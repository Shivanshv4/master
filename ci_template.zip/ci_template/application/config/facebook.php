<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '';
$config['secret']  = '';

?>
