<?php

$lang["msg_country_list"] = "Country List";
$lang["empty_phone"] = "Please enter phone number.";
$lang["invalid_phone"] = "Please enter valid phone number.";
$lang["otp_number"] = "OTP Number.";
$lang["empty_password"] = "Please enter password.";
$lang["empty_otp"] = "Please enter otp number.";
$lang["success_verify_otp"] = "OTP verified successfully.";
$lang["enter_valid_otp"] = "Please enter valid otp number.";
$lang['signup_success'] =  'Thanks for sign up with us.';
$lang['otp_limit'] =  'You have reached OTP limit for today.';
?>