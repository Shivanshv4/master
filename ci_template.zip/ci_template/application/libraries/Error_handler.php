<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * File Name: errors.php
 * Description: This file contains classes and functions to display all error and success messages.
 * Author: Singsys Pte. Ltd. (00120)
 * Date Created: 2015-06-08
 * Date Released: 2015-07-30
 */
class Error_handler {

    protected $errMsg;
    public function __construct() {
         
    }
    public function _getStatusMessage($errorStatus) {
        include('webservice_exception.php');
        return $this->errMsg = $messages[$errorStatus];
    }
}

?>