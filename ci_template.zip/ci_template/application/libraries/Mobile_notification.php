<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * File Name: errors.php
 * Description: This file contains classes and functions to display all error and success messages.
 * Author: Singsys Pte. Ltd. (00120)
 * Date Created: 2015-06-08
 * Date Released: 2015-07-30
 */
class Mobile_notification
{
   var $status = "failed";
   var $message = "Invalid Operation";
   private $isError = FALSE;
   private $androidApiKey = "AIzaSyD53NQdeD2v0LyJS0P3Hc9JyJY9yrgIa3s";
   private $androidUrl ="https://android.googleapis.com/gcm/send";
   //private $ios_cert_path = 'third_party/apns-dev.pem';  // sandbox
   private $ios_cert_path = 'third_party/apns-pro.pem';    // live
   private $ios_cert_pwd ="";
   
   //private $ios_cert_server = "ssl://gateway.sandbox.push.apple.com:2195"; // sandbox
   private $ios_cert_server = "ssl://gateway.push.apple.com:2195";  // live
   
   private $CI ;
   
   public function __construct()
   {
	//parent constructor
	$this->CI = &get_instance();
	$this->CI->load->library('error_handler');
	$this->CI->load->database();
	$this->CI->load->model('webservice_model','',TRUE);
   }
   
   /**
    *This function is used to send the push notifications to the devices
    */
   public function _sendPushNotification($tokenArr =array(), $notifyTo, $notifyFrom,$notifType, $notification_id,$account_type="", $otherData = array())
   {

	$sendPush = array();
	//$message = $this->getNotificationMessage($notifType);
	$receiverData = $this->CI->webservice_model->getUserDetails($notifyTo);
	//_print_r($receiverData);exit;
	if($receiverData['device_type'] == "android"){
	   $sendPush =  $this->_sendAndroidPushNotification($tokenArr, $message="", $notifyTo, $notifyFrom,$notifType,$notification_id,$account_type, $otherData);
	}else{
	   $sendPush =  $this->_sendApplePushNotification($tokenArr, $message="", $notifyTo, $notifyFrom,$notifType,$notification_id,$account_type, $otherData);
	}
	return $sendPush ;
   }
   /**
    *This function is used to send the push notifications to the android devices
    */
   public function _sendAndroidPushNotification($tokenArr, $message="", $notifyTo, $notifyFrom,$notifType, $notification_id, $account_type ="", $otherData = array())
   {
	$DataArr = array();
	if(count($tokenArr)==0){
	   $this->message = $this->CI->error_handler->_getStatusMessage('unable_to_send_push');
	}elseif(trim($notifyTo) == ""){
	   $this->message = $this->CI->error_handler->_getStatusMessage('invalid_notify_to');
	}elseif(trim($notifyFrom) == ""){
	   $this->message = $this->CI->error_handler->_getStatusMessage('invalid_notify_from');
	}else{
	   $senderData = $this->CI->webservice_model->getUserDetails($notifyFrom);
	   $receiverData = $this->CI->webservice_model->getUserDetails($notifyTo);
	   $badge_count = $this->CI->webservice_model->getUreadMessagesCount(array('to_id'=>$notifyTo));
	   
	  
	   $datetime = date('Y-m-d H:i:s');

	   $data = array('action' => $notifType, 'sname' => $senderData['name'],'request_name' => $otherData['request_name'],'sid'=>$notifyFrom, 'notification_id'=>$notification_id,'account_type'=>$account_type  ? $account_type:""); // action defines whether any action should take after recieving the push
	    
	    
	    
	    foreach($badge_count as $key=>$val)
	   {
	       $data[$key]=$val;
	   }
	   
	   if($notifType == 'new_sfs') {
		 $sfs_data = $this->CI->webservice_model->getShoutOutByID($notification_id);
		 if(count($sfs_data))
		 $data['thr'] = $sfs_data['time_in_hr'];
	   }


	   if(count($otherData))
		 $data = array_merge($data, $otherData);

		 
		
	   $tokenArr = array_values(array_filter($tokenArr));
	   $fields = array(
		 'registration_ids' => $tokenArr,
		 'data' => $data,
	   );

	   $headers = array(
		     'Authorization: key=' . $this->androidApiKey,
		     'Content-Type: application/json'
	   );
	   // Open connection
	   $ch = curl_init();
	   
	   // Set the url, number of POST vars, POST data
	   curl_setopt($ch, CURLOPT_URL, $this->androidUrl);
	   
	   curl_setopt($ch, CURLOPT_POST, true);
	   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	   
	   // Disabling SSL Certificate support temporarly
	   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	   
	   curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
	   
	   // Execute post
	   $result = curl_exec($ch);
	   
	   curl_close($ch);
	   //echo 'Result from google:' . $result . '---';
	   $res_dec = json_decode($result);
	   //_print_r($res_dec);exit;
	   if ($res_dec->success >= 1){
		$this->message = $this->CI->error_handler->_getStatusMessage('notification_sent');
		$this->status = "success";
	   }
	   else{
		$this->message = $this->CI->error_handler->_getStatusMessage('notification_not_sent');
	   }
	}
	$DataArr = array('status' => $this->status, 'message' => $this->message, 'data'=>$res_dec);
	//print_r($DataArr); exit();
	return $DataArr;
   }
   
   /**
     *Method used to send the notifications to apple device
     */
   public function _sendApplePushNotification($tokenArr, $message="", $notifyTo, $notifyFrom,$notifType,$notification_id,$account_type ="", $otherData = array())
   {

	//print_r($tokenArr); 
	if($tokenArr == '' || count($tokenArr)==0){
	   $this->message = $this->CI->error_handler->_getStatusMessage('unable_to_send_push');
	}elseif(trim($notifyTo) == ""){
	   $this->message = $this->CI->error_handler->_getStatusMessage('invalid_notify_to');
	}elseif(trim($notifyFrom) == ""){
	   $this->message = $this->CI->error_handler->_getStatusMessage('invalid_notify_from');
	}
	   
	
	 
	$senderData = $this->CI->webservice_model->getUserDetails($notifyFrom);
	
	$sname = substr($senderData['name'],0,22);
	
	$request_name = substr($otherData['request_name'],0,12);
	
	$message_data = $this->getNotificationMessage($notifType,$sname,$request_name);
	
	$receiverData = $this->CI->webservice_model->getUserDetails($notifyTo);
	$badge_count = $this->CI->webservice_model->getUreadMessagesCount(array('to_id'=>$notifyTo));
	$datetime = date('Y-m-d H:i:s');
	$account_type_arr = array("shopowner"=>1, "consumer"=>2);
	//echo $appleKey;
	$tokenArr = array_values(array_filter($tokenArr));
	$ctx = stream_context_create();
	stream_context_set_option($ctx, 'ssl', 'local_cert', (APPPATH.$this->ios_cert_path));
	stream_context_set_option($ctx, 'ssl', 'passphrase', $this->ios_cert_pwd);

	//$apns_fp = stream_socket_client($this->ios_cert_server, $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
	$apns_fp = stream_socket_client($this->ios_cert_server, $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
	if ($apns_fp)
	{
	  if($notifType == 'Off' || $notifType == 'OffRequest') {
	       $body['aps'] = array(
		 'action' => $message_data['type'],
		 'badge'=>$badge_count['total_count'],
		 //'sn' => substr($senderData['name'],0,12),
		 'sn' => substr($senderData['name'],0,22),
		 'nid'=>$notification_id,
		 'content-available' => '1',
	       );
	  } else {	   
		 $data = array(
			'alert'  => $message_data['msg'],
			'action' => $message_data['type'],
			///'sn' => substr($senderData['name'],0,10),
			'sn' => substr($senderData['name'],0,22),
			//'dt' => $datetime,
			'sid'=>$notifyFrom,
			'badge'=>$badge_count['total_count'],
			'nid'=>$notification_id,
			'at'=>$account_type_arr[$account_type] ? $account_type_arr[$account_type] :0,
			'sound' => 'notify.wav',
		 );
		 if(count($otherData))
		 $data = array_merge($data, $otherData);
		 $body['aps'] = $data;
	  }
	  if($notifType == 'new_sfs') {
		 $sfs_data = $this->CI->webservice_model->getShoutOutByID($notification_id);
		 if(count($sfs_data))
			$data['thr'] = $sfs_data['time_in_hr'];
	  }

	   $payload = json_encode($body);
	   //echo '$payload==>'.$payload;
	   $msg = '';
	   foreach ($tokenArr as $token) {
		$msg .= chr(0) . pack('n', 32) . pack('H*', $token) . pack('n', strlen($payload)) . $payload;
	   }

	   $result = fwrite($apns_fp, $msg, strlen($msg));
	   //echo '$result==>'.$result;
	   if (!$result){
		$this->message = $this->CI->error_handler->_getStatusMessage('notification_not_sent');
	   }
	   else{
		$this->message = $this->CI->error_handler->_getStatusMessage('notification_sent');
		$this->status = "success";
	   }
	   // Close the connection to the server
	   fclose($apns_fp);
	}
	$DataArr = array('status' => $this->status, 'message' => $this->message, 'data'=>$result);
	return $DataArr;
   }

   private function getNotificationMessage($notifType,$user_name,$product_name)
   {
	$notification_arr =array();
	switch ($notifType){
	   case "new_product":
		$notification_msg = "New product has been added.";
		$notif_Type = '1';
	   break;
	   case "new_sfs":
		$notification_msg = "A product has been shout out.";
		$notif_Type = '2';
	   break;
	   case "new_follower":
	         $user_name= $user_name!=""?$user_name:"User";
		$notification_msg = "".$user_name." has started to following you.";
		$notif_Type = '3';
	   break;
	   case "new_review":
		$notification_msg = "A new review has been posted.";
		$notif_Type = '4';
	   break;
	   case "new_direct_request":
		$notification_msg = "A new request has been posted for your product.";
		$notif_Type = '5';
	   break;
	   case "new_open_request":
		$notification_msg = "A new request has been posted.";
		$notif_Type = '6';
	   break;
	   case "new_chat":
		$notification_msg = "A new message has been received.";
		$notif_Type = '7';
	   break;
	   case "chat":
		$notification_msg = "A new message has been received.";
		$notif_Type = '11';
	   break;
	   case "new_reply":
		$notification_msg = "A new comment has been added.";
		$notif_Type = '8';
	   break;
	 case "Off":
		$notification_msg = "";
		$notif_Type = '9';
	   break;
	 case "OffRequest":
		$notification_msg = "";
		$notif_Type = '10';
	   break;
	  case "new_rank":
		$notification_msg = "A new rank assigned.";
		$notif_Type = '12';
	   break;
	 case "new_request_comment":
		$notification_msg = "".$user_name." has posted comment on ".$product_name." .";
		$notif_Type = '13';
	   break;
	 case "featured_profile":
		$notification_msg = "Your application for Show Your Profile advertisement has been approved!";
		$notif_Type = '14';
	   break;
	 case "featured_product":
		$notification_msg = "Your application for Feature One Product advertisement has been approved!";
		$notif_Type = '15';
	   break;

	}
	
	$notification_arr = array('msg'=>$notification_msg, 'type'=>$notif_Type);
	return $notification_arr;
   }
}
?>
