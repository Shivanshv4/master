<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * File Name: email_notification.php
 * Description: This file contains classes and functions to send the notifications.
 * Author: Singsys Pte. Ltd. (00120)
 * Date Created: 2015-09-14
 * Date Released: 2015-09-14
 */
class Email_notification
{
   var $status = "failed";
   var $message = "Invalid Operation";
   private $isError = FALSE;
   private $CI ;

   public function __construct()
   {
	//parent constructor
	$this->CI = &get_instance();
	$this->CI->load->library('error_handler');
	$this->CI->load->database();
	$this->CI->load->model('webservice_model','',TRUE);
	$this->CI->load->model('admin_model','',TRUE);
   }

   public function _sendEmailNotifications($data, $mail_type)
   {
	$categoryData = $productData =array();
	$adminEmail =  $this->CI->admin_model->getconfig('signup_email');
	$to_userData = $this->CI->webservice_model->getUserDetails($data['to_id']);
	$from_userData = $this->CI->webservice_model->getUserDetails($data['from_id']);
	
	switch ($mail_type)
	{
	   case "new_product":
		$msg = $this->CI->webservice_model->_getMessage('new_product_post');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

		$patternFind1[0] 	= '/{user_name}/';
		$patternFind1[1] 	= '/{shopowner_name}/';
		$patternFind1[2] 	= '/{product_name}/';
		$patternFind1[3] 	= '/{product_category}/';

		$replaceFind1[0] 	= $to_userData['name'];
		$replaceFind1[1] 	= $productData['shopowner_name'];
		$replaceFind1[2] 	= $productData['name'];
		$replaceFind1[3] 	= $categoryData['category_name'];

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

		break;
	   case "new_sfs":
		$msg = $this->CI->webservice_model->_getMessage('new_sfs_post');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

		$patternFind1[0] 	= '/{user_name}/';
		$patternFind1[1] 	= '/{shout_out_by}/';
		$patternFind1[2] 	= '/{product_name}/';
		$patternFind1[3] 	= '/{product_category}/';

		$replaceFind1[0] 	= $to_userData['name'];
		$replaceFind1[1] 	= $from_userData['name'];
		$replaceFind1[2] 	= $productData['name'];
		$replaceFind1[3] 	= $categoryData['category_name'];

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

		break;
	   case "new_follower":
		$msg = $this->CI->webservice_model->_getMessage('new_follower');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

		$patternFind1[0] 	= '/{user_name}/';
		$patternFind1[1] 	= '/{follower_name}/';

		$replaceFind1[0] 	= $to_userData['name'];
		$replaceFind1[1] 	= $from_userData['name'];

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

		break;
	   case "new_review":
		$msg = $this->CI->webservice_model->_getMessage('new_review_post');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

		$patternFind1[0] 	= '/{user_name}/';
		$patternFind1[1] 	= '/{reviewer_name}/';
		$patternFind1[2] 	= '/{product_name}/';
		$patternFind1[3] 	= '/{product_category}/';

		$replaceFind1[0] 	= $to_userData['name'];
		$replaceFind1[1] 	= $from_userData['name'];
		$replaceFind1[2] 	= $productData['name'];
		$replaceFind1[3] 	= $categoryData['category_name'];

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

		break;
	   case "new_request":
		if($data['product_id'] >0){
		   $msg = $this->CI->webservice_model->_getMessage('new_direct_request');
		}else{
		   $msg = $this->CI->webservice_model->_getMessage('new_open_request');
		}

		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

		if($data['product_id'] >0){
		   $patternFind1[0] 	= '/{user_name}/';
		   $patternFind1[1] 	= '/{requester_name}/';
		   $patternFind1[2] 	= '/{product_name}/';
		   $patternFind1[3] 	= '/{product_category}/';

		   $replaceFind1[0] 	= $to_userData['name'];
		   $replaceFind1[1] 	= $from_userData['name'];
		   $replaceFind1[2] 	= $productData['name'];
		   $replaceFind1[3] 	= $categoryData['category_name'];
		}else{
		   $patternFind1[0] 	= '/{user_name}/';
		   $patternFind1[1] 	= '/{requester_name}/';
		   $patternFind1[2] 	= '/{product_category}/';

		   $replaceFind1[0] 	= $to_userData['name'];
		   $replaceFind1[1] 	= $from_userData['name'];
		   $replaceFind1[2] 	= $categoryData['category_name'];
		}

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

		break;
	   case "new_reply":
		$msg = $this->CI->webservice_model->_getMessage('new_comment_post');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

		$patternFind1[0] 	= '/{user_name}/';
		$patternFind1[1] 	= '/{replyby_name}/';

		$replaceFind1[0] 	= $to_userData['name'];
		$replaceFind1[1] 	= $from_userData['name'];

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

		break;
	    case "new_rank":
		$msg = $this->CI->webservice_model->_getMessage('new_rank');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

		$patternFind1[0] 	= '/{user_name}/';
		$patternFind1[1] 	= '/{rank}/';

		$replaceFind1[0] 	= $to_userData['name'];
		$replaceFind1[1] 	= $to_userData['col_border'];

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

		break;
	    case "new_request_comment":
	       
	       
		$msg = $this->CI->webservice_model->_getMessage('new_request_comment');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

	       $request_data = $this->CI->webservice_model->getRequestData($data['request_id']);
	       $request_name = $request_data['title']!=""?$request_data['title']:'';
	       
		$patternFind1[0] 	= '/{user_name}/';
		$patternFind1[1] 	= '/{replyby_name}/';
		$patternFind1[2] 	= '/{request_name}/';

		$replaceFind1[0] 	= $to_userData['name'];
		$replaceFind1[1] 	= $from_userData['name'];
		$replaceFind1[2] 	= $request_name;

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

		break;
	    case "featured_profile":
	          
		$msg = $this->CI->webservice_model->_getMessage('featured_profile');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

	      
		$patternFind1[0] 	= '/{user_name}/';
		
		$replaceFind1[0] 	= $to_userData['name'];
		

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

	    break;
	 case "featured_product":
	          
		$msg = $this->CI->webservice_model->_getMessage('featured_product');
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);

		$patternFind1[0] 	= '/{user_name}/';
		

		$replaceFind1[0] 	= $to_userData['name'];
		

		$txtdesc_contact	= stripslashes($message);
		$contact_sub	= stripslashes($subject);
		$contact_sub	= preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

	    break;
	}
	try
	{
	   $email_config = array(
		'protocol'  => 'smtp',
		'smtp_host' => $this->CI->admin_model->getconfig('smtp_server_host'),
		'smtp_port' => $this->CI->admin_model->getconfig('smtp_port_number'),
		'smtp_user' => $this->CI->admin_model->getconfig('smtp_uName'),
		'smtp_pass' => $this->CI->admin_model->getconfig('smtp_uPass'),
		'mailtype'  => 'html',
		'starttls'  => true,
		'newline'   => "\r\n"
	   );

	   $this->CI->load->library('email', $email_config);
	   $this->CI->email->initialize($email_config);
	   $this->CI->email->from($adminEmail, SITE_NAME);
	   $this->CI->email->to($to_userData['email'], $to_userData['name']);
	   $this->CI->email->subject($contact_sub);
	   $this->CI->email->message($ebody_contact);
	   if($this->CI->email->send()){ 
		//show_error($this->CI->email->print_debugger());exit;
		return 1;
	   }else{ 
		//show_error($this->CI->email->print_debugger());exit;
		return 0;
	   }
	}catch(Exception $ex){
	   //show_error($this->CI->email->print_debugger());
	   return 0;
	}
   }
}
?>
