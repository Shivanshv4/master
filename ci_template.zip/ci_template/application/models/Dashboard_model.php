<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_model extends CI_Model
{
    public function __construct() {
		$this->load->database();
		parent::__construct();
	}
    
    public function getCountries() ///
    {
	$query = $this->db->order_by('country_name','ASC')->get_where('country', array('status' => "Active"));
        return $query->result();
    }
    public function countUserProducts($userid)
    {
                $this->db->select('count(*) as total');
		$this->db->where('shop_id',$userid);
		$q = $this->db->get('products');
		$details = $q->row_array();
                if($details['total']>0)
                    return $details['total'];
                else
                    return 0;
    }
    public function countUserReviews($userid)
    {  
                $this->db->select('count(r.id) as total');
                $this->db->from('reviews r');
                $this->db->join('products p', 'p.id = r.product_id', 'left');
                $this->db->where('p.shop_id', $userid);
                $q = $this->db->get();
                
                $details = $q->row_array();
                if($details['total']>0)
                    return $details['total'];
                else
                    return 0;
                    
    }
    public function getProductByID($id)
    {
	$this->db->select('*');
	$this->db->where('id',$id);
	$q = $this->db->get('products');
	$data= $q->row_array();
	global $product_type;
	$data['product_type'] = $product_type[trim($data['product_type'])];
	return $data;
	
    }
    public function getUserProducts($userid,$limit)
    {
		//$this->db->limit($limit[0],$limit[1]);
		//$query = $this->db->order_by('id', 'DESC')->get_where('products', array('shop_id' => $userid));
		//$fffff =  $query->result();
		//echo $this->db->last_query();
		//return $fffff;

		$this->db->select('products.*');
		$this->db->from('products');
		if(count($limit)>0){
			$this->db->limit($limit[0],$limit[1]);
	    }
		$this->db->where(array('shop_id' => $userid));
		$this->db->order_by('featured','DESC');
		$this->db->order_by('id','DESC');
		$q = $this->db->get();
		//echo $this->db->last_query();
        $data =  $q->result();
		return $data;

    }
    public function getUserProductsNext($userid,$limit,$lastid)
    {
	if($userid>0)
	{
	    $this->db->limit($limit[0],$limit[1]);
	    //$this->db->where(array('shop_id' => $userid,'id < '=>$lastid));
	    $this->db->where(array('shop_id' => $userid));
	    $this->db->order_by('id','DESC');
	    $query=$this->db->get('products');
	    return $query->result();
	}
	else{
          return array();
	}
    }
    /* this function will return all active reviews posted on the product*/
    public function getProductReviews($product_id)
    {
	$this->db->select('reviews.*,users.name, users.image_name');
	$this->db->from('reviews');
	$this->db->join('users', 'reviews.user_id = users.id');
	$this->db->join('products', 'reviews.product_id = products.id');
	$this->db->where('reviews.cstatus',"Active");
	$this->db->where('products.id',$product_id);
	$q = $this->db->get();
	///echo $this->db->last_query();
	return $q->result_array();
    }
    /* this function will return all reviews posted by the user */
    public function getMyReviews($userid,$limit =array())
    {
	if($userid>0)
	{
	    $this->db->select('reviews.*,products.*,reviews.cstatus AS review_status');
	    $this->db->from('reviews');
	    $this->db->join('users', 'reviews.user_id = users.id');
	    $this->db->join('products', 'reviews.product_id = products.id');
	    $this->db->where('users.id',$userid);
	    $this->db->order_by('reviews.id','DESC');
	    if(count($limit)>0){
		$this->db->limit($limit[0],$limit[1]);
	    }
	    $q = $this->db->get();
	    return $q->result_array();
	}
	return array();
	
    }
     /* this function will return all reviews posted on the shop * */
    public function getMyShopReviews($userid,$limit =array())
    {
	if($userid>0)
	{
	    $this->db->select('reviews.*,users.name,users.image_name'); //products.name as product_name
	    $this->db->from('reviews');
	   // $this->db->join('products', 'reviews.product_id = products.id');
	    $this->db->join('users', 'reviews.user_id = users.id');
	    $this->db->where('reviews.shop_id',$userid);
	    $this->db->order_by('reviews.id','DESC');
	    if(count($limit)>0){
		$this->db->limit($limit[0],$limit[1]);
	    }
	    $q = $this->db->get();
	    return $q->result_array();
	}
	return array();
	
    }
    
    public function getMyShopRequests_delete($userid)
    {
	  if($userid >0)
	  {
		$this->db->select('request.*,users.name,users.image_name,products.name as product_name');
		$this->db->from('request');
		$this->db->join('products', 'request.product_id = products.id');
		$this->db->join('users', 'request.user_id = users.id');
		$this->db->where('request.shop_id',$userid);
		$q = $this->db->get();
		return $q->result_array();
	  }
	  return array();
    }
    
    public function getMyRequests_delete($userid) //
    {
	if($userid>0)
	{
	    $this->db->select('request.*,users.name,users.image_name,products.name as product_name');
	    $this->db->from('request');
	    $this->db->join('users', 'request.shop_id = users.id');
	    $this->db->join('products', 'request.product_id = products.id');
	    $this->db->where('request.user_id',$userid); 
	    $q = $this->db->get();
	    return $q->result_array();
	}
	return array();
	
    }
    
     public function getProductRequests($userid,$limit =array())
    {
	if($userid>0)
	{
	    $this->db->select('request.*,users.name,users.image_name');
	    $this->db->from('request');
	    $this->db->join('products', 'request.product_id = products.id');
	    $this->db->join('users', 'products.shop_id = users.id');
	    $this->db->where('users.id',$userid);
	    if(is_array($limit) && count ($limit) && !empty($limit[0]) ){
		$this->db->limit($limit[0],$limit[1]);
	  }
	    $q = $this->db->get(); 
	    return $q->result_array();
	}
	return array();
	
    }


	public function getFeaturedProduct($userid = 0)
    {
	if($userid>0)
	{
	    $this->db->select('products.id, products.name, products.shop_id');
	    $this->db->from('products');
	    //$this->db->join('products', 'request.product_id = products.id');
	    $this->db->join('users', 'products.shop_id = users.id');
	    $this->db->where('users.id',$userid);
		$this->db->where('products.product_type != ','soldout');
		$this->db->where('products.featured = ','Yes');
	//    if(is_array($limit) && count ($limit) && !empty($limit[0]) ){
	//	$this->db->limit($limit[0],$limit[1]);
	  //}
	    $q = $this->db->get();
		//echo $this->db->last_query();
	    return $q->result_array();
	}
	return array();

    }
    
     public function countShopFollowers($userid,$account_type)
    {
	if($userid>0)
	{
	    if($account_type=="shopowner"){
		$this->db->select('count(*) as total');
		$this->db->from('followers');
		$this->db->join('users', 'followers.shop_id = users.id','inner');
		$this->db->where('followers.shop_id',$userid);
		$this->db->where('followers.status',"Following");
		$this->db->where('users.status',"Active");
		$q = $this->db->get(); 
		$data=$q->result_array(); 
		return $data[0]['total'];
	    }
	    else{
		$this->db->select('count(*) as total');
		$this->db->from('followers');
		$this->db->join('users', 'followers.user_id = users.id','inner');
		$this->db->where('followers.user_id',$userid);
		$this->db->where('followers.status',"Following");
		$this->db->where('users.status',"Active");
		$q = $this->db->get(); 
		$data=$q->result_array(); 
		return $data[0]['total'];
	    }
	}
	return 0;
	
    }

    public function getShopFollowers($userid)
    {
	if($userid>0)
	{
		$this->db->select('u.*,followers.added_on');
		$this->db->from('followers');
		$this->db->join('users as shop', 'followers.shop_id = shop.id','inner');
		$this->db->join('users as u', 'followers.user_id = u.id','inner');
		$this->db->where('followers.shop_id',$userid);
		$this->db->where('followers.status',"Following");
		$this->db->where('u.status',"Active");
		$q = $this->db->get();
		$data=$q->result_array();
		return $data;
	}
	return 0;

    }

    public function getShoutOutByID($productId,$userid=0)
    {
	//if($userid>0 && $productId>0)
	if($productId>0)
	{
	    $this->db->select('sfs.*');
	    $this->db->from('sfs');
	    //$this->db->where('sfs.user_id',$userid);
	    $this->db->where('sfs.product_id',$productId);
	    $this->db->where('sfs.status','Active');
	    $q = $this->db->get(); 
	    $data=$q->row_array(); 
	    return $data;
	}
	return array();
	
    }
    
     public function getReviewByID($id)
    {
	$this->db->select('*');
	$this->db->where('id',$id);
	$q = $this->db->get('reviews');
	return $q->row_array();
	
    }
    public function AllUserByType($whereClause = "",$limit="")
    {
	  $this->db->select('users.*');
	  $this->db->from('users');
	  if(is_array($whereClause) && count ($whereClause)){
	       $this->db->where($whereClause);
	  }
	  if(is_array($limit) && count ($limit) && !empty($limit[0]) ){
	    $this->db->limit($limit[0],$limit[1]);
	  }
	  $this->db->order_by('users.id','DESC');
	  $query=$this->db->get();
	  $data=$query->result_array();
	  //echo $this->db->last_query(); die;
	  return $data;
    }
   public function ShopProductList($whereClause = "",$limit="")
   {
	  $this->db->select('products.*');
	  $this->db->select('users.name as shop_name');
	  $this->db->from('users');
	  $this->db->join('products', 'products.shop_id = users.id');
	  if(is_array($whereClause) && count ($whereClause)){
	       $this->db->where($whereClause);
	  }
	  $query=$this->db->get();
	  $data=$query->result_array();
	  //echo $this->db->last_query();
	  return $data;
   }
   
   /**
    *This function is used to list the static content pages
    *@param string $title_name
    *@return array
    */
   public function getStaticContentByVari($variabeleName=0,$status="")
   {
	$content_array = array();
	if($variabeleName){
	    
	    if(!empty($status))
	    {
	    $where = array('variable_name'=>$variabeleName,"status"=>$status);
	    }
	    else{
		$where = array('variable_name'=>$variabeleName);
	    }
	   $query = $this->db->get_where('static_content',$where);
	   $content_array = $query->row_array();
	  
	}
	return $content_array;
   }
    public function getNotification($whereClause = "",$limit="",$user_id=0)
    {
	  $alldatas = array();
	  $this->db->select('notification.*,users.name,users.image_name,users.account_type');
	  $this->db->from('notification');
	  $this->db->join('users', 'users.id = notification.from_id');
	  if(is_array($whereClause) && count ($whereClause)){
	       $this->db->where($whereClause);
	  }
	  if(is_array($limit) && count ($limit) && !empty($limit[0]) ){
	    $this->db->limit($limit[0],$limit[1]);
	  }
	  $this->db->order_by('notification.id','DESC');
	  $query = $this->db->get();
	  $datas = $query->result_array();
	  //echo $this->db->last_query();
	  
	  
	  $time_zone = getUserLocalTimeZone($user_id);
	
	  if(count($datas)) {
	    foreach ($datas as $data){
			
		$sql_query = "SELECT COUNT(id_block) AS total_row FROM cm_block_users WHERE status = 'Block' AND (shop_id ='".$data['to_id']."' AND user_id = '".$data['from_id']."' ) OR  (shop_id ='".$data['from_id']."' AND user_id = '".$data['to_id']."' )" ;
		$totalProduct_query = $this->db->query($sql_query);
		$totalProductBlock = $totalProduct_query->row()->total_row ;
		
		$data['user_status'] = '';
		if($totalProductBlock > 0)
			$data['user_status'] = 'Block';
			
		$data['shop_name'] = '';
		$data['shop_image'] = '';
		$data['product_name'] = '';
		$data['product_id'] = '';
		$data['account_type'] = $data['account_type']!=""?$data['account_type']:"";
		$data['time_in_hr'] = '';
		$data['request_title'] = '';
		$data['created_on_db'] = agoTimePost($data['created_on'],$time_zone);
		//$data['created_on'] = agoTimePost($data['created_on']);
		switch ($data['type']) {
		    case  'new_follower' :
		    case  'unfollow' :
				// name  image_name
				$this->db->select('users.name, users.image_name, users.account_type');
				$this->db->from('users');
				$this->db->where('users.id',$data['to_id']);
				$query_sfs = $this->db->get();
				$data_sfs = $query_sfs->row();
				$data['shop_name'] = $data_sfs->name;
				$data['shop_image'] = $data_sfs->image_name;
				
				// name  image_name
				$this->db->select('users.name, users.image_name, users.account_type');
				$this->db->from('users');
				$this->db->where('users.id',$data['from_id']);
				$query_sfs = $this->db->get();
				$data_sfs = $query_sfs->row();
				
				$data['account_type'] = $data_sfs->account_type;

				$data['product_name'] = '';
				$data['product_id'] = '';
				$data['product_image'] = '';
		    break;
		    case  'new_product' :

				$this->db->select('products.id, products.name');
				$this->db->from('products');
				$this->db->where('products.id',$data['detail_id']);
				$query_sfs = $this->db->get();
				$data_sfs = $query_sfs->row();
				$data['product_name'] = $data_sfs->name ? $data_sfs->name:"";
				$data['product_id'] = $data_sfs->id ? $data_sfs->id :"";
				$data['product_image'] = $this->webservice->getProductImageById($data['product_id']);

		    break;
		    case  'new_request' :
				$this->db->select('products.id, products.name');
				$this->db->from('request');
				$this->db->join('products', 'request.product_id = products.id');
				$this->db->where('request.id',$data['detail_id']);
				$query_sfs = $this->db->get();
				$data_sfs = $query_sfs->row();
				$data['product_name'] = $data_sfs->name ? $data_sfs->name :"";
				$data['product_id'] = $data_sfs->id ? $data_sfs->id :"";
				$data['product_image'] = '';

		    break;
		   case  'new_request_comment' :
				$this->db->select('request.id, request.title');
				$this->db->from('request');
				$this->db->where('request.id',$data['detail_id']);
				$query_sfs = $this->db->get();
				$data_sfs = $query_sfs->row();
				$data['request_title'] = $data_sfs->title ? $data_sfs->title :"";
				$data['product_id'] = $data_sfs->id ? $data_sfs->id :"";
				$data['product_image'] = '';

		    break;
		    case  'new_review' :
				$this->db->select('products.id, products.name');
				$this->db->from('reviews');
				$this->db->join('products', 'reviews.product_id = products.id');
				$this->db->where('reviews.id',$data['detail_id']);
				$query_sfs = $this->db->get();
				$data_sfs = $query_sfs->row();
				$data['product_name'] = $data_sfs->name ? $data_sfs->name :"";
				$data['product_id'] = $data_sfs->id ? $data_sfs->id :"";
				$data['product_image'] = $this->webservice->getProductImageById($data_sfs->id);
		    break;
		    case  'new_sfs' :

				$this->db->select('products.id, products.name, time_in_hr');
				$this->db->from('sfs');
				$this->db->join('products', 'sfs.product_id = products.id');
				$this->db->where('sfs.id',$data['detail_id']);
				$query_sfs = $this->db->get();
				$data_sfs = $query_sfs->row();

				$data['product_name'] = $data_sfs->name ? $data_sfs->name :"";
				$data['product_id'] = $data_sfs->id ? $data_sfs->id :"";
				$data['product_image'] = $this->webservice->getProductImageById($data_sfs->id);
				$data['time_in_hr'] = $data_sfs->time_in_hr ? $data_sfs->time_in_hr :"";

		    break;
		    case 'new_reply':
				$new_reply = $this->db->query("SELECT id_request FROM `cm_reply` WHERE id_reply = '".$data['detail_id']."'");
				$data['detail_id']  = $new_reply->row()->id_request;

				$this->db->select('products.id, products.name');
				$this->db->from('products');
				$this->db->where('products.id',$data['detail_id']);
				$query_sfs = $this->db->get();
				$data_sfs = $query_sfs->row();
				$data['request_title'] = $data_sfs->name;


		    break;

		}
		$alldatas[] = $data;
	    }
	  }
	  //echo count($datas).' = '.count($alldatas);
	  return $alldatas;
    }
    public function getFollowStatus($userid,$shopid)
    {
	 $query = $this->db->get_where('followers',array('user_id'=>$userid,'shop_id'=>$shopid,'status'=>'Following'));
	 $data_array = $query->row_array();
	 return $data_array;
    }
    
    public function getShopReviewProductCount($session_data)
    {
	  if($session_data['account_type'] == "shopowner"){
		$query = $this->db->get_where('reviews',array('shop_id'=>$session_data['Userid']));
		$data_array = $query->result_array();
		$reviews=count($data_array);
		
		$query = $this->db->get_where('products',array('shop_id'=>$session_data['Userid']));
		$data_array = $query->result_array(); 
		$products=count($data_array);
	  }
	  else
	  {
		$query = $this->db->get_where('reviews',array('user_id'=>$session_data['Userid'],'cstatus'=>'Active'));
		$data_array = $query->result_array();
		$reviews=count($data_array);
		$query = $this->db->get_where('followers',array('user_id'=>$session_data['Userid'],'status'=>'Following'));
		$data_array = $query->result_array();
		$products=count($data_array);
	  }
	  $res['reviews']=$reviews;
	  $res['products']=$products;
	  return $res;
    }
    
     public function getMyShopRequests($userid,$limit = array())
    {
	  if($userid >0)
	  {
		$this->db->select('request.*,users.name,users.image_name,products.name as product_name, products.image as p_image, products.id as p_id ');
		$this->db->from('request');
		$this->db->join('products', 'request.product_id = products.id');
		$this->db->join('users', 'request.user_id = users.id');
		$this->db->where('request.shop_id',$userid);
		$this->db->order_by('request.id','DESC');
		if(is_array($limit) && count ($limit) && !empty($limit[0]) ){
		    $this->db->limit($limit[0],$limit[1]);
		}
		$q = $this->db->get();
		return $q->result_array();
	  }
	  return array();
    }
    
    public function getMyRequests($userid,$limit = array())
    {
	if($userid>0)
	{
	    $this->db->select('request.*,users.name,users.image_name,products.name as product_name');
	    $this->db->from('request');
	    $this->db->join('users', 'request.shop_id = users.id');
	    $this->db->join('products', 'request.product_id = products.id');
	    $this->db->where('request.user_id',$userid);
	    $this->db->order_by('request.id','DESC');
	    if(is_array($limit) && count ($limit) && !empty($limit[0]) ){
		    $this->db->limit($limit[0],$limit[1]);
		}
	    $q = $this->db->get();
	    return $q->result_array();
	}
	return array();
	
    }
    /* -------------------------------     add insert update delete     --------------------*/
    public function add_product($insertArray)
    {
	  $insertArray['added_on'] =   date('Y-m-d H:i:s');
	  $insertArray['updated_on'] =   date('Y-m-d H:i:s');
	  $this->db->insert('products', $insertArray);
        return $this->db->insert_id();
    }
    
    public function update_product($id,$updatArray){
	  $updatArray['updated_on'] =   date('Y-m-d H:i:s');
	  $this->db->where('id', $id);
	  return $this->db->update('products', $updatArray);
    }
     public function delete_product($id){
	    $this->db->where('id', $id);
	  return $this->db->delete('products');
     }
    public function add_request($insertArray)
    {
       $this->db->insert('request', $insertArray);
        return $this->db->insert_id();
    }
    public function update_request($id,$updatArray)
    {
	  $this->db->where('id', $id);
	  return $this->db->update('request', $updatArray);
	  // echo $this->db->last_query();
    }
     public function add_review($insertArray)
    {
       $this->db->insert('reviews', $insertArray);
        return $this->db->insert_id();
    }
   
    public function add_shoutout($insertArray)
    {
       $this->db->insert('sfs', $insertArray);
        return $this->db->insert_id();
    }
     public function update_review($id,$updatArray){
		$this->db->where('id', $id);
		return $this->db->update('reviews', $updatArray);
    }
     public function delete_review($id){
	    $this->db->where('id', $id);
	  return $this->db->delete('reviews');
     }
     public function update_notification($id,$updatArray){
		$this->db->where('id', $id);
		return $this->db->update('notification', $updatArray);
    }
    
   
    /**
     *This function is used to get the replies of any request.
     *@param requested data array
     *@return array
     */
    public function getRequestReplies($dataArr, $limit=array())
    {
	  $query_result = array();
	  if($dataArr['id_reply'] >0){
		$query = $this->db->get_where('reply',array('id_reply'=>$dataArr['id_reply']));
		$query_result= $query->row_array();
	  }else{
		//$sqlQuery = "SELECT cu.name AS user_name, cu.account_type AS user_type, cr.* FROM `cm_reply` AS cr INNER JOIN cm_users AS cu ON (cu.id = cr.user_id AND cu.status = 'Active') WHERE cr.id_request ='".$dataArr['id_request']."'";
		if($dataArr['reply_to'] !="" && $dataArr['reply_from'] !=""){
		    $sqlQuery = "SELECT cu.name AS user_name, cu.account_type AS user_type,cm_reply.* FROM cm_reply  AS cm_reply INNER JOIN cm_users AS cu ON   (cu.id = cm_reply.reply_from AND cu.status = 'Active') WHERE ( (cm_reply.reply_to = '".$dataArr['reply_to']."' AND  cm_reply.reply_from = '".$dataArr['reply_from']."') OR (cm_reply.reply_to = '".$dataArr['reply_from']."' AND  cm_reply.reply_from = '".$dataArr['reply_to']."') ) ";
		}else{
		    $sqlQuery = "SELECT cu.name AS user_name, cu.account_type AS user_type,cm_reply.* FROM cm_reply  AS cm_reply INNER JOIN cm_users AS cu ON   (cu.id = cm_reply.reply_from AND cu.status = 'Active') AND id_request = '".$dataArr['id_request']."'";
		}

		if(is_array($limit) && count ($limit)>0 ){
		    $sqlQuery .= " LIMIT ".$limit[1]. "," .$limit[0];
		}
		$query = $this->db->query($sqlQuery);
		$query_result= $query->result_array();
	  }
	  return $query_result;
    }

    /**
     *This function is used to add the reply content into database
     */
    public function saveReplyData($insertArray)
    {
	$this->db->insert('reply', $insertArray);
        return $this->db->insert_id();
    }

    /**
     *This function is used to get
     */
    public function getUserFollowingList($data)
    {
	  $resultArray =array();
	  $following_query = "SELECT cf.*, cu.name, cu.account_type, cu.image_name FROM `cm_followers` AS cf INNER JOIN cm_users AS cu ON (cu.id = cf.shop_id AND cu.status = 'Active' AND cu.account_type = 'shopowner') where cf.user_id = '".$data['user_id']."' AND cf.status = 'Following' ORDER BY cf.shop_id DESC";
	  
	  $query = $this->db->query($following_query);
	  $query_result= $query->result_array();
	  if(count($query_result)>0)
	  {
		foreach($query_result as $rs)
		{
		    $shop_product = $this->db->query("SELECT COUNT(id) AS shop_product FROM cm_products WHERE shop_id ='".$rs['shop_id']."' AND cstatus = 'Active'");
		    $rs['shop_product_count'] = $shop_product->row()->shop_product;
		    $shop_follower = $this->db->query("SELECT COUNT(id_follow) AS shop_follower FROM cm_followers INNER JOIN cm_users AS cm_users ON (cm_users.id = cm_followers.shop_id AND cm_users.status = 'Active') WHERE cm_followers.shop_id ='".$rs['shop_id']."' AND cm_followers.status = 'Following'");
		    $rs['shop_follower_count'] = $shop_follower->row()->shop_follower ;
		    $resultArray[] = $rs;
		}
	  }
	  //echo "<PRE>";
	  //print_r($resultArray);
	  //echo "</PRE>";
	  return $resultArray;
    }


	/**
     *This function is used to get
     */
    public function getRequestFollowingList($data)
    {
	  $resultArray =array();
	  $following_query = "SELECT re.id, re.user_id, re.id_category, re.title, re.price, re.request_image, re.description, rf.added_on FROM `cm_request_followers` AS rf
							INNER JOIN cm_request AS re ON (rf.request_id = re.id )
							where rf.user_id = '".$data['user_id']."' ORDER BY rf.id_follow DESC";
							
	  $query = $this->db->query($following_query); 
	  return $query_result= $query->result_array();
    }
	
public function shareIcons($product_link,$image_url=""){
	//<a href="https://api.addthis.com/oexchange/0.8/forward/instagram/offer?url='.urlencode($product_link).'" target="_blank"><img src="https://cache.addthiscdn.com/icons/v2/thumbs/32x32/instagram.png" border="0" alt="Instagram" title="Instagram"/></a>
	  
	  //<a href="https://api.addthis.com/oexchange/0.8/forward/facebook/offer?url='.urlencode($product_link).'" target="_blank"><img src="https://cache.addthiscdn.com/icons/v2/thumbs/32x32/facebook.png" border="0" alt="Facebook" title="Facebook"/></a>
	  //<a href="https://api.addthis.com/oexchange/0.8/forward/pinterest/offer?url='.urlencode($product_link).'" target="_blank"><img src="https://cache.addthiscdn.com/icons/v2/thumbs/32x32/pinterest.png" border="0" alt="Pinterest" title="Pinterest"/></a>
	  
	  
	  
	  $shareIcons = '<div class="sharebutton">
	  <a href="https://www.facebook.com/sharer/sharer.php?u='.($product_link).'" target="_blank"><img src="https://cache.addthiscdn.com/icons/v2/thumbs/32x32/facebook.png" border="0" alt="Facebook" title="Facebook"/></a>
	  
	  <a href="https://api.addthis.com/oexchange/0.8/forward/twitter/offer?url='.($product_link).'" target="_blank"><img src="https://cache.addthiscdn.com/icons/v2/thumbs/32x32/twitter.png" border="0" alt="Twitter" title="Twitter"/></a>
	  <a href="https://api.addthis.com/oexchange/0.8/forward/tumblr/offer?url='.($product_link).'" target="_blank"><img src="https://cache.addthiscdn.com/icons/v2/thumbs/32x32/tumblr.png" border="0" alt="Tumblr" title="Tumblr"/></a>
	  
	  <a href="https://in.pinterest.com/pin/create/button/?media='.$image_url.'" target="_blank"><img src="https://cache.addthiscdn.com/icons/v2/thumbs/32x32/pinterest.png" border="0" alt="Pinterest" title="Pinterest"/></a>
	  
	  </div>';
	  
	 return $shareIcons;
   }

	public function getProductImageById($id)
	{
	  $this->db->select('image');
	  $this->db->from('product_images');
	  $this->db->where('product_id',$id);
	  $query= $this->db->get();
	  $product_image = $query->row_array();
	  if(count($product_image)) {
		if(file_exists('uploads/product_image/thumb_'.$product_image['image']) && $product_image['image']) {
			$iamgeName = base_url().'uploads/product_image/thumb_'.$product_image['image'];
		} else {
			$iamgeName = base_url().'lib/images/no_product.png';
		}
	  } else {
		$iamgeName = base_url().'lib/images/no_product.png';
	  }
	  //echo $this->db->last_query();
	  return $iamgeName;
	}
	
	public function getReplyList($arr)
	{
	    
	     $request_sql ="SELECT * FROM (SELECT cm_users.name,cm_users.image_name,cm_users.account_type, cm_reply.* FROM `cm_reply` INNER JOIN cm_users AS cm_users ON (cm_users.id = cm_reply.reply_from AND cm_users.status ='Active' AND cm_users.id NOT IN(SELECT shop_id FROM cm_block_users WHERE user_id = '".$arr['user_id']."' AND status = 'Block' )) WHERE cm_reply.id_request = '".$arr['request_id']."' ORDER BY cm_reply.reply_date DESC) AS tmp_table  ORDER BY tmp_table.reply_date DESC";
	     if($arr['limit'])
	     {
		$request_sql .=" limit 0,".$arr['limit'];
	     }
	    //echo $request_sql;
	    $request_query = $this->db->query($request_sql);
	    $request_data =  $request_query->result_array();
	    
	    return $request_data;
	}
	public function getReplyDetail($arr)
	{
	    
	     $request_sql ="SELECT * FROM `cm_reply` where id_reply = '".$arr['id_reply']."'" ;
	    
	    $request_query = $this->db->query($request_sql);
	    $request_data =  $request_query->row_array();
	    
	    return $request_data;
	}
	public function getFeaturedProductByUserId($user_id,$limit)
	{
	    $result=array();
	    if($user_id>0)
	    {
		$sql ="SELECT * FROM `cm_products` where shop_id = '".$user_id."' and featured='yes' " ;
		
		$sql .=" order by id desc";
		
		if(is_array($limit))
		{
		    $sql .=" limit $limit[0],$limit[1]";
		}
		
		
		
		$sql = $this->db->query($sql);
		$product_data =  $sql->result_array();
		
		foreach($product_data as $val)
		{
		    $val['product_image'] = $this->webservice->getProductImageById($val['id']);
		    $res[]=$val;
		}
		$result=$res;
	    }
	    return $result;
	}
	
}
?>
