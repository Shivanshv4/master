<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model
{
   /**
    * Admin Model using is related to general functions to fetch
    * the information from database.
    *
    *
    * @category 	model
    * @package 	application_models
    * @version 	0.0.1
    * @author 	Singsys Pte. Ltd. <info@singsys.com>
    * dated  	2015-08-07
    */
   
     //class constructor
     public function __construct(){
	  parent::__construct();
     }
   
     /**
    *This function provides the admin data by admin name and password
    *@param string $username name of admin user
    *@param string $password password of admin user
    *@return array $admin_data
    */
     public function adminUserData($email,$password)
     {
	  $admin_data = array();
	  $this->db->from('admin');
	  $this->db->where('email',$email);
	  $this->db->where('password',md5($password));
	  $query= $this->db->get();
	  $admin_data = $query->row_array();
	  return $admin_data;
     }
   
     /**
    *This function provides the all users from database
    *@return array $admin_data
    */
     public function getAllUsersAdmin($user_id=0, $userType = '')
     {
	  $admin_data = array();
	  $query = "select * from cm_users where status!='Pending' ";
	  if($userType!="")
	  {
	       $query .=" and account_type='".$userType."' ";
	  }
	  $query .=" order by id desc";
	  $q = $this->db->query($query);
	  $admin_data = $q->result_array();
	  return $admin_data;
     }
   
     /**
      *This function provides the all users from database
      *@return array $admin_data
      */
     public function getAllUsers($whereClause,$limit=array())
     {
	  $this->db->select(array("users.*"));
	  $this->db->from('users');
	  if(is_array($whereClause) && count ($whereClause)){
	       $this->db->where($whereClause);
	  }
	  if(is_array($limit) && count ($limit) && !empty($limit[0]) ){
	    $this->db->limit($limit[0],$limit[1]);
	  }
	  $this->db->order_by('id','DESC');
	  $query=$this->db->get();
	  $result=$query->result_array();
       
	  return $result;
     }
   
     public function getuser_byid($user_id)
     {
	    $this->db->select(array("users.*"));
	    $this->db->from('users');
	       $this->db->where(array("id"=>$user_id));
	    $this->db->order_by('id','DESC');
	    $query=$this->db->get();
	    $result=$query->row_array();
       
	  
	return $result;
     }
   
     public function checkemail_byemail($u_email)
     {
	  if(empty($u_email))
	     return FALSE;
     
	  $this->db->select('email');
	  $this->db->from('users');
	  $this->db->where('email',$u_email);
	  $q = $this->db->get();
	  if($q->num_rows() > 0)
	  {
	     return TRUE;
	  }
	  return FALSE;
	  
     }
   
     /**
      *This function provides the all users from database
      *@return array $admin_data
      */
     public function getAllActiveUsers()
     {
	  $admin_data = array();
	  $this->db->where(array('status ='=>'Active'));
	  $this->db->order_by('name','ASC');
	  $query = $this->db->get('users');
	  $admin_data = $query->result_array();
	return $admin_data;
     }
   
     /**
      *This function provides the all users from database
      *@return array $admin_data
      */
     public function save_userData($userdata)
     {
	  unset($userdata['cpassword']);
	  if(isset($userdata['id']) && $userdata['id']>0){
	     $userId = $userdata['id'];
	     unset($userdata['id'],$userdata['account_type'],$userdata['password']);
	     $query = $this->db->update('users', $userdata ,array('id'=>$userId));
	     return $query;
	  }else{
	     $userdata['password'] = md5($userdata['password']);
	     $userdata['created_on'] = date('Y-m-d H:i:s');
	     $userdata['status'] = 'Active';
	     $this->db->insert('users', $userdata);
	     $userid = $this->db->insert_id();
	     return $userid;
	  }
     }
   
     /**
      *This function deletes the user details from database
      *@return array $admin_data
      */
     public function delete_userData($user_id)
     {
	  try{
	     $this->db->trans_begin();
	    
	     $delete_user = $this->db->delete("users",array('id'=> $user_id));
	     if ($this->db->trans_status() === FALSE)
	     {
		  $this->db->trans_rollback();
		  return FALSE;
	     }
	     else
	     {  
		  $this->db->trans_commit();
		  return TRUE;
	     }
	  }catch(Exception $ex){
	     return FALSE;
	  }
     }
   
     /**
      *This function returns the count of users by account type
      *@param string $account_type
      *@return int count
      */
     public function _getUserCountByType($account_type = "")
     {
	  if($account_type !="")
	  {
	     $this->db->select('count(id) AS user_count');
	     $query = $this->db->get_where('users',array('account_type'=>$account_type,'status !='=>'Pending'));
	     $count_type = $query->row_array();
	  }
	  else{
	     $this->db->select('count(id) AS user_count');
	     $query = $this->db->get('users');
	     $count_type = $query->row_array();
	  }
	  return $count_type;
     }
   
     /**
      *This function returns the count of contact
      *@return int count
      */
     public function _getContactCount()
     {
	  $this->db->select('count(id) AS contact_count');
	  $query = $this->db->get('contact');
	  $contact_count = $query->row()->contact_count;
	  return $contact_count;
     }
   
     /**
      *get all the configurations by key
      *@param string $key
      *$return string
      */
     public function getconfig($key ="")
     {
	  if($key !=""){
	     $this->db->select('value');
	     $query = $this->db->get_where('config',array('key'=>$key));
	     $data_array = $query->row_array();
	     return $data_array['value'];
	  }else{
	     $query = $this->db->get('config');
	     $data_array = $query->result_array();
	     return $data_array;
	  }
	  
     }
   
     public function update_admin($dataArr,$id)
     {
	  $query = $this->db->update('admin', $dataArr ,array('id'=>$id));
	  if($query)
	       return TRUE;
	  else
	       return FALSE;
     }
     /**
     *get all the configurations by key
     *@param string $key
     *$return string
     */
     public function _getConfigurationAllArray()
     {
	  $config_array = array();
	  $query = $this->db->get('config');
	  $data_array = $query->result_array();
	  foreach($data_array as $key=>$val)
	     {
		$config_array[$val['key']] = $val['value'];
	     }
	  return $config_array;
     
     }

     /**
      *This function is used to check the configuration key exists
      */
     public function _checkConfigurationKeyExists($key)
     {
	  $query = $this->db->get_where('config',array('key'=>$key));
	  $data_array = $query->num_rows();
	  return $data_array > 0 ? TRUE : FALSE;
     }

     /**
      *Check whether user exists or not
      *@param string $u_email, int $user_id
      *@return boolean
      */
     public function user_email_exist($u_email,$user_id = "")
     {
	  if(empty($u_email))
	     return FALSE;
     
	  $this->db->select('email');
	  $this->db->from('users');
	  $this->db->where('email',$u_email);
	  $this->db->where('status !=','Pending');
	  //$this->db->where('status !=','Active');
	  if(!empty($user_id)){
	     $this->db->where('id !=',$user_id);
	  }
	  $q = $this->db->get();
	  if($q->num_rows() > 0)
	  {
	     return TRUE;
	  }
	  return FALSE;
     }
   
  
   
     /**
     *Check whether user exists or not
     *@param string $u_email, int $user_id
     *@return boolean
     */
     public function changeStatus($user_id,$status)
     {
	 if(empty($user_id))
	    return FALSE;
     
	 $query = $this->db->update('users', array('status'=>$status) ,array('id'=>$user_id));
	 return $query;
     }   
    
     public function updateFeatured($user_id,$status)
     {
	  $date = date("Y-m-d H:i:s");
	  if(empty($user_id))
	    return FALSE;
	   
	  $user_data = $this->webservice_model->getUserDetails($user_id);
	  $featured_count = $user_data['featured_count']+1;
	  $query = $this->db->update('users', array('featured_profile'=>"Yes","featured_profileon"=>$date,"featured_count"=>$featured_count) ,array('id'=>$user_id));
	  //echo $this->db->last_query();  die;
	  return $query;
     }
     public function insertFeaturedHistory($insertArray)
     {
	 $this->db->insert('featured_profile_history', $insertArray);
	 return  $this->db->insert_id();
     }
     public function insertReset($insertArray)
     {
	 $this->db->insert('resetstats', $insertArray);
	 return  $this->db->insert_id();
     }
     public function getlastReset()
     {
	  $this->db->select('*');
	  $this->db->order_by('id','DESC');
	  $q = $this->db->get('resetstats');
	  
	  $details = $q->row_array();
     
	  if(count($details) > 0)
	     return $details;
     
	  return FALSE;
     }
   
     /**
      *This function is used to list the static content pages
      *@param string $title_name
      *@return array
      */
     public function getStaticContent($content_id=0)
     {
	  $content_array = array();
	  if($content_id >0){
	     $query = $this->db->get_where('static_content',array('id'=>$content_id));
	     $content_array = $query->row_array();
	  }else{
	     $this->db->order_by('id','ASC');
	     $query = $this->db->get('static_content');
	     $content_array = $query->result_array();
	  }
	  return $content_array;
     }
   
     /**
     *This function is used to list the static content pages
     *@param string $title_name
     *@return array
     */
     public function getmessageConfig($content_id=0)
     {
	 $content_array = array();
	 if($content_id >0){
	    $query = $this->db->get_where('message_config',array('id'=>$content_id));
	    $content_array = $query->row_array();
	 }else{
	    $this->db->order_by('id','ASC');
	    $query = $this->db->get('message_config');
	    $content_array = $query->result_array();
	 }
	 return $content_array;
     }
   
     /**
      *This function is used to add content data
      *@param array $productdata
      *@return int
      */
     public function save_contentData($contentdata)
     {
	  if(isset($contentdata['id']) && $contentdata['id']>0){
	     $productId = $contentdata['id'];
	     $query = $this->db->update('static_content', $contentdata ,array('id'=>$productId));
	     return $query;
	  }else{
	     $this->db->insert('static_content', $contentdata);
	     $product_id = $this->db->insert_id();
	     return $product_id;
	  }
     }
     
     public function save_messageconfig($contentdata)
     {
	  if(isset($contentdata['id']) && $contentdata['id']>0){
	     $productId = $contentdata['id'];
	     $query = $this->db->update('message_config', $contentdata ,array('id'=>$productId));
	     return $query;
	  }else{
	     $this->db->insert('message_config', $contentdata);
	     $product_id = $this->db->insert_id();
	     return $product_id;
	  }
     }
     /**
      *This function returns the count of users by account type
      *@param string $account_type
      *@return int count
      */
      public function _getAllUserByType($account_type = "")
     {
	  if(is_array($account_type) && count ($account_type)){
		 $query = $this->db->get_where('users',$account_type);
		 $count_type = $query->result_array();
	  } else {
		 $query = $this->db->get('users');
		 $count_type = $query->result_array();
	  }
	  return $count_type;
	  
     }

     /**
      *Change status of static content
      *@param string $status, int $content_id
      *@return boolean
      */
     public function changeContentStatus($content_id,$status)
     {
	  if(empty($content_id))
	     return FALSE;
     
	  $query = $this->db->update('static_content', array('status'=>$status) ,array('id'=>$content_id));
	  return $query;
     }
   
     public function changeMessageStatus($content_id,$status)
     {
	 if(empty($content_id))
	    return FALSE;
     
	 $query = $this->db->update('message_config', array('status'=>$status) ,array('id'=>$content_id));
	 return $query;
     }
   
     /**
      *This function is used to save/update the system configurations
      *@param $configArray
      *@return int
      */
     public function save_configData($configArray)
     {
	  if(count($configArray) >0){
	     foreach($configArray as $key=>$value)
	     {
		  if($this->_checkConfigurationKeyExists($key) == TRUE){
		     $query = $this->db->update('config', array('value'=>$value) ,array('key'=>$key));
		  }else{
		     $data= array('key'=>$key,'value'=>$value);
		     $this->db->insert('config', $data);
		     $config_id = $this->db->insert_id();
     
		  }
	     }
	     return $config_id;
	  }
     }

     /**
      *This function is used to get list of all user contacts
      *@return array
      */
     public function getAllContacts($id=0,$type="")
     {
	  $cdata =array();	
	  $this->db->select("contact.*,adv_plan.adv_name");
	  $this->db->from('contact');
	  $this->db->join('adv_plan as adv_plan','adv_plan.id = contact.plan_id','left');
	  
	  if(!empty($type))
	  {
	    $this->db->where('contact.type', $type);
	  }
	  if($id >0)
	  {
	    $this->db->where('contact.id', $id);
	    $query= $this->db->get();	   
	    $cdata = $query->row_array();
	  }
	  else{
	    $this->db->order_by('contact.id','DESC');
	    $query= $this->db->get();	   
	    $cdata=$query->result_array();
	  }
	  //echo $this->db->last_query();
	  return $cdata;
     }
   
     /**
      *This function deletes the user details from database
      *@return array $admin_data
      */
     public function delete_contactData($id_contact)
     {
	  $delete_contact = $this->db->delete("contact",array('id'=> $id_contact));
	  return $delete_contact;
     }
   
     /**
      *this function is used to update admin user profile
      *@param $insertArr
      *@return int
      */
     public function updateAdminUser($insertArr)
     {
	   unset($insertArr['confirm_password']);
	  if(!empty($insertArr['password'])){
	     $insertArr['password'] = md5(trim($insertArr['password']));
	  }
	  
	  $query = $this->db->update('admin', $insertArr ,array('id'=>$insertArr['id']));
	  return $query;
     }
   
     /**
     *this function is used to update admin user profile
     *@param $insertArr
     *@return int
     */
     public function updateAdminPassword($insertArr)
     {
	 unset($insertArr['c_password']);
	 $insertArr['password'] = md5(trim($insertArr['password']));
	 $query = $this->db->update('admin', $insertArr ,array('id'=>1));
	 return $query;
     }
   
     /**
      *This function is used to get admin user profile data
      *@param $id user id
      *@return array
      */
     public function _getAdminDataById($id)
     {
	  $query = $this->db->get_where('admin',array('id'=>$id));
	  return $query->row_array();
     }
   
     /**
      *This function is used to get admin user profile data
      *@param $id user id
      *@return array
      */
     public function _getAdminDataByEmail($email)
     {
	  $query = $this->db->get_where('admin',array('email'=>$email));
	  return $query->row_array();
     }

     /**
      *This function is used to get the counrty detials by country id
      *@param int $id
      *@return array
      */
     public function _getCountryDetailsById($id)
     {
	  $data_array = array();
	  $data_array = $this->db->get_where('country', array('id'=>$id))->row_array();
	  return $data_array;
     }
   
   ///////////////////////////// category functions
   
   /**
    *this method returns the all categories
    *@param $status
    *@return array
    */
     public function getCategoryList($status="",$limit=array())
     {
	 $category_data = array();
	 if($status !="" && $status != 'Deleted'){
	    $this->db->where('category_status',$status);
	 }else{
	    $this->db->where('category_status !=','Deleted');
	 }
	 $this->db->order_by('cat_order','ASC');
	 if(is_array($limit) && count ($limit)>0){
	    $this->db->limit($limit[0],$limit[1]);
	 }
       $query= $this->db->get('category');
	 $category_data = $query->result_array();
       return $category_data;
     }
   
    /**
    *This function is used to get the category data on basis of category id
    *@param $id category id
    *@return array
    */
     public function GetCategoryById($id = '')
     {
	  $category_data =array();
	  if($id >0) {
	     $this->db->where('id_category =',$id);
	     $query= $this->db->get('category');
	     $category_data = $query->row_array();
	  }
	  return $category_data;
     }
    /**
    *This function is used to add category data
    *@param array $productdata
    *@return int
    */
     public function save_categoryData($categorydata)
     {
	  if(isset($categorydata['id_category']) && $categorydata['id_category']>0){
	     $categoryId = $categorydata['id_category'];
	     $categorydata['updated_on']= date('Y-m-d H:i:s');
	     $query = $this->db->update('category', $categorydata ,array('id_category'=>$categoryId));
	     return $query;
	  }else{
	     unset($categorydata['id_category']);
	     $categorydata['added_on']= date('Y-m-d H:i:s');
	     $categorydata['updated_on']= date('Y-m-d H:i:s');
	     $this->db->insert('category', $categorydata);
	     $category_id = $this->db->insert_id();
	     return $category_id;
	  }
     }
   
    /**
    *change category status
    *@param string $status, int $id_category
    *@return boolean
    */
     public function changeCatgoryStatus($id_category,$status)
     {
	  if(empty($id_category))
	     return FALSE;
	  
	  if($status == 'Deleted')
	  {
	     $p_query = $this->db->update('products', array('id_category'=>'0') ,array('id_category'=>$id_category));
	  }
	  $query = $this->db->update('category', array('category_status'=>$status) ,array('id_category'=>$id_category));
	  return $query;
     }
   ///////////////////////
   
}
?>
