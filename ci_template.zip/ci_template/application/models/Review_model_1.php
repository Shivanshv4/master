<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Review_model extends CI_Model
{
   /**
    * Product Model using is related to general functions to fetch
    * the information from database.
    *
    *
    * @category 	model
    * @package 	application_models
    * @version 	0.0.1
    * @author 	Singsys Pte. Ltd. <info@singsys.com>
    * dated  	2015-08-07
    */
   
   //class constructor
   public function __construct(){
	parent::__construct();
   }
   
   /**
    *this method returns the all reviews under a shop owner
    *@param $shop_id
    *@return array
    */
   public function getShopReviews($shop_id,$status="")
   {
	$product_data = array();
	$this->db->where('shop_id',$shop_id);
	if($status !=""){
	   $this->db->where('cstatus',$status);
	}
      $query= $this->db->get('reviews');
	$product_data = $query->result_array();
      return $product_data;
   }
   
}?>