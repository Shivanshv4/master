<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Webservice_model extends CI_Model
{
   /**
    *@category 	model
    *@package 	application_models
    *@author 	Singsys Pte. Ltd. (00130) <info@singsys.com>
    *@version 	0.0.1
    *dated  	2015-08-06
    */

   public function __construct() {
	   $this->load->database();
   }

/////////// used functions   
   public function _getCountryList()
   {
	$country_list = array();
	$query = $this->db->get('country');
	$country_list = $query->result_array();
	return $country_list;
   }
   
   public function add_otp($mobile)
   {
	if(!empty($mobile))
	{
		$date = date('Y-m-d H:i:s');
		$otp = generate_otp();
		
		$dataArr['mobile'] =  $mobile;
		$dataArr['addedon'] =  $date;
		$dataArr['otp'] =  $otp;
		$this->db->insert('user_otp', $dataArr);
		$insert_id = $this->db->insert_id();
		if($insert_id)
			return $otp;
		else
			return 0;
	}
	return FALSE;
   }
   public function update_otp($mobile,$otp)
   {
	if(!empty($mobile))
	{
		$insertArray=array("expired"=>1);
		$insert_id = $this->db->update('user_otp', $insertArray, array('mobile'=>$mobile,"otp"=>$otp));
		if($insert_id)
			return $insert_id;
		else
			return FALSE;
	}
	return FALSE;
   }
   public function _otpcount($mobile)
   {
	$data = array();
	$this->db->select('count(*) as count');
	$this->db->from('user_otp');
	$this->db->where('mobile',$mobile);
	$query = $this->db->get();
	$data = $query->row_array();
	if($data['count']>0)
		return $data['count'];
	else
		return 0;
   }
   public function isvalidotp($mobile,$otp)
   {
	$data = array();
	$this->db->select('otp,addedon');
	$this->db->from('user_otp');
	$this->db->where('mobile',$mobile);
	$this->db->order_by('id desc');
	$query = $this->db->get();
	$data = $query->row_array();
	
	$date = date('Y-m-d H:i:s');
	
	$dif = dateDifference($date,$data['addedon']);
	
	if($data['otp']==$otp && $dif['minutes_total']<10)
		return TRUE;
	else
		return FALSE;
   }
    public function signup($insertArray)
   {
	if(!empty($insertArray))
	{
		$date = date('Y-m-d H:i:s');
		$dataArr['created_on'] =  $date;
		$this->db->insert('users', $dataArr);
		$insert_id = $this->db->insert_id();
		if($insert_id)
			return $insert_id;
		else
			return 0;
	}
	return FALSE;
   }
   public function getUserDetails($user_id)
   {
	   $userData = array();
	   if($user_id >0){
		   $query = $this->db->get_where('users', array('id' => $user_id));
		   $userData = $query->row_array();
	   }
	   return $userData;
   }
/////////////////////////// end functions

   /**
    *This function is used to add/update the user details
    *@param array $posted data
    *@return int val
    */
   public function CheckUserBlockForChat($insertArray)
   {
	$sql_query = "SELECT COUNT(id_block) AS total_row FROM cm_block_users WHERE status = 'Block' AND (shop_id ='".$insertArray['from_id']."' OR user_id = '".$insertArray['from_id']."' ) AND  (shop_id ='".$insertArray['to_id']."' OR user_id = '".$insertArray['to_id']."' )" ;
	$totalProduct_query = $this->db->query($sql_query);
	return  (int)$totalProduct_query->row()->total_row ;
   }

   /**
    *This function is used to add/update the user details
    *@param array $posted data
    *@return int val
    */
   public function create_user($insertArray)
   {
	if(isset($insertArray['user_id']) && $insertArray['user_id'] >0){
	   $user_id = $insertArray['user_id'];
	   unset($insertArray['user_id']);
	   $query = $this->db->update('users', $insertArray, array('id'=>$user_id));
	   return  $query;
	}else{
	   $delete_user = $this->db->delete("users",array('email'=> $insertArray['email'], 'status ='=>'Pending'));
	   $this->db->insert('users', $insertArray);
	   return  $this->db->insert_id();
	}
   }
   
	public function setrequestfollow($insertArray)
	{
		if($insertArray['type'] == 'unfollow'){
			$delete_user = $this->db->delete("request_followers",array('request_id'=> $insertArray['request_id'], 'user_id'=> $insertArray['user_id']));
		}else{
			$this->db->select('id_follow');
			$this->db->from('request_followers');
			$this->db->where('request_id',$insertArray['request_id']);
			$this->db->where('user_id',$insertArray['user_id']);
			$q = $this->db->get();
			if($q->num_rows() < 1)	{	
				unset($insertArray['type']);
				$insertArray['added_on'] = date('Y-m-d H:i:s');
				$this->db->insert('request_followers', $insertArray);
			}
		}
		return '';
	}
	
	public function setWishlistStatus($insertArray)
	{
		if($insertArray['type'] == 'delete'){
			$delete_user = $this->db->delete("wishlist",array('product_id'=> $insertArray['product_id'], 'user_id'=> $insertArray['user_id']));
		}else{
			$this->db->select('id');
			$this->db->from('wishlist');
			$this->db->where('product_id',$insertArray['product_id']);
			$this->db->where('user_id',$insertArray['user_id']);
			$q = $this->db->get();
			if($q->num_rows() < 1)	{	
				unset($insertArray['type']);
				$insertArray['added_on'] = date('Y-m-d H:i:s');
				$this->db->insert('wishlist', $insertArray);
			}
		}
		return '';
	}
	

	public function productFeatured($insertArray)
	{
		if(count($insertArray)){
			$shop_id 	= $insertArray['shop_id'];
			$product_id = $insertArray['product_id'];
			unset($insertArray['shop_id']);
			unset($insertArray['product_id']);
			$query = $this->db->update('products', $insertArray, array('shop_id'=>$shop_id, 'id'=>$product_id ));
			//echo $this->db->last_query();
			return true;
		} else {
			return false;
		}
	}

	public function getWishlistProudcts($user_id)
	{
		$product_data = array();
		$this->db->select('products.*');
		$this->db->from('products');
		$this->db->select('users.name as shop_owner');
		//$this->db->select('category.category_name');
		$this->db->join('users','users.id = products.shop_id','inner');
		$this->db->join('wishlist','wishlist.product_id = products.id','inner');
		$this->db->where('wishlist.user_id',$user_id);
		
		$this->db->order_by('wishlist.id','DESC');
		$query= $this->db->get();
		$product_data = $query->result_array();
		//echo $this->db->last_query();
		foreach($product_data as $rs)
		{
			$rs['productimages'] = $this->webservice->get_product_image($rs['id']);
			$dataArr[] = $rs;
		}
		
		return $dataArr;
	}
	
	public function getWishlistStatus($product_id, $user_id)
	{
		$data = '';
		$this->db->select('id');
		$this->db->from('wishlist');
		$this->db->where('product_id',$product_id);
		$this->db->where('user_id',$user_id);
		$q = $this->db->get();
		if($q->num_rows() > 0)	{	
			$data = 'added';
		}
		return $data;
	}
   
   /**
    *This function is used to add/update the user details
    *@param array $posted data
    *@return int
    */
   public function createUserByFb($insertArray)
   {
	if($insertArray['is_verified'] == 'Yes'){
	   $insertArray['status'] = 'Active';
	}else{
	   $insertArray['status'] = 'Pending';
	}
	unset($insertArray['is_verified']);
	if(trim($insertArray['fb_id']) == ""){
	   return 0;
	}
	$user_fdetails = $this->db->get_where('users',array('fb_id '=>trim($insertArray['fb_id'])))->row_array();
	if(count($user_fdetails) >0){
	   $query = $this->db->update('users', $insertArray, array('id'=>$user_fdetails['id']));
	   return  $user_fdetails['id'];
	}
	else
	{
	   if(trim($insertArray['email']) !=""){
		$user_details = $this->db->get_where('users',array('email '=>trim($insertArray['email'])))->row_array();
		if(count($user_details) >0){
		   if($user_details['status'] == 'Pending'){
			//$delete_user = $this->db->delete("users",array('id'=> $user_details['id']));
			$query = $this->db->update('users', $insertArray, array('id'=>$user_details['id']));
			return  $user_details['id'];
		   }else{
			$query = $this->db->update('users', $insertArray, array('id'=>$user_details['id']));
			return  $user_details['id'];
		   }
		}
		else{
		   $this->db->insert('users', $insertArray);
		   return  $this->db->insert_id();
		}
	   }
	}
   }
   
   public function _getUser_by_fb_id($fb_id = FALSE)
   {
	   if($fb_id === FALSE)
		   return FALSE;

	   $query = $this->db->get_where('users', array('fb_id' => $fb_id));
	   return $query->row_array();
   }
	
   public function update_user($id,$updatArray){
	   $this->db->where('id', $id);
	   $query = $this->db->update('users', $updatArray);
	   return  $query;
   }
   
   /**
    *This function is used to check whether the user email exists or not
    *@param string $email, int $user_id, string $status
    *return boolean
    */
   public function sg_email_exist($u_email,$user_id = 0,$status="")
   {
	if(empty($u_email)){
	   return FALSE;
	}
	else
	{
	   $this->db->select('email');
	   $this->db->from('users');
	   $this->db->where('email',$u_email);
	   if($status !=""){
		$this->db->where('status !=',$status);
	   }
	   if($user_id >0){
		$this->db->where('id !=',$user_id);
	   }
	   $q = $this->db->get();
	   if($q->num_rows() > 0)
	   {
		return TRUE;
	   }
	}
	return FALSE;
   }

   public function sg_fb_id_exist($fb_id, $email = ''){
	   if(empty($fb_id))
		 return false;

	   $this->db->select('*');
	   $this->db->from('users');

	   if($fb_id && $email ) {
		$where = " fb_id='".$fb_id."' OR email='".$email."'";
		$this->db->where($where);
	   } else {
		$this->db->where('fb_id',$fb_id);
	   }
	   $q = $this->db->get();
		//echo $this->db->last_query();

	   if($q->num_rows() > 0)
	   {
		 return TRUE;
	   }
	   return FALSE;
   }
   public function get_fb_id_exist($fb_id, $email = ''){
	$q = array();
	   if(empty($fb_id))
		 return $q;

	   $this->db->select('*');
	   $this->db->from('users');

	   if($fb_id && $email ) {
		$where = " fb_id='".$fb_id."' OR email='".$email."'";
		$this->db->where($where);
	   } else {
		$this->db->where('fb_id',$fb_id);
	   }
	   $query = $this->db->get(); // row_array
	   $q = $query->row_array();

		//echo $this->db->last_query();
		return $q;


   }
	
   public function user_exist($email,$password){
	   if(empty($email) && empty($password))
		 return false;

	   $query = $this->db->get_where('users', array('slug' => $slug));

	   if($q->num_rows() > 0)
	   {
		 return TRUE;
	   }
	   return FALSE;
   }
   
   public function get_news($slug = FALSE)
   {
	   if ($slug === FALSE)
	   {
		   $query = $this->db->get('users');
		   return $query->result_array();
	   }

	   $query = $this->db->get_where('users', array('slug' => $slug));
	   return $query->row_array();
   }
	
   public function _getMessage($opt)
   {
	   $this->db->select('subject, content');
	   $this->db->where('title', $opt);
	   $q = $this->db->get('message_config');
	   
	   if($q->num_rows() > 0)
	   {
		 return $q->row();
	   }
	   return array();
   }
   
   
   
   public function shop_product_image($insertArray)
   {
	   $insertArray['addedon'] =   date('Y-m-d H:i:s');
	   $this->db->insert('product_images', $insertArray);
	   return  $this->db->insert_id();	
   }
   
   public function get_product_image($productId)
   {
	   $this->db->select('*');
	   $this->db->from('product_images');
	   $this->db->where('product_id',$productId);
	   $query= $this->db->get();
	   $product_images = $query->result_array();
	   
	   return $product_images;
   }
   
   public function get_product_image_by_id($id)
   {
	   $this->db->select('*');
	   $this->db->from('product_images');
	   $this->db->where('id',$id);
	   $query= $this->db->get();
	   $product_images = $query->row_array();
	   
	   return $product_images;
   }
   
	public function getProductImageById($id)
	{
		$iamgeName = '';
		
		$this->db->select('image');
		$this->db->from('product_images');
		$this->db->where('product_id',$id);
		$query= $this->db->get();
		$product_image = $query->row_array();
		
		if(file_exists('uploads/product_image/'.$product_image['image']) && $product_image['image'])
		{
			$iamgeName = $product_image['image'];
		} 
		
		return $iamgeName;
	}
   
   public function create_shop_product($insertArray)
   {
	if(isset($insertArray['id']) && $insertArray['id'] >0){
	   $product_id = $insertArray['id'];
	   unset($insertArray['id']);
	   $insertArray['updated_on'] =   date('Y-m-d H:i:s');
	   $query = $this->db->update('products', $insertArray, array('id'=>$product_id));
	   return  $query;
	}else{
	   $insertArray['added_on'] =   date('Y-m-d H:i:s');
	   $insertArray['updated_on'] =   date('Y-m-d H:i:s');
	   $this->db->insert('products', $insertArray);
	   return  $this->db->insert_id();	
	}
   }
   public function GetProductById($id = '', $user_id=''){
	$admin_data =array();
	// function to get wishlist status
	$wishlistStatus = $this->getWishlistStatus($id, $user_id);
	if($id >0) {
	   $this->db->select('products.*');
	   $this->db->from('products');
	   //$this->db->select('users.name as shopowner_name, users.address as shopowner_address, users.image_name as shopowner_image');
	   $this->db->select('users.name as shopowner_name, users.address as shopowner_address, users.image_name as shopowner_image');
	   $this->db->join('users','users.id = products.shop_id','inner');
	   $this->db->where('products.id',$id);
	   $query= $this->db->get();
	   $admin_data = $query->row_array();
	   
	   $time_zone = getUserLocalTimeZone($user_id);
	   
	   $admin_data['added_on'] = $admin_data['added_on'] !="" ? agoTimePost($admin_data['added_on'],$time_zone) :"";
	   $admin_data['updated_on'] = $admin_data['updated_on'] !="" ? agoTimePost($admin_data['updated_on'],$time_zone) :"";
	   $admin_data['image'] = $this->webservice->getProductImageById($id);
	   $admin_data['productimages'] = $this->webservice->get_product_image($id);
	   $admin_data['wishlist_status'] = $wishlistStatus;
	   
	   global $product_type;
	   $admin_data['product_type'] = $product_type[$admin_data['product_type']];
	}
	return $admin_data;
   }
   /**
    *This function is used to save the review data into database
    *@param requested data
    *@return array
    */
   public function create_product_review($insertArray)
   {
	if(isset($insertArray['id']) && $insertArray['id'] >0){
	   $review_id = $insertArray['id'];
	   unset($insertArray['id']);
	   $query = $this->db->update('reviews', $insertArray, array('id'=>$review_id));
	   //return  $query;
	}else{
		$this->db->insert('reviews', $insertArray);
		$review_id = $this->db->insert_id();	
	}
	if($review_id){
		$query = $this->db->get_where('reviews', array('id' => $review_id));
		return $query->row_array();
	}
   }
   
   
   public function edit_product_review($insertArray)
   {
	if(isset($insertArray['id']) && $insertArray['id'] >0){
	   $review_id = $insertArray['id'];
	   $user_id = $insertArray['user_id'];
	   unset($insertArray['id']);
	   unset($insertArray['user_id']);
	   $query = $this->db->update('reviews', $insertArray, array('id'=>$review_id, 'user_id' => $user_id));
	}
	if($review_id){
		$query = $this->db->get_where('reviews', array('id' => $review_id));
		return $query->row_array();
	}
   }
   /**
    *this method returns the all reviews under a shop owner posted for a product
    *@param $insertArr
    *@return array
    */
   public function getProductShopReviews($insertArr =array())
   {

	//print_r($insertArr);
	$product_data = array();
	if(count($insertArr)>0){
	   $this->db->select("reviews.*, DATE_FORMAT(cm_reviews.add_on, '%d %m, %Y') AS posted_on");
	   $this->db->from('reviews');
	   $this->db->select('reviewer.name as reviewer_name,reviewer.image_name AS reviewer_image');
	   $this->db->join('users as reviewer','reviewer.id = reviews.user_id','inner');
	   $this->db->select('shopowner.name AS shopowner_name');
	   $this->db->join('users as shopowner','shopowner.id = reviews.shop_id','inner');
	   $this->db->select('products.name AS product_name, products.image AS product_image');
	   $this->db->join('products as products','products.id = reviews.product_id','inner');

	   $this->db->where('1','1');

	   if($insertArr['action'] != 'productreview') {
		if($insertArr['account_type'] == 'consumer') {
			$this->db->where('reviews.user_id',$insertArr['shop_id']);
		} else {
		     $this->db->where('reviews.shop_id',$insertArr['shop_id']);
		}
	   }

	   if($insertArr['product_id'] > 0){
		$this->db->where('reviews.product_id',$insertArr['product_id']);
	   }
	   if($insertArr['status'] !=""){
		$this->db->where('reviews.cstatus',$insertArr['status']);
	   }

	   $this->db->order_by('reviews.id','DESC');
	   $query= $this->db->get();
	   //echo "<br/><br/>". $this->db->last_query();
	   $product_data = $query->result_array();
	   
		foreach($product_data as $rs)
		{
			//$rs['product_image_all'] = array();
			$iamgeName = $this->webservice->get_product_image($rs['product_id']);

			if(count($iamgeName)) {
				$rs['product_image'] = $iamgeName[0]['image'];
				//$rs['product_image_all'] = $iamgeName;
			}
			$rs['add_on'] = $rs['add_on'] !="" ? agoTimePost($rs['add_on']) :"";
			///$rs['posted_on'] = $rs['posted_on'] !="" ? agoTimePost($rs['posted_on']) :"";
			$data[] = $rs;
		}
	}
      return $data;
   }
   /**
    *this method returns the all reviews posted for shop owner
    *@param $insertArr
    *@return array
    */
   public function getShopReviews($insertArr =array())
   {

	//print_r($insertArr);
	$product_data = array();
	if(count($insertArr)>0){
	   $this->db->select("reviews.*, DATE_FORMAT(cm_reviews.add_on, '%d %m, %Y') AS posted_on");
	   $this->db->from('reviews');
	   $this->db->select('reviewer.name as reviewer_name,reviewer.image_name AS reviewer_image');
	   if(!empty($insertArr['user_id'])) {
	   $this->db->join('users as reviewer','reviewer.id = reviews.shop_id','inner');
	   }
	   else{
		$this->db->join('users as reviewer','reviewer.id = reviews.user_id','inner');
	   }
	   $this->db->select('shopowner.name AS shopowner_name');
	   
	   $this->db->join('users as shopowner','shopowner.id = reviews.shop_id','inner');
	   
	   //$this->db->select('products.name AS product_name, products.image AS product_image');
	   //$this->db->join('products as products','products.id = reviews.product_id','inner');

	   $this->db->where('1','1');

	        if(!empty($insertArr['user_id'])) {
			$this->db->where('reviews.user_id',$insertArr['user_id']);
		}
		if(!empty($insertArr['shop_id']))
		{
		$this->db->where('reviews.shop_id',$insertArr['shop_id']);
		}
	   

	//   if($insertArr['product_id'] > 0){
	//	$this->db->where('reviews.product_id',$insertArr['product_id']);
	//   }
	   if($insertArr['status'] !=""){
		$this->db->where('reviews.cstatus',$insertArr['status']);
	   }

	   $this->db->order_by('reviews.id','DESC');
	   $query= $this->db->get();
	   //echo "<br/><br/>". $this->db->last_query();
	   $product_data = $query->result_array();
	   
	    $time_zone = getUserLocalTimeZone($insertArr['user_id']);
	   
		foreach($product_data as $rs)
		{
			//$rs['product_image_all'] = array();
			/*
			$iamgeName = $this->webservice->get_product_image($rs['product_id']);

			if(count($iamgeName)) {
				$rs['product_image'] = $iamgeName[0]['image'];
				//$rs['product_image_all'] = $iamgeName;
			}
			*/
			$rs['add_on'] = $rs['add_on'] !="" ? agoTimePost($rs['add_on'],$time_zone) :"";
			///$rs['posted_on'] = $rs['posted_on'] !="" ? agoTimePost($rs['posted_on']) :"";
			$data[] = $rs;
		}
	}
      return $data;
   }
   
   /**
    *this method returns the all reviews posted for shop owner
    *@param $insertArr
    *@return array
    */
   public function getShopReviewsByUserId($user_id,$shop_id)
   {

	$data = array();
	if($user_id>0 && $shop_id>0){
		$this->db->select("reviews.*");
		$this->db->from('reviews');
		$this->db->where('reviews.user_id',$user_id);
		$this->db->where('reviews.shop_id',$shop_id);
		
		$this->db->order_by('reviews.id','DESC');
		$query= $this->db->get();
		//echo "<br/><br/>". $this->db->last_query();
		$product_data = $query->result_array();
		
		if(!empty($product_data))
		$data = $product_data[0];
	}
      return $data;
   }
    /**
    *This function is used to detail the static content pages
    *@param string $title_name
    *@return array
    */
   public function getStaticContentByVariable($insertArr = 0)
   {
	$variable_name = $insertArr['variable_name'];
	$content_array = array();
	if($variable_name){
	   $query = $this->db->get_where('static_content',array('variable_name'=>$variable_name));
	   $content_array = $query->row_array();
	}
	return $content_array;
   }


   /**
    *This function is used to follow/unfollow user
    *@param array $dataArr
    *@return int
    */
   public function update_userFollowing($dataArr)
   {
	$query_follow = $this->db->get_where('followers',array('user_id '=>$dataArr['user_id'], 'shop_id'=>$dataArr['shop_id']));
	$exist_follow = $query_follow->row_array();
	if($exist_follow && $exist_follow['id_follow'] >0){
	   $follow_query1 = $this->db->update('followers', $dataArr, array('id_follow'=>$exist_follow['id_follow']));
	   $follow_query = $exist_follow['id_follow'];
	}else{
	   $dataArr['added_on'] = date('Y-m-d H:i:s');
	   $this->db->insert('followers', $dataArr);
	   $follow_query = $this->db->insert_id();	
	}
	return $follow_query;
   }
   
    /**
    *This function is used to get all followers
    *@param array $dataArr
    *@return int
    */
   public function get_shopFollowers($dataArr)
   {
	$follower_data = array();  // IF(shopowner.address IS NULL, '',shopowner.address) as shopowner_address
	$this->db->select('followers.*');
	$this->db->from('followers');
	$this->db->select('follower.name as follower_name, follower.image_name as follower_image, follower.address as follower_address, follower.account_type AS follower_account_type');
	$this->db->join('users as follower','follower.id = followers.user_id','inner');
	$this->db->select("shopowner.name AS shopowner_name, shopowner.address as shopowner_address, shopowner.image_name as shopowner_image , shopowner.account_type AS shopowner_account_type");
	$this->db->join('users as shopowner','shopowner.id = followers.shop_id','inner');
	
	if($dataArr['followers'] =="shop_followers"){
	   $this->db->where('followers.shop_id',$dataArr['shop_id']);
	}elseif($dataArr['followers'] =="user_following"){
	   $this->db->where('followers.user_id',$dataArr['user_id']);
	}
	if($dataArr['status'] !=""){
	   $this->db->where('followers.status',$dataArr['status']);
	}
      $this->db->order_by('followers.id_follow','DESC');
      $query= $this->db->get();
	$follower_data = $query->result_array();
	//echo $this->db->last_query();
      return $follower_data;
   }
   
   /**
    *This funstion is used to get user list by account type
    *@param array $dataArray
    *@return array
    */
   public function getUserByType($dataArray)
   {
	$user_list = array();
	if(count($dataArray) >0)
	{
	   $this->db->select('*');
	   if($dataArray['account_type'] !="")
	   {
		$this->db->where('account_type =',$dataArray['account_type']);
	   }
	   if($dataArray['status'] !="")
	   {
		$this->db->where('status =',$dataArray['status']);
	   }
	   $query = $this->db->get('users');
	   $user_list = $query->result_array();
	}
	return $user_list;
   }
   
   /**
    *This function is used to get list shop details count
    *@param array $insertArr
    *@return array
    */
   public function get_shopDetailCount($insertArr)
   {
	$data_array = array();
	//total reviews

	$this->db->select('count(id) AS total_reviews');
	if($insertArr['account_type'] == "shopowner"){
		$tr_query = $this->db->get_where('reviews', array('shop_id'=>$insertArr['shop_id'], 'cstatus'=>'Active'))->row()->total_reviews;
	}else{
		$tr_query = $this->db->get_where('reviews', array('user_id'=>$insertArr['shop_id'], 'cstatus'=>'Active'))->row()->total_reviews;
	}
	$data_array['total_reviews'] = $tr_query >0 ? (int)$tr_query : 0;

	//total_products
	$this->db->select('count(id) AS total_products');
	if($insertArr['account_type'] == "shopowner"){
		$tp_query = $this->db->get_where('products', array('shop_id'=>$insertArr['shop_id'], 'cstatus'=>'Active'))->row()->total_products;
	}else{
		$tp_query = $this->db->get_where('request', array('user_id'=>$insertArr['shop_id'], 'product_id !='=>0))->row()->total_products;
	}
	$data_array['total_products'] = $tp_query >0 ? (int)$tp_query : 0;

	//total rating
	if($insertArr['account_type'] == "shopowner"){
		$this->db->select('AVG(rating) AS total_rating');
		$tar_query = $this->db->get_where('reviews', array('shop_id'=>$insertArr['shop_id'], 'cstatus'=>'Active'))->row()->total_rating;//echo $this->db->last_query();exit;
		$data_array['total_rating'] = $tar_query >0 ? (int)$tar_query : 0;
	}else{
		$data_array['total_rating'] = 0;
	}
	
	$data_array['follow_status'] = $data_array['blacklist_status'] ="";
	if($insertArr['user_id'] >0 && $insertArr['user_id'] != $insertArr['shop_id'])
	{
	   //user_following
	   $this->db->select('status AS follow_status');
	   $f_query = $this->db->get_where('followers', array('shop_id'=>$insertArr['shop_id'], 'user_id'=>$insertArr['user_id']))->row()->follow_status;//echo $this->db->last_query();exit;
	   $data_array['follow_status'] = $f_query !="" ? $f_query :'Unfollowing';

	   //user block status
	   //$this->db->select('status AS block_status');
	   //$block_query = $this->db->get_where('cm_block_users', array('shop_id'=>$insertArr['shop_id'], 'user_id'=>$insertArr['user_id']))->row()->block_status;
	   //$data_array['blacklist_status'] = $block_query ? $block_query :"";
	   
	   $block_sql = "SELECT status AS block_status FROM `cm_block_users`  WHERE  (`user_id` = '".$insertArr['user_id']."' AND `shop_id` = '".$insertArr['shop_id']."') OR (`user_id` = '".$insertArr['shop_id']."' AND `shop_id` = '".$insertArr['user_id']."')";
	   $block_query = $this->db->query($block_sql);
	   $data_array['blacklist_status'] = $block_query->row()->block_status ? $block_query->row()->block_status :"Unblock";
	}
	
	if($insertArr['account_type'] == "shopowner"){
		$this->db->select('count(id_follow) AS total_followers');
		$this->db->from('followers');
		$this->db->where(array('shop_id'=>$insertArr['shop_id'], 'status'=>'Following'));
		$query_foll = $this->db->get();
		$data_foll = $query_foll->row_array();
		$data_array['total_followers'] = $data_foll['total_followers'] >0 ? (int)$data_foll['total_followers'] :0 ;
	}else{
		$data_array['total_followers'] = 0;
	}
	
	$this->db->select('count(id_follow) AS total_following');
	$fb_query = $this->db->get_where('followers', array('user_id'=>$insertArr['shop_id'], 'status'=>'Following'))->row()->total_following;//echo $this->db->last_query();exit;
	$data_array['total_following'] = $fb_query >0 ? (int)$fb_query :0;
	
	
	$this->db->select('count(id) AS total_request');
	if($insertArr['account_type'] == "shopowner"){
		$this->db->where('shop_id =', $insertArr['shop_id']);
	}else{
		$this->db->where('user_id =', $insertArr['shop_id']);
	}
	$fc_query1 = $this->db->get('cm_request');
	$fc_query = $fc_query1->row()->total_request;
	
	if($insertArr['account_type'] == "shopowner"){
		// code to get total requests
		$getRequests = $this->dashboard->getRequestFollowingList(array('user_id'=>$insertArr['shop_id'])); //$this->getUserRequests($insertArr);
		$getRequestsCount = count($getRequests);
		
		$data_array['total_request_follower'] = $getRequestsCount >0 ? (int)$getRequestsCount :0;
	}
	else{
		$data_array['total_request'] =$fc_query;
	}
	
	return $data_array;
   }
   
   /**
    *This function is used to add the shout out data
    *@param $insertArr
    *@return array
    */
   public function addShoutOutShout($insertArr)
   {
	$this->db->insert('sfs', $insertArr);
	$sfs_id = $this->db->insert_id();
	return $sfs_id;
   }
   
   /**
    *This function is used to get all the shout out data
    *@return array
    */
   public function getAllShoutOutShout()
   {
	$sfs_list = array();
	$query = $this->db->get_where('sfs',array('status'=>'Active'));
	$sfs_list = $query->result_array();
	return $sfs_list;
   }
   
   /**
    *This function is used to get all the shout out data
    *@return array
    */
   public function _updateShoutOutShout($fields)
   {
	$query = $this->db->update('sfs',$fields,array('id'=>$fields['id']));
	return $query ? 1 :0;
   }
   
   public function _updateRequestNotification($fields)
   {
	$query = $this->db->update('request_notification',$fields,array('id'=>$fields['id']));
	return $query ? 1 :0;
   }
   
   public function getAllRequestNotification()
    {
	
	$query_result = array();
	$query = $this->db->get_where('request_notification',array('status'=>0));
	$query_result= $query->result_array();
	
	return $query_result;
    }
   /**
    *This function is used to fetch all the counrty code from database
    *@return array
    */
   public function _getCountryCode()
   {
	$country_list = array();
	$query = $this->db->get('phone_country_code');
	$country_list = $query->result_array();
	return $country_list;
   }
   
    /**
    *this method returns the all categories under a shop owner
    *@param $status
    *@return array
    */
   public function getCategoryList($status="")
   {
	$category_data = array();
	if($status !="" && $status != 'Deleted'){
	   $this->db->where('category_status',$status);
	}else{
	   $this->db->where('category_status !=','Deleted');
	}
	$this->db->order_by('cat_order','ASC');
		$query= $this->db->get('category');
		$category_data = $query->result_array();
		return $category_data;
   }
   
   public function deleteProductImage($imageId) {
	if($imageId) {
		$product_data = $this->webservice->get_product_image_by_id($imageId);
		//unlink imgaes
		@unlink(FCPATH.'uploads/product_image/'.$product_data['image']);
		@unlink(FCPATH.'uploads/product_image/thumb_'.$product_data['image']);
		@unlink(FCPATH.'uploads/product_image/big_'.$product_data['image']);
		
		$delete_product_image = $this->db->delete("product_images",array('id'=> $imageId));
	}
   }
   
   public function getShoutOutByID($productId,$userid=0)
    {
	//if($userid>0 && $productId>0)
	if($productId>0)
	{
	    $this->db->select('sfs.*');
	    $this->db->from('sfs');
	    //$this->db->where('sfs.user_id',$userid);
	    $this->db->where('sfs.product_id',$productId);
	    $this->db->where('sfs.status','Active');
	    $q = $this->db->get(); 
	    $data=$q->row_array(); 
	    return $data;
	}
	return array();
	
    }
   
   /**
    *This function is used to get the products/shops by category id
    *@param requested data
    *@return array
    *
    */
   public function getShopProductListByCategory($id_category, $list_type)
   {
	$result_array = array();
	if($list_type == 'shop'){
		$this->db->select('products.shop_id');
		$this->db->from('products');
		$this->db->select('shop.name AS shop_owner, shop.image_name AS shop_image, shop.address as shop_address,shop.account_type');
		$this->db->select('country.country_name');
		$this->db->join('users as shop','shop.id = products.shop_id','inner');
		$this->db->join('country as country','shop.country_id = country.id','left');
		$this->db->where('shop.status =','Active');
		$this->db->where('products.cstatus =','Active');
		$this->db->where('products.id_category =',$id_category);
		$this->db->group_by('products.shop_id');
		$this->db->order_by('products.shop_id','DESC');
		$query= $this->db->get();
		$resultArray = $query->result_array();
		if(count($resultArray)>0){
			foreach($resultArray as $rs)
			{
				$totalProduct_query = $this->db->query("SELECT COUNT(id) AS total_product FROM cm_products WHERE shop_id ='".$rs['shop_id']."' AND cstatus = 'Active'");
				$rs['total_products'] = (int)$totalProduct_query->row()->total_product ;
				$totalFollow_query = $this->db->query("SELECT COUNT(id_follow) AS total_follower FROM cm_followers WHERE shop_id ='".$rs['shop_id']."' AND status = 'following'");
				$rs['total_follower'] = (int)$totalFollow_query->row()->total_follower ;
				$data_arr[] = $rs;
			}
		}
	}else{
		$this->db->select('products.*');
		$this->db->from('products');
		$this->db->select('shop.account_type, shop.name as shop_name');
		$this->db->join('users as shop','shop.id = products.shop_id','inner');
		$this->db->where('products.cstatus =','Active');
		$this->db->where('products.id_category =',$id_category);
		$this->db->order_by('products.id','DESC');
		$query= $this->db->get();
		$result_array = $query->result_array();
		
		foreach($result_array as $rs)
		{
			$rs['image'] = $this->getProductImageById($rs['id']);
			$rs['added_on'] = $rs['added_on'] !="" ? agoTimePost($rs['added_on']) :"";
			$rs['updated_on'] = $rs['updated_on'] !="" ? agoTimePost($rs['updated_on']) :"";
			$data_arr[] = $rs;
		}
	}
	return $data_arr;
   }
   
  
   public function getSearchedDataByType($dataArr)
   {
	//print_r($dataArr);
	$result_list = array();
	$time_zone = getUserLocalTimeZone($dataArr['user_id']);
	
	switch($dataArr['search_type'])
	{
		case "category":
			$getcategory = "SELECT * FROM cm_category WHERE category_status ='Active' ";
			if(trim($dataArr['search_text'])!="")
			{
				$getcategory .= "  AND category_name LIKE '%".$dataArr['search_text']."%' ";
			}
			$getcategory .= "  ORDER BY id_category DESC ";
			$q_category = $this->db->query($getcategory);
			$result_listArr = $q_category->result_array();

			//echo $this->db->last_query();
			
			foreach($result_listArr as $rs)
			{
				$rs['image'] = $this->getProductImageById($rs['id']);
				$rs['added_on'] = $rs['added_on'] !="" ? agoTimePost($rs['added_on'],$time_zone) :"";
				$rs['updated_on'] = $rs['updated_on'] !="" ? agoTimePost($rs['updated_on'],$time_zone) :"";
				$result_list[] = $rs;
			}			
			
		break;
		
		case "category_shop":
			
			/*
			$getshop = "SELECT `cm_products`.`shop_id`, `shop`.`name` AS `shop_owner`, `shop`.`image_name` AS `shop_image`, `shop`.`address` as `shop_address`,`shop`.`created_on` AS shop_created_on, AVG(revi.rating) as shopavgrating,count(f.id_follow) FROM `cm_products` INNER JOIN `cm_users` as `shop` ON `shop`.`id` = `cm_products`.`shop_id` LEFT JOIN cm_reviews as revi ON shop.id = revi.shop_id
			
			inner join cm_followers as f on cm_products.shop_id=f.shop_id
			
			WHERE `shop`.`status` = 'Active' AND `cm_products`.`cstatus` = 'Active' ";
			if(trim($dataArr['id_category'])) {
				$getshop .= " AND `cm_products`.`id_category` = '".$dataArr['id_category']."' ";
			}
			if(trim($dataArr['search_text'])!="")
			{
				$getshop .= "  AND `shop`.`name` LIKE '%".$dataArr['search_text']."%' ";
			}
			
			if(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="latest"){
				$getshop .= "  GROUP BY `cm_products`.`shop_id` ORDER BY shop_created_on DESC ";
			}elseif(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="most_popular"){
				$getshop .= "  GROUP BY `cm_products`.`shop_id` ORDER BY shopavgrating DESC  ";
			}
			else{
				$getshop .= "  GROUP BY `cm_products`.`shop_id` ORDER BY `cm_products`.`shop_id` DESC  ";
			}
			*/
			$getshop ="
			select t2.*,count(p.id) as total_products from(
select t1.*,count(f.id_follow) as total_followers from (
SELECT `cm_products`.`shop_id`, shop.id,`shop`.`name` AS `shop_owner`, `shop`.`image_name` AS `shop_image`, `shop`.`address` as `shop_address`,`shop`.`created_on` AS shop_created_on, AVG(revi.rating) as shopavgrating FROM `cm_users` as `shop`  INNER JOIN `cm_products`  ON `shop`.`id` = `cm_products`.`shop_id` LEFT JOIN cm_reviews as revi ON shop.id = revi.shop_id
			
			WHERE `shop`.`status` = 'Active' AND `cm_products`.`cstatus` = 'Active'";
			if(trim($dataArr['id_category'])) {
				$getshop .= " AND `cm_products`.`id_category` = '".$dataArr['id_category']."' ";
			}
			if(trim($dataArr['search_text'])!="")
			{
				$getshop .= "  AND `shop`.`name` LIKE '%".addslashes($dataArr['search_text'])."%' ";
			}
			$getshop .= " GROUP BY shop.id 
    )as t1  

left join cm_followers as f on f.shop_id=t1.shop_id where status='Following'
    
    group by t1.shop_id order by shop_id desc
    ) as t2

left join cm_products as p on p.shop_id=t2.shop_id group by t2.shop_id ";

		        if(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="latest"){
				$getshop .= "   ORDER BY t2.shop_created_on DESC ";
			}elseif(trim($dataArr['filter_type']) !="" && (trim($dataArr['filter_type']) =="most_popular" || trim($dataArr['filter_type']) =="highest_ratings" )){
				$getshop .= "  ORDER BY t2.shopavgrating DESC  ";
			}
			elseif(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="most_products"){
				$getshop .= "  ORDER BY total_products DESC  ";
			}
			elseif(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="most_followers"){
				$getshop .= "  ORDER BY t2.total_followers DESC  ";
			}
			else{
				$getshop .= "  ORDER BY `t2`.`shop_id` DESC  ";
			}
			
			
			$query ="select count(f.id_follow) as total_followers,t3.* from
			(
			SELECT AVG( r.rating ) AS shopavgrating, t2 . *
			FROM (
			
			SELECT count( p.shop_id ) AS total_products, t1. *
			FROM (
			
			SELECT `shop`.`name` AS `shop_owner` , shop.id,shop.id as shop_id, `shop`.`image_name` AS `shop_image` , `shop`.`address` AS `shop_address` , `shop`.`created_on` AS shop_created_on
			FROM `cm_users` AS `shop`";
			if(trim($dataArr['id_category'])) {
				$query .=" left join cm_products as pd on pd.shop_id=shop.id ";
			}
			$query .="
			WHERE `shop`.`status` = 'Active' and shop.account_type='shopowner' ";
			
			if(trim($dataArr['id_category'])) {
				$query .=" AND pd.`id_category` = '".$dataArr['id_category']."' ";
			}
			if(trim($dataArr['search_text'])!="")
			{
				$search_text = str_replace("'","''",$dataArr['search_text']);
				$query .= "  AND `shop`.`name` LIKE '%".$search_text."%' ";
			}
			$query .="
			) AS t1
			LEFT JOIN cm_products AS p ON (p.shop_id = t1.id and p.cstatus='Active')
			GROUP BY t1.id
			) AS t2
			LEFT JOIN cm_reviews AS r ON r.shop_id = t2.id
			GROUP BY t2.id
			) as t3 left join cm_followers as f on (f.shop_id=t3.id and f.status='Following' )
			    
			    group by t3.id ";
			
			 if(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="latest"){
				$query .= "   ORDER BY t3.shop_created_on DESC ";
			}elseif(trim($dataArr['filter_type']) !="" && (trim($dataArr['filter_type']) =="most_popular" || trim($dataArr['filter_type']) =="highest_ratings" )){
				$query .= "  ORDER BY t3.shopavgrating DESC  ";
			}
			elseif(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="most_products"){
				$query .= "  ORDER BY t3.total_products DESC  ";
			}
			elseif(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="most_followers"){
				$query .= "  ORDER BY total_followers DESC  ";
			}
			else{
				$query .= "  ORDER BY `t3`.`id` DESC  ";
			}
			
			//echo $query;
			$q_shop = $this->db->query($query);
			$resultList = $q_shop->result_array(); 
			if(count($resultList)>0){
				
				foreach($resultList as $rs)
				{
					/*
					$totalProduct_query = $this->db->query("SELECT COUNT(id) AS total_product FROM cm_products WHERE shop_id ='".$rs['shop_id']."' AND cstatus = 'Active'");
					$rs['total_products'] = (int)$totalProduct_query->row()->total_product ;
					$totalFollow_query = $this->db->query("SELECT COUNT(id_follow) AS total_follower FROM cm_followers WHERE shop_id ='".$rs['shop_id']."' AND status = 'following'");
					$rs['total_follower'] = (int)$totalFollow_query->row()->total_follower ;
					*/
					$rs['shop_created_on'] = $rs['shop_created_on'] !="" ? agoTimePost($rs['shop_created_on'],$time_zone) :"";
					
					$result_list[] = $rs;
					
					
				}
			}

		break;
		
		case "category_product":

			//$getproduct_old = "SELECT cp.*, (SELECT IF(AVG(rating) IS NULL, 0, AVG(rating)) FROM cm_reviews WHERE product_id IN (cp.id)) as product_rating  FROM `cm_products` AS cp WHERE cp.cstatus = 'Active' AND cp.id_category = '".$dataArr['id_category']."' ";
			$getproduct = "SELECT shop.name as shop_name, cp.*, (SELECT IF(AVG(rating) IS NULL, 0, AVG(rating)) FROM cm_reviews WHERE product_id IN (cp.id)) as product_rating  FROM `cm_products` AS cp JOIN cm_users as shop ON (shop.id = cp.shop_id ) WHERE cp.cstatus = 'Active' AND cp.product_type !='soldout'  ";
			if(trim($dataArr['id_category'])!="")
			{
				$getproduct .= "  AND cp.id_category = '".$dataArr['id_category']."' ";
			}
			if(trim($dataArr['search_text'])!="")
			{
				$search_text = str_replace("'","''",$dataArr['search_text']);
				$getproduct .= "  AND cp.name LIKE '%".$search_text."%' ";
			}
			if(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="latest")
			{
				//$getproduct .= "  ORDER BY cp.featured DESC, cp.updated_on DESC ";
				$getproduct .= "  ORDER BY cp.id DESC ";
			}elseif(trim($dataArr['filter_type']) !="" && trim($dataArr['filter_type']) =="most_popular"){
				//$getproduct .= "  ORDER BY cp.featured DESC, product_rating DESC ";
				$getproduct .= "  ORDER BY product_rating DESC ";
			}else{
				//$getproduct .= " ORDER BY cp.featured DESC, cp.id DESC ";
				$getproduct .= " ORDER BY cp.id DESC ";
			}
			//$getproduct .= ", name ASC ";echo $getproduct;exit;
			$q_product = $this->db->query($getproduct);
			$result_listArr = $q_product->result_array();
			//echo $this->db->last_query();
			
			foreach($result_listArr as $rs)
			{
				$rs['image'] = $this->getProductImageById($rs['id']);
				$rs['added_on'] = $rs['added_on'] !="" ? agoTimePost($rs['added_on'],$time_zone) :"";
				$rs['updated_on'] = $rs['updated_on'] !="" ? agoTimePost($rs['updated_on'],$time_zone) :"";
				$result_list[] = $rs;
			}

		break;
		
		case "category_request":
			/*$getrequest = "SELECT req.*, shop.name as shop_owner, shop.image_name AS shop_owner_image, con.name AS consumer_name, con.image_name AS consumer_image, prod.name AS product_name, prod.image AS product_image FROM `cm_request` AS req INNER JOIN cm_users AS shop ON shop.id = req.shop_id INNER JOIN cm_users AS con ON con.id = req.user_id INNER JOIN cm_products AS prod ON prod.id = req.product_id WHERE prod.cstatus = 'Active' AND shop.status = 'Active' AND con.status = 'Active' ";
			if(trim($dataArr['search_text'])!="")
			{
				$getrequest .= "  AND req.title LIKE '%".$dataArr['search_text']."%' ";
			}
			$getrequest .= " AND req.id_category = '".$dataArr['id_category']."' ORDER BY req.id DESC ";*/

			if($dataArr['user_type'] == 'shopowner') {

				$getrequest = "SELECT tab1.* FROM (
				(SELECT re.*, u.id as u_id, u.name as u_name FROM cm_request as re JOIN cm_users as sh ON re.shop_id = sh.id JOIN cm_users as u ON (re.user_id = u.id) WHERE sh.id = '".$dataArr['user_id']."' ".($dataArr['id_category'] ? ' AND re.id_category = '.$dataArr['id_category'] : '')." )
				UNION
				(SELECT re.*, u.id as u_id, u.name as u_name FROM cm_request as re JOIN cm_users as u ON (re.user_id = u.id) WHERE shop_id = 0 ".($dataArr['id_category'] ? ' AND id_category = '.$dataArr['id_category'] : '')." ))
				as tab1 WHERE 1 ";
				if(trim($dataArr['search_text'])!=""){
					$getrequest .= " AND tab1.title  LIKE '%".$dataArr['search_text']."%' ";
				}
				$getrequest .=" AND tab1.user_id NOT IN(SELECT user_id FROM cm_block_users WHERE shop_id = '".$dataArr['user_id']."' AND status = 'Block' ) ";

				$getrequest .=" ORDER BY tab1.added_on DESC " ;
				//echo $getrequest;
			} else
			{
			     $getrequest = "SELECT tab1.* FROM (
			     (SELECT re.*, u.id as u_id, u.name as u_name FROM cm_request as re JOIN cm_users as sh ON re.shop_id = sh.id JOIN cm_users as u ON (re.user_id = u.id) WHERE  re.user_id = '".$dataArr['user_id']."' ".($dataArr['id_category'] ? ' AND re.id_category = '.$dataArr['id_category'] : '').")
			     UNION
			     (SELECT re.*, u.id as u_id, u.name as u_name FROM cm_request as re JOIN cm_users as u ON (re.user_id = u.id) WHERE shop_id = 0 AND re.user_id = '".$dataArr['user_id']."' ))
			     as tab1 WHERE 1 ";
				if(trim($dataArr['search_text'])!=""){
					$getrequest .= " AND tab1.title  LIKE '%".$dataArr['search_text']."%' ";
				}
				$getrequest .=" AND tab1.shop_id NOT IN(SELECT shop_id FROM cm_block_users WHERE user_id = '".$dataArr['user_id']."' AND status = 'Block' ) ";
				$getrequest .=" ORDER BY tab1.added_on DESC " ;
				//echo $getrequest;
			}
			$q_request = $this->db->query($getrequest);
			$result_listArr = $q_request->result_array();
			
			foreach($result_listArr as $rs)
			{
				$rs['added_on'] = $rs['added_on'] !="" ? agoTimePost($rs['added_on'],$time_zone) :"";
				$result_list[] = $rs;
			}
			
			//echo $this->db->last_query();
		break;
	}

	//echo $this->db->last_query();
	//echo "AAA: ".count($result_list);
	return $result_list;
   }
   
  
/**
    *This function is used to contact
    *@param array $dataArr
    *@return int
    */
   public function add_contact($insertArray)
    {
       $this->db->insert('contact', $insertArray);
       return $this->db->insert_id();

    }

    /**
    *This function is used to block/unblock user
    *@param array $dataArr
    *@return int
    */
   public function update_userBlockAndUnlock($dataArr)
   {

	$query_block = $this->db->get_where('block_users',array('user_id '=>$dataArr['user_id'], 'status != ' => '', 'shop_id'=>$dataArr['shop_id']));
	$exist_block = $query_block->row_array();
	//echo $this->db->last_query();
	if($exist_block && $exist_block['id_block'] >0){
		if($dataArr['status'] == 'getData') {
			return $exist_block;
		} else {
			$follow_query = $this->db->update('block_users', $dataArr, array('id_block'=>$exist_block['id_block']));
		}
	} else if($dataArr['status'] == 'Block'){
	   $dataArr['added_on'] = date('Y-m-d H:i:s');
	   $this->db->insert('block_users', $dataArr);
	   $follow_query = $this->db->insert_id();

	}
	return $follow_query;
   }

   /**
    *this function is used to update the user block /unblock status
    *@param $dataArr array
    *@return int 1|0
    */
   public function updateBlockedUserStatus($dataArr)
   {
	$data = 0;
	if($dataArr['id_block'] >0){
		$query_block = $this->db->get_where('block_users',array('id_block '=>$dataArr['id_block']));
		$exist_block = $query_block->row_array();
		if(count($exist_block) >0){
			$follow_query = $this->db->update('block_users', array('status'=>$dataArr['status']), array('id_block'=>$exist_block['id_block']));
			$data = 1;
		}
	}else{
		$query_block = $this->db->get_where('block_users',array('shop_id '=>$dataArr['shop_id'],'user_id '=>$dataArr['user_id']));
		$exist_block = $query_block->row_array();
		if(count($exist_block) >0){
			$follow_query = $this->db->update('block_users', array('status'=>$dataArr['status']), array('id_block'=>$exist_block['id_block']));
			$data = 1;
		}else{
			$dataArr['added_on'] = date('Y-m-d H:i:s');
			$this->db->insert('block_users', $dataArr);
			$data = 1;
		}
	}
	return $data;
   }

   /**
    *
    */
   public function _checkUserIsBlock($dataArr)
   {
	$num_rows = array();
	$query_block = $this->db->get_where('block_users',array('shop_id '=>$dataArr['shop_id'],'user_id '=>$dataArr['user_id'],'status'=>$dataArr['status']));
	$num_rows = $query_block->row_array();
	return $num_rows;
   }

   public function checkUserBlokedByAllShops($dataArr)
   {
	$data = array();
	$sqlQuery = "SELECT * FROM cm_block_users WHERE shop_id IN (SELECT id FROM cm_users WHERE account_type ='shopowner' AND status ='Active') AND user_id = '".$dataArr['user_id']."' AND status ='".$dataArr['status']."'";
	$query = $this->db->query($sqlQuery);
	$data = $query->result_array();
	return $data;
   }

   public function readMessages($dataArr)
   {
	if($dataArr['chat_id'] >0){
		$sqlQuery = "UPDATE cm_chat SET seen_status = 'read', seenon = '".date('Y-m-d H:i:s')."', msg_status = '1' WHERE id='".$dataArr['chat_id']."'";
		$query = $this->db->query($sqlQuery);
	}else{
		$chat_type = $dataArr['chat_type'];
		$sqlQuery = "UPDATE cm_chat SET seen_status = 'read', seenon = '".date('Y-m-d H:i:s')."', msg_status = '1' WHERE from_id='".$dataArr['from_id']."' AND to_id='".$dataArr['to_id']."' AND product_id='".$dataArr['product_id']."'  ";
		
		if(!empty($chat_type) && $chat_type!="all")
		{
			$sqlQuery .=" AND chat_type='".$chat_type."'";
		}
		$query = $this->db->query($sqlQuery);
	}
	return $query;
   }

   public function getUreadMessagesCount($dataArr)
   {
	$count_query = array();
	//unread chat count

	$getHistoryQry = "SELECT c.*, u.name, u.image_name from cm_chat as c
		JOIN cm_users as u ON (c.to_id = u.id) JOIN cm_users as us ON (c.from_id = us.id)  WHERE msg_status = '0' AND ";

	$getHistoryQry .= " u.id = '" . $dataArr['to_id'] . "' AND c.to_id = '" . $dataArr['to_id'] . "' and c.delete_status!='All' and c.deleted_by!='".$dataArr['to_id']."' ";
	$q = $this->db->query($getHistoryQry);
	$chat_count =  $q->num_rows();

	//$this->db->select('COUNT(id) AS data_count');
	//$chat_count = $this->db->get_where('cm_chat', array('seen_status'=>'unread', 'msg_status'=>'0', 'to_id'=>$dataArr['to_id']))->row()->data_count;

	$count_query['chat_count'] = $chat_count >0 ? (int)$chat_count : 0;

	//unread notification count
	$this->db->select('COUNT(id) AS data_count_noti');
	$noti_count = $this->db->get_where('cm_notification', array('status'=>'Unread', 'to_id'=>$dataArr['to_id']))->row()->data_count_noti;
	$count_query['notification_count'] = $noti_count >0 ? (int)$noti_count : 0;

	//total count

	//$sqlQuery_total =  "SELECT (data_count + chat_count) FROM ( SELECT COUNT(id) AS data_count, (SELECT COUNT(id) FROM cm_chat WHERE seen_status ='unread' AND msg_status ='0' AND to_id = '".$dataArr['to_id']."') AS chat_count FROM cm_notification WHERE to_id = '".$dataArr['to_id']."' AND status = 'Unread') AS total_count WHERE 1";
	//$total_count = $this->db->query($sqlQuery_total);
	//$count_query['total_count'] = $total_count >0 ? (int)$total_count : 0;
	$count_query['total_count'] =  (int)($count_query['chat_count'] + $count_query['notification_count'] );
	return $count_query;
   }

   /**
    *This function is used to read all the notifications on notifiation list page
    */
   public function readAllNotifications($dataArr)
   {
	$updateArr = array('status'=>'Read');
	$noti_query = $this->db->update('notification', $updateArr, array('to_id'=>$dataArr['to_id']));
	return $noti_query ? 1 : 0;
   }

   public function getLastReplyDetails($dataArr)
   {
	$reply_data = array();
	$reply_sql = "SELECT * FROM cm_reply WHERE ( (reply_to = '".$dataArr['reply_to']."' AND  reply_from = '".$dataArr['reply_from']."') OR (reply_to = '".$dataArr['reply_from']."' AND  reply_from = '".$dataArr['reply_to']."') ) AND  id_request = '".$dataArr['id_request']."' ORDER BY id_reply DESC LIMIT 0,1";
	$reply_query = $this->db->query($reply_sql);
	$reply_data= $reply_query->row_array();
	return $reply_data;
   }

   public function getRequestData($requestId)
   {
	$request_data = array();
	$request_sql = "SELECT cm_users.name as request_by, cm_users.image_name as request_user_image, cm_request.* FROM `cm_request`  INNER JOIN cm_users AS cm_users ON (cm_request.user_id = cm_users.id AND cm_users.status ='Active') WHERE cm_request.id = '".$requestId."'";
	$request_query = $this->db->query($request_sql);
	$request_data =  $request_query->row_array();
	return $request_data;
   }
   
   
   public function getRequestDetailData($dataArr)
   {
	//print_r($dataArr);
	$tmp_array =array();
	
	$request_data['shop_replied_count'] = 0;
	$request_data = array('request_detail'=>array(), 'shop_replied'=>array());
	
	$request_data['followtype'] = 'unfollow';
	$this->db->select('id_follow');
	$this->db->from('request_followers');
	$this->db->where('request_id',$dataArr['request_id']);
	$this->db->where('user_id',$dataArr['user_id']);
	$q = $this->db->get();
	if($q->num_rows() > 0) {
		$request_data['followtype'] = 'follow';
	}
	
	$time_zone = getUserLocalTimeZone($dataArr['user_id']);
	
	$request_sql = "SELECT cm_users.name as request_by, cm_request.* FROM `cm_request`  INNER JOIN cm_users AS cm_users ON (cm_request.user_id = cm_users.id AND cm_users.status ='Active') WHERE cm_request.id = '".$dataArr['request_id']."'";
	$request_query = $this->db->query($request_sql);
	$request_data['request_detail'] =  $request_query->row_array();
	$request_data['request_detail']['added_on'] = agoTimePost($request_data['request_detail']['added_on'],$time_zone);
	
	//if($request_data['request_detail']['shop_id'] == 0 && $dataArr['account_type'] == "consumer"){
		$request_reply = "SELECT * FROM (SELECT cm_users.name,cm_users.image_name, cm_reply.* FROM `cm_reply` INNER JOIN cm_users AS cm_users ON (cm_users.id = cm_reply.reply_from AND cm_users.status ='Active' AND cm_users.account_type ='shopowner' AND cm_users.id NOT IN(SELECT shop_id FROM cm_block_users WHERE user_id = '".$dataArr['user_id']."' AND status = 'Block' )) WHERE cm_reply.id_request = '".$dataArr['request_id']."' ORDER BY cm_reply.reply_date DESC) AS tmp_table GROUP BY tmp_table.reply_from ORDER BY tmp_table.reply_date DESC";

		// AND cm_users.id NOT IN(SELECT shop_id FROM cm_block_users WHERE user_id = '".$insertArr['from_id']."' AND status = 'Block' )

		$request_reply1 = " SELECT * FROM cm_request AS re INNER JOIN cm_reply AS rep ON (re.id = rep.id_request)  WHERE  rep.id_request = '".$dataArr['request_id']." AND  ( rep.reply_to = '".$dataArr['request_id']."'  OR rep.reply_from = '".$dataArr['request_id']."') '";

		$reply_query = $this->db->query($request_reply);
		//$request_data['shop_replied'] =  $reply_query->result_array();
		$request_data['shop_replied_count'] = $reply_query->num_rows();
		$request_datares =  $reply_query->result_array();
		$i =0;
		foreach($request_datares as $res)
		{
			$getRequest_sql = "SELECT reply_content, reply_date FROM cm_reply WHERE ((reply_to = '".$res['reply_to']."' AND reply_from ='".$res['reply_from']."' ) OR (reply_to = '".$res['reply_from']."' AND reply_from ='".$res['reply_to']."' )) ORDER BY reply_date DESC LIMIT 0,1";
			$getRequest_data = $this->db->query($getRequest_sql);
			$getRequest = $getRequest_data->row_array();
			$tmp_array['id_reply'] 		=      $res['id_reply'];
			$tmp_array['id_request'] 	=    $res['id_request'];
			$tmp_array['parent_id'] 	=     $res['parent_id'];
			$tmp_array['reply_to'] 		=      $res['reply_to'];
			$tmp_array['reply_from'] 	=    $res['reply_from'];
			$tmp_array['reply_content'] 	= $getRequest['reply_content'];
			$tmp_array['name'] 		= $res['name'];
			$tmp_array['image_name'] 	= $res['image_name'];
			$tmp_array['groupby'] 	 	=    date('Y-m-d');
			$tmp_array['reply_date'] 	=    date('h:i A',(strtotime($getRequest['reply_date'])));
			$tmp_array['ago_time'] 		=     agoTimePost($getRequest['reply_date'],$time_zone);
			$request_data['shop_replied'][] = $tmp_array;
			$i++;
		}
	//}
	return $request_data;
   }

   /**
    *This function is used to save the reply data to a request
    *@param array $dataArr
    *@return int inserted id
    */
   public function saveReplyData($dataArr)
   {
	$tmp_array =array();$reply_date = date('Y-m-d H:i:s');
	$pervious_data = $this->getLastReplyDetails(array('reply_from'=>$dataArr['reply_from'], 'reply_to'=>$dataArr['reply_to'], 'id_request'=>$dataArr['id_request']));
	if(count($pervious_data) == 0){
		$parent_id = 0;
	}else{
		$parent_id = $pervious_data['id_reply'];
	}
	$dataArr['parent_id'] =  $parent_id;
	$dataArr['reply_date'] =  $reply_date;
	$this->db->insert('reply', $dataArr);
	$reply_id = $this->db->insert_id();

	$tmp_array['id_reply'] =      $reply_id;
	$tmp_array['id_request'] =    $dataArr['id_request'];
	$tmp_array['parent_id'] =     $parent_id;
	$tmp_array['reply_to'] =      $dataArr['reply_to'];
	$tmp_array['reply_from'] =    $dataArr['reply_from'];
	$tmp_array['reply_content'] = $dataArr['reply_content'];
	$tmp_array['groupby'] 	 =    date('Y-m-d');
	$tmp_array['reply_date'] =    date('h:i A',(strtotime($reply_date)));
	$tmp_array['ago_time'] =     agoTime($reply_date);
	return $tmp_array;
   }
   
   /**
    *This function is used to update reply comment
    *@param array $dataArr
    *@return array
    */
   public function updateReplyComment($dataArr,$id_reply)
   {
	$tmp_array =array(); 
	$reply_date = date('Y-m-d H:i:s');
	
	//$dataArr['parent_id'] =  $parent_id;
	$updateArr['reply_content'] =  $dataArr['reply_content'];
	//$updateArr['reply_date'] =  $reply_date;
	$this->db->update('reply', $updateArr,array('id_reply'=>$id_reply));

	//if($this->db->affected_rows())

		$tmp_array['id_reply'] =      $id_reply;
		//$tmp_array['id_request'] =    $dataArr['id_request'];
		//$tmp_array['parent_id'] =     $parent_id;
		//$tmp_array['reply_to'] =      $dataArr['reply_to'];
		//$tmp_array['reply_from'] =    $dataArr['reply_from'];
		$tmp_array['reply_content'] = $dataArr['reply_content'];
		$tmp_array['groupby'] 	 =    date('Y-m-d');
		//$tmp_array['reply_date'] =    date('h:i A',(strtotime($reply_date)));
		$tmp_array['ago_time'] =     agoTime($reply_date);

	return $tmp_array;
   }
   
    /**
    *This function is used to delete reply comment
    *@param array $dataArr
    *@return bool
    */
   public function deleteReplyComment($id_reply)
   {
	$tmp_array =array(); 

	$this->db->delete('reply',array('id_reply'=>$id_reply));
	if($this->db->affected_rows())
	{
		return true;
	}
	else{
		return false;
	}
   }

   /**
    *This function fetches the all request replies from database
    *@param array $dataArr
    *@return array $chat_array
    */
   public function getRequestConversationData($dataArr)
   {
	$chat_array = $chatArray= array();

	/*$shopData = $this->getUserDetails($dataArr['reply_to']);
	$chat_array['repliedby_data'] = array('replied_by_name'=>$shopData['name'], 'replied_by_image'=>$shopData['image_name']);
	
	$sql_query = "SELECT COUNT(id_block) AS total_row FROM cm_block_users WHERE status = 'Block' AND (shop_id ='".$dataArr['reply_to']."' AND user_id = '".$dataArr['reply_from']."' ) OR  (shop_id ='".$dataArr['reply_from']."' AND user_id = '".$dataArr['reply_to']."' )" ;
	$totalProduct_query = $this->db->query($sql_query);
	$totalProductBlock = $totalProduct_query->row()->total_row ;
	
	$chat_array['repliedby_data']['user_status'] = '';
	if($totalProductBlock > 0)
		$chat_array['repliedby_data']['user_status'] = 'Block';*/

	$record_per_page = $dataArr['record_per_page'];

	$request_query = "SELECT cm_users.account_type, cm_users.image_name, cm_users.name, cm_reply.*,date_format(reply_date, '%Y-%m-%d') as newdate
	FROM cm_reply INNER JOIN cm_users ON (cm_users.id = cm_reply.reply_from AND cm_users.status ='Active') WHERE 1 AND id_request = '".$dataArr['request_id']."' ";

	if($dataArr['list_type'] == "new"){
		$request_query .= "  AND  cm_reply.id_reply > '".$dataArr['id_reply']."' ";
		$request_query .= " ORDER BY cm_reply.id_reply DESC  ";
	}elseif($dataArr['list_type'] == "old"){
		$request_query .= "  AND  cm_reply.id_reply < '".$dataArr['id_reply']."' ";
		$request_query .= " ORDER BY cm_reply.id_reply DESC  ";
		$request_query .= " LIMIT 0, $record_per_page ";
	}else{
		$request_query .= " ORDER BY cm_reply.id_reply DESC  ";
		if($record_per_page)
			$request_query .= " LIMIT 0, $record_per_page ";

	}
	//echo $request_query;
	//$request_query .= " ORDER BY cm_reply.parent_id DESC  ";
	//if($record_per_page >0){
	//	$request_query .= " LIMIT 0, $record_per_page ";
	//}
	//echo $request_query;
	$request_data = $this->db->query($request_query);
	$res_array =  $request_data->result_array();
	//echo $this->db->last_query();
	if($request_data->num_rows() >0){
		foreach($res_array as $rs){
			$tmp_array['id_reply'] =      $rs['id_reply'];
			$tmp_array['id_request'] =    $rs['id_request'];
			$tmp_array['parent_id'] =     $rs['parent_id'];
			$tmp_array['reply_to'] =      $rs['reply_to'];
			$tmp_array['reply_from'] =    $rs['reply_from'];
			$tmp_array['reply_content'] = $rs['reply_content'];
			$tmp_array['groupby'] 	 =    $rs['newdate'];
			$tmp_array['reply_date'] =    $rs['reply_date'];
			$tmp_array['ago_time'] =      agoTimePost($rs['reply_date']);
			$tmp_array['reply_from_atype'] =$rs['account_type'];
			$tmp_array['reply_name'] =$rs['name'];
			$tmp_array['reply_image'] =$rs['image_name'];
			$chatArray[] = $tmp_array;
		}
	}
	//if(count($chatArray)==0){
	//	$chat_array['repliedby_data'] = array();
	//}
	$chat_array['reply_list'] = $chatArray;

	return $chat_array;
   }
   
   /**
    *This function is used to delete the request details and the associated data
    *@param int $request_id
    *@return int 0|1
    */
   public function deleteRequestData($request_id)
   {
	if($request_id>0)
	{
		$request_data = $this->webservice->getRequestData($request_id);
		
		$user_id = $request_data['user_id'];
		
		$query_reply = $this->db->query("DELETE FROM cm_reply WHERE id_request = '".$request_id."'");
		$query_noti = $this->db->query("DELETE FROM cm_notification WHERE detail_id = '".$request_id."' AND (type='new_request' or type='new_request_comment') ");
		$query_request = $this->db->query("DELETE FROM cm_request WHERE id = '".$request_id."'");
		$query_request = $this->db->query("DELETE FROM cm_request_followers WHERE request_id = '".$request_id."'");
		
		$sq = "UPDATE cm_chat SET delete_status = 'All' WHERE
			  (from_id = '".$user_id."'  or to_id = '".$user_id."')
			  
			AND product_id =  '".$request_id."' and chat_type='request' ";
		
		$this->db->query($sq);
		
		// delete images
		@unlink(FCPATH.'uploads/request_images/'.$request_data['image']);
		@unlink(FCPATH.'uploads/request_images/thumb_'.$request_data['image']);
	}
	
	if($query_reply || $query_noti || $query_request){
		return 1;
	}else{
		return 0;
	}
   }

    /**
    *This function fetches the all comment on request/product
    *@param array $dataArr
    *@return array $chat_array
    */
   public function getreplyComment($dataArr,$page_no=0,$recordsPerPage=10)
   {
	$data_Array = array();

	$type = $dataArr['type'];	
	$record_per_page = $dataArr['record_per_page'];

	$request_query = "SELECT cm_users.account_type, cm_users.image_name, cm_users.name, cm_reply.*,date_format(reply_date, '%Y-%m-%d') as newdate
	FROM cm_reply INNER JOIN cm_users ON (cm_users.id = cm_reply.reply_from AND cm_users.status ='Active') WHERE 1 AND id_request = '".$dataArr['id_request']."' and type='".$type."' ";
	
	/*
	if($dataArr['list_type'] == "new"){
		$request_query .= "  AND  cm_reply.id_reply > '".$dataArr['id_reply']."' ";
		$request_query .= " ORDER BY cm_reply.id_reply DESC  ";
	}elseif($dataArr['list_type'] == "old"){
		$request_query .= "  AND  cm_reply.id_reply < '".$dataArr['id_reply']."' ";
		$request_query .= " ORDER BY cm_reply.id_reply DESC  ";
		$request_query .= " LIMIT 0, $record_per_page ";
	}else{
		$request_query .= " ORDER BY cm_reply.id_reply DESC  ";
		if($record_per_page)
			$request_query .= " LIMIT 0, $record_per_page ";

	}
	*/
	$request_query .= " ORDER BY cm_reply.id_reply DESC  ";
	
	//echo $request_query;
	if($page_no>0)
	{
		$index=($page_no-1)* $recordsPerPage;
		$request_query .= " limit ".$index." , ".$recordsPerPage." ";
	}
	
	//echo $request_query;
	
	$request_data = $this->db->query($request_query);
	$res_array =  $request_data->result_array();
	
	//echo $this->db->last_query();
	if($request_data->num_rows() >0){
		
		 $time_zone = getUserLocalTimeZone($dataArr['user_id']);
			foreach($res_array as $rs){
				
				$ownpost = $rs['reply_from']==$dataArr['reply_from']?1:0;
				
				$tmp_array['id_reply'] =      $rs['id_reply'];
				$tmp_array['id_request'] =    $rs['id_request'];
				//$tmp_array['parent_id'] =     $rs['parent_id'];
				//$tmp_array['reply_to'] =      $rs['reply_to'];
				$tmp_array['reply_from'] =    $rs['reply_from'];
				$tmp_array['reply_content'] = $rs['reply_content'];
				$tmp_array['groupby'] 	 =    $rs['newdate'];
				$tmp_array['reply_date'] =    $rs['reply_date'];
				$tmp_array['ago_time'] =      agoTimePost($rs['reply_date'],$time_zone);
				$tmp_array['reply_from_atype'] =$rs['account_type'];
				$tmp_array['reply_name'] =$rs['name'];
				$tmp_array['reply_image'] =$rs['image_name'];
				$tmp_array['ownpost'] =$ownpost;
				$data_Array[] = $tmp_array;
			}
		
	}


	return $data_Array;
   }
    /**
    *This function fetches the comment on request/product by id
    *@param array $dataArr
    *@return array $chat_array
    */
   public function getreplyCommentById($id_reply,$user_id=0)
   {
	$data_Array = array();

	$record_per_page = $dataArr['record_per_page'];

	$request_query = "SELECT cm_reply.*,date_format(reply_date, '%Y-%m-%d') as newdate
	FROM cm_reply WHERE 1 AND id_reply = '".$id_reply."' ";
	
	//echo $request_query;
	
	$request_data = $this->db->query($request_query);
	$res_array =  $request_data->result_array();
	//echo $this->db->last_query();
	if($request_data->num_rows() >0){
		$time_zone = getUserLocalTimeZone($user_id);
		
		foreach($res_array as $rs){
			
			$ownpost = $rs['reply_from']==$dataArr['reply_from']?1:0;
			
			$tmp_array['id_reply'] =      $rs['id_reply'];
			$tmp_array['id_request'] =    $rs['id_request'];
			//$tmp_array['parent_id'] =     $rs['parent_id'];
			//$tmp_array['reply_to'] =      $rs['reply_to'];
			$tmp_array['reply_from'] =    $rs['reply_from'];
			$tmp_array['reply_content'] = $rs['reply_content'];
			$tmp_array['groupby'] 	 =    $rs['newdate'];
			$tmp_array['reply_date'] =    $rs['reply_date'];
			$tmp_array['ago_time'] =      agoTimePost($rs['reply_date'],$time_zone);
			$tmp_array['reply_from_atype'] =$rs['account_type'];
			$tmp_array['reply_name'] =$rs['name'];
			$tmp_array['reply_image'] =$rs['image_name'];
			$tmp_array['ownpost'] =$ownpost;
			$data_Array[] = $tmp_array;
		}
		
	}

	if(empty($data_Array))
		return $data_Array;
	else
		return $data_Array[0];
   }
    public function getAdvertisementList($status = '',$variable_name)
   {
      $banner_data = array();
      $this->db->select('adv_plan.*');
      $this->db->from('adv_plan');

	if($status !=""){
	       $this->db->where('cstatus',$status);
	}
	
	if($variable_name !="" && $variable_name !="all")
	{
	      $this->db->where('type',$variable_name);
	}
	  
      $this->db->order_by('position asc, id DESC');
      $query= $this->db->get();
      $banner_data = $query->result_array();
      return $banner_data;
   }
   public function updateUserOnLogin($user_id,$arr)
   {
	// update 
   }
   /*public function getUreadMessagesCount($dataArr)
   {
	$count_query = array();
	if($dataArr['type']== "chat_count"){
		//$this->db->select('COUNT(id) AS chat_count');
		//$fb_query = $this->db->get_where('cm_chat', array('seen_status'=>'unread', 'msg_status'=>'0', 'to_id'=> $dataArr['to_id']))->row()->chat_count;
		$sqlQuery = "SELECT COUNT(id) AS data_count FROM cm_chat WHERE seen_status ='unread' AND msg_status ='0' AND to_id = '".$dataArr['to_id']."'";
	}elseif($dataArr['type']== "total_count"){
		//$this->db->select('COUNT(id) AS total_count');
		//$fb_query = $this->db->get_where('cm_chat', array('seen_status'=>'unread', 'msg_status'=>'0', 'to_id'=> $dataArr['to_id']))->row()->total_count;
		$sqlQuery = "SELECT (data_count + chat_count) FROM ( SELECT COUNT(id) AS data_count, (SELECT COUNT(id) FROM cm_chat WHERE seen_status ='unread' AND msg_status ='0' AND to_id = '".$dataArr['to_id']."') AS chat_count FROM cm_notification WHERE to_id = '".$dataArr['to_id']."' AND status = 'Unread') AS total_count WHERE 1";
	}else{
		$sqlQuery = "SELECT COUNT(id) AS data_count FROM cm_notification WHERE to_id = '".$dataArr['to_id']."' AND status = 'Unread'";
	}
	$fb_query = $this->db->query($sqlQuery);
	$count_query = $fb_query >0 ? (int)$fb_query : 0;
	return $count_query;
   }*/
}

/* End of file Webservice_model.php */
/* Location: ./application/models/Webservice_model.php */
?>
