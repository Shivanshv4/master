<?php

class Pages_model extends CI_Model
{

   public function __construct() {
	$this->load->database();
	$this->load->library('mobile_notification');
	$this->load->library('email_notification');
   }

   
   public function create_user($insertArray)
   {
	$this->db->insert('users', $insertArray);
	return  $this->db->insert_id();
   }
   
   public function _is_active_user($username)
   {
	$this->db->select('id,email,password');
	$this->db->where('email',$username);
	//$this->db->where('status','Active');
	$q = $this->db->get('users');
	return $details = $q->row_array();
   }
   public function updateUserLoginHistory($user_id)
   {
        $date=date("Y-m-d");
        $this->db->select('count(*) as count');
	$this->db->where('user_id',$user_id);
	$this->db->where('date_format(loginon,"%Y-%m-%d")',$date);
	$q = $this->db->get('userlogin_history');
        $count = $q->row_array();
	
	 //echo $this->db->last_query();
	 if($count['count']==0)
	 {
	    $loginon=date("Y-m-d H:i:s");
	    $insertArray=array(
			       "user_id"=>$user_id,
			       "loginon"=>$loginon,
			       );
	    $this->db->insert('userlogin_history', $insertArray);
	    $insert_id = $this->db->insert_id();
	    if($insert_id)
	    {
	       $user_data = $this->webservice->getUserDetails($user_id);
	       $active_days = $user_data['active_days']+1;
	       $updatArray=array("active_days"=>$active_days);
	       
	       $this->db->where('id', $user_id);
	       $this->db->update('users', $updatArray);
	       
	    }
	    
	 }
   }
   /**
    ***************************************************************************
    * Code to check if user is valid or not.                                 **
    * @param $username string email address. 				  **
    * @param $pass string password.					  **
    * @return boolean							  **
    * *************************************************************************
    */

   public function _isValid_user($username,$pass)
   {
	$this->db->select('id,email,password');
	$this->db->where('email',$username);
	$this->db->where('password',md5($pass));
	//$this->db->where('status','Active');
	$q = $this->db->get('users');
	$details = $q->row();
	if(count($details) > 0)
	   return TRUE;
	else
	return FALSE;
   }


    public function _isValid_user_webser($username,$pass)
   {
	$this->db->select('id,email,password');
	$this->db->where('email',$username);
	$this->db->where('password',md5($pass));

	$q = $this->db->get('users');
	$details = $q->row();

	if(count($details) > 0)
	   return $details;

	return FALSE;
   }
   public function _getUserbyFBId($fb_id)
   {
	$this->db->select('*');
	$this->db->where('fb_id',$fb_id);
	$q = $this->db->get('users');
	$details = $q->row();

	if(count($details) > 0)
	   return $details;

	return FALSE;
   }
   public function _getUserbyEmail($email)
   {
	$this->db->select('*');
	$this->db->where('email',$email);
	$q = $this->db->get('users');
	$details = $q->row();

	if(count($details) > 0)
	   return $details;

	return FALSE;
   }

   public function valid_all_email($email)
   {
	$this->db->where(array('email'=> $email));
	$q = $this->db->get('users');
	$data = $q->result_array();
	if (!empty($data))
	   return 1;
	else
	   return 0; 
   }
	
	public function update_user($id,$updatArray){
	   $this->db->where('id', $id);
	   //return $this->db->update('users', $updatArray);
	}
	
	public function _isexist_user($username)
	{
	   $this->db->select('*');
	   $this->db->where('email',$username);
	   $this->db->where('status !=','Pending');
	   $this->db->where('status !=','Inactive');
	   $q = $this->db->get('users');
	   $details = $q->row();
	   if(count($details) > 0)
		return TRUE;
	   
	   return FALSE;
	}
	
	// Check user which status is not pending
	public function isEmailExists($email)
	{
	   $this->db->where(array('email'=> $email));
	   $this->db->where(array('status !='=>'Pending'));
	   $q = $this->db->get('users');
	   $data = $q->result_array();
	   //echo $this->db->last_query(); die;
	   if (!empty($data))
		return 1;
	   else
		return 0; 
	}
	/**
	 ***************************************************************************
	 * Code to get user detail by email.                                 	  **
	 * @param $email string email address  				  	  **
	 * @return boolean OR array						  **
	 * *************************************************************************
	 */

	public function _getUser_by_email($email = FALSE)
	{
	   if($email === FALSE)
		return FALSE;

	   $query = $this->db->get_where('users', array('email' => $email));
	   return $query->row_array();
	}
	
	public function _getUser_by_id($uid = FALSE)
	{
	   if($uid === FALSE)
		return FALSE;

	   $query = $this->db->get_where('users', array('id' => $uid,'status'=>'Active'));
	   return $query->row_array();
	}
	
	public function _getuserdetail_by_email($email = FALSE)
	{
	   if($email === FALSE)
		return FALSE;

	   $query = $this->db->get_where('users', array('email' => $email));
	   return $query->row_array();
	}
	
	public function _getMessage($opt)
	{
	   $this->db->select('subject, content');
	   $this->db->where('title', $opt);
	   $q = $this->db->get('message_config');
	   
	   if($q->num_rows() > 0)
	   {
		return $q->row();
	   }
	   return array();
	}
	
	public function _verifyVarificationLink($link_array)
	{
	   $this->db->select('*');
	   $this->db->where('id',$link_array[0]);
	   $this->db->where('activate_code',$link_array[1]);
	   $query = $this->db->get('users');
	   return $query->row_array();
	}
	
	/**
	 *This function is used to add the notifications into the notification table
	 *@param requested data
	 *@return int
	 */
	public function addNotifications($insertArr, $otherData = array())
	{
	   $noti_id =0;
	   $idCategory = $insertArr['id_category'];
	   unset($insertArr['id_category']);
	   if(count($insertArr) >0)
	   {
		switch($insertArr['type'])
		{
		  
		   case "new_reply":
			$re_sqlquery = "SELECT cm_users.device_token,cm_users.notifications,cm_users.name,cm_users.email_alert,cm_users.account_type,cm_reply.* FROM cm_reply INNER JOIN cm_users ON cm_users.id = cm_reply.reply_to WHERE cm_reply.id_reply = '".$insertArr['detail_id']."'";
			$reply_query = $this->db->query($re_sqlquery);
			$reply_data = $reply_query->row_array();

			//
			$re_sqlquery = "SELECT cm_users.device_token,cm_users.notifications,cm_users.name,cm_users.email_alert,cm_users.account_type,cm_reply.* FROM cm_reply INNER JOIN cm_users ON cm_users.id = cm_reply.reply_from WHERE cm_reply.id_reply = '".$insertArr['detail_id']."'";
			$reply_query = $this->db->query($re_sqlquery);
			$sender_reply_data = $reply_query->row_array();
			
			
			$insertArr['created_on'] = date('Y-m-d H:i:s');
			$this->db->insert('notification',$insertArr);
			$noti_id = $this->db->insert_id();
			
			$other_data=array("sname"=>$sender_reply_data['name']);

			if($reply_data['notifications'] == "On" && trim($reply_data['device_token']) !=""){
			   $noti_data = $this->mobile_notification->_sendPushNotification(array($reply_data['device_token']),$reply_data['reply_to'], $reply_data['reply_from'],$insertArr['type'],$reply_data['id_request'],$reply_data['account_type'],$other_data);
			} else if($reply_data['notifications'] == "Off" && trim($reply_data['device_token']) !=""){
			   $noti_data = $this->mobile_notification->_sendPushNotification(array($reply_data['device_token']),$reply_data['reply_to'], $reply_data['reply_from'], 'OffRequest',$reply_data['id_request'],$reply_data['account_type'],$other_data);
			}
			if($reply_data['email_alert'] == "On"){
			   $mail_data = $this->email_notification->_sendEmailNotifications(array('to_id'=>$reply_data['reply_to'], 'from_id'=>$reply_data['reply_from'],'reply_id'=>$reply_data['id_request']),"new_reply");
			}
		   break;
		  
		   default:
			$noti_id =0;
		   break;
		}
	   }
	   return $noti_id ;
	}
	
/**
    *This function is used to read all the notifications on notifiation list page
    */
   public function readAllNotifications($dataArr)
   {
	$updateArr = array('status'=>'Read');
	$noti_query = $this->db->update('notification', $updateArr, array('to_id'=>$dataArr['to_id']));
	return $noti_query ? 1 : 0;
   }
	/**
	 *This function is used to get the unread notification of logged users
	 *@param int $users
	 *@return int count
	 */
	public function getUserUnreadNotifications($user_id)
	{
	   $notification_count = 0;
	   $this->db->select('COUNT(id) AS noti_count');
	   $notification_count = $this->db->get_where('notification',array('to_id'=>$user_id, 'status'=>'Unread'))->row()->noti_count;
	   return $notification_count;
	}
	
	
	public function getUnreadMessage($to_id,$from_id, $product_id = '')
	{
	   $chat_data = array();
	    //$chat_query_old = "SELECT id AS chid , message,addedon, (SELECT COUNT(id) FROM cm_chat WHERE msg_status ='0'  And ( (from_id = '".$to_id."' OR to_id = '".$to_id."') AND (from_id = '".$from_id."' OR to_id = '".$from_id."'))) AS chat_count  FROM cm_chat WHERE ( (from_id = '".$to_id."' OR to_id = '".$to_id."') AND (from_id = '".$from_id."' OR to_id = '".$from_id."') AND message != '') ORDER BY id DESC LIMIT 0,1";
	    $chat_query = "SELECT id AS chid , message,addedon, (SELECT COUNT(id) FROM cm_chat WHERE msg_status ='0'  And (from_id = '".$to_id."' AND to_id = '".$from_id."' AND product_id = '".$product_id."' and delete_status!='All' and deleted_by!='".$from_id."')) AS chat_count  FROM cm_chat WHERE ( (from_id = '".$to_id."' OR to_id = '".$to_id."') AND (from_id = '".$from_id."' OR to_id = '".$from_id."') AND message != '' AND product_id = '".$product_id."') and delete_status!='All' and deleted_by!='".$from_id."' ORDER BY id DESC LIMIT 0,1";
	    //echo "<br/><br/>".$chat_query;
	    
	   $u_query = $this->db->query($chat_query);
	   $chat_data = $u_query->row_array();
	   return $chat_data;
	}
	
}
