<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_model extends CI_Model
{
   /**
    * Product Model using is related to general functions to fetch
    * the information from database.
    *
    *
    * @category 	model
    * @package 	application_models
    * @version 	0.0.1
    * @author 	Singsys Pte. Ltd. <info@singsys.com>
    * dated  	2015-08-07
    */
   
   //class constructor
   public function __construct(){
	parent::__construct();
   }
   
    public function updateFeatured($product_id,$status)
   {
     $date = date("Y-m-d H:i:s");
	if(empty($product_id))
	   return FALSE;

	$query = $this->db->update('products', array('featured_product'=>"Yes","featured_producton"=>$date) ,array('id'=>$product_id));
	//echo $this->db->last_query(); 
	return $query;
   }  
   
   /**
    *this method returns the all products under a shop owner
    *@param $shop_id
    *@return array
    */
   public function getProductList($shop_id=0,$status="", $featured ='',$forder_by='')
   {
	  $product_data = array();
	  $this->db->select('products.*');
	  $this->db->from('products');
	  $this->db->select('users.name as shop_owner');
	  $this->db->select('category.category_name');
	  $this->db->join('users','users.id = products.shop_id','inner');
	  $this->db->join('category','category.id_category = products.id_category','inner');
	  if($shop_id >0){
		 $this->db->where('products.shop_id',$shop_id);
	  }
	  if($status !=""){
		 $this->db->where('products.cstatus',$status);
	  }
	  if($featured) {
		$this->db->where('products.featured',$featured);
	  }
	  if($forder_by=="featured")
	  {
	       
	       $this->db->order_by('featured_producton','DESC');
	       $this->db->order_by('featured','DESC');
	     $this->db->order_by('id','DESC');  
	  }
	  else{
	  $this->db->order_by('id','DESC');
	  }
	  
	  $query= $this->db->get();
	  $product_data = $query->result_array();
	  //echo $this->db->last_query();
	  //global $product_type;
	  
	  foreach($product_data as $rs)
	  {
		  $rs['productimages'] = $this->webservice->get_product_image($rs['id']);
		  if(count($rs['productimages'])) {
		   $rs['image'] = $rs['productimages'][0]['image'];
		  }

		    //$rs['product_type'] = $product_type[$rs['product_type']];
		  $dataArr[] = $rs;
	  }
	  
      return $dataArr;
   }
   
   /**
    *This function is used to add product data
    *@param array $productdata
    *@return int
    */
   public function save_productData($productdata)
   {
	if(isset($productdata['id']) && $productdata['id']>0){
	   $productId = $productdata['id'];
	   $query = $this->db->update('products', $productdata ,array('id'=>$productId));
	   return $query;
	}else{
	   $this->db->insert('products', $productdata);
	   $product_id = $this->db->insert_id();
	   return $product_id;
	}
   }
   
   /**
    *This function deletes the product details from database
    *@return array $admin_data
    */
   public function delete_productData($product_id)
   {
	try{
	   //$this->db->trans_begin();
	   $delete_request = $this->db->delete("request",array('product_id'=> $product_id));
	   $delete_ureviews = $this->db->delete("reviews",array('product_id'=> $product_id));
	   $delete_sfs = $this->db->delete("sfs",array('product_id'=> $product_id));
	   $delete_sfs = $this->db->delete("notification",array('detail_id'=> $product_id, 'type'=>'new_product'));
	   $delete_product = $this->db->delete("products",array('id'=> $product_id));
	   if ($this->db->trans_status() === FALSE)
	   {
		$this->db->trans_rollback();
		return FALSE;
	   }
	   else
	   {
	        // set all message as delete_status=All
		 $sql = "UPDATE cm_chat SET delete_status = 'All' WHERE
		  product_id = '".$product_id."' and chat_type='product' ";
		  
		  $this->db->query($sql);
		  
		   $sql = "UPDATE cm_chatgroup SET delete_status = 'All' WHERE
		  product_id = '".$product_id."' and chat_type='product' ";
		  
		  $this->db->query($sql);
		  
		$this->db->trans_commit();
		return TRUE;
	   }
	}catch(Exception $ex){
	   return FALSE;
	}
   }
   
   /**
    *Check whether user exists or not
    *@param string $u_email, int $user_id
    *@return boolean
    */
   public function changeStatus($product_id,$status)
   {
	if(empty($product_id))
	   return FALSE;

	$query = $this->db->update('products', array('cstatus'=>$status) ,array('id'=>$product_id));
	return $query;
   }
   
   public function GetProductById($id = '')
   {
	$admin_data =array();
	if($id >0) {
	   $this->db->select('products.*');
	   $this->db->from('products');
	   $this->db->select('users.name as shop_owner');
	   $this->db->join('users','users.id = products.shop_id','inner');
	   $this->db->where('products.id',$id);
	   $query= $this->db->get();
	   $admin_data = $query->row_array();
	}
	return $admin_data;
   }
   
   /**
    *this method returns the all categories under a shop owner
    *@param $status
    *@return array
    */
   public function getCategoryList($status="",$limit=array())
   {
	$category_data = array();
	if($status !="" && $status != 'Deleted'){
	   $this->db->where('category_status',$status);
	}else{
	   $this->db->where('category_status !=','Deleted');
	}
	$this->db->order_by('cat_order','ASC');
	if(is_array($limit) && count ($limit)>0){
	   $this->db->limit($limit[0],$limit[1]);
	}
      $query= $this->db->get('category');
	$category_data = $query->result_array();
      return $category_data;
   }
   
   /**
    *This function is used to get the category data on basis of category id
    *@param $id category id
    *@return array
    */
   public function GetCategoryById($id = '')
   {
	$category_data =array();
	if($id >0) {
	   $this->db->where('id_category =',$id);
	   $query= $this->db->get('category');
	   $category_data = $query->row_array();
	}
	return $category_data;
   }
   
   /**
    *This function is used to add category data
    *@param array $productdata
    *@return int
    */
   public function save_categoryData($categorydata)
   {
	if(isset($categorydata['id_category']) && $categorydata['id_category']>0){
	   $categoryId = $categorydata['id_category'];
	   $categorydata['updated_on']= date('Y-m-d H:i:s');
	   $query = $this->db->update('category', $categorydata ,array('id_category'=>$categoryId));
	   return $query;
	}else{
	   unset($categorydata['id_category']);
	   $categorydata['added_on']= date('Y-m-d H:i:s');
	   $categorydata['updated_on']= date('Y-m-d H:i:s');
	   $this->db->insert('category', $categorydata);
	   $category_id = $this->db->insert_id();
	   return $category_id;
	}
   }
   
    /**
    *change category status
    *@param string $status, int $id_category
    *@return boolean
    */
   public function changeCatgoryStatus($id_category,$status)
   {
	if(empty($id_category))
	   return FALSE;
	
	if($status == 'Deleted')
	{
	   $p_query = $this->db->update('products', array('id_category'=>'0') ,array('id_category'=>$id_category));
	}
	$query = $this->db->update('category', array('category_status'=>$status) ,array('id_category'=>$id_category));
	return $query;
   }
   
   public function getTotalCategoryCount()
   {
	$this->db->select('COUNT(id_category) AS total_category');
	$fb_query = $this->db->get_where('category', array('category_status'=>'Active'))->row()->total_category;
	$total_category = $fb_query >0 ? (int)$fb_query :0;
	return $total_category;
   }

}
?>
