<?php

class Banner_model extends CI_Model
{

   public function __construct() {
	$this->load->database();
	$this->load->library('mobile_notification');
	$this->load->library('email_notification');
   }

   
   public function getBannerList($status="")
   {
      $banner_data = array();
      $this->db->select('banner.*,banner_type.name as banner_type_name ');
      $this->db->from('banner');
      $this->db->join('banner_type','banner.banner_type = banner_type.id','left');
      if($status !=""){
	 $this->db->where('cstatus',$status);
      }
      $this->db->order_by('banner_id','DESC');
      $query= $this->db->get();
      $banner_data = $query->result_array();
      return $banner_data;
   }
   // All active/Inactive
   public function getBannerAllList($status = 'Active')
   {
      $banner_data = array();
      $this->db->select('banner.*,banner_type.name as banner_type_name ');
      $this->db->from('banner');
      $this->db->join('banner_type','banner.banner_type = banner_type.id','left');
      if($status !=""){
	 $this->db->where('cstatus',$status);
      }
      $this->db->order_by('banner_id','DESC');
      $query= $this->db->get();
      $banner_data = $query->result_array();
      return $banner_data;
   }
   /**
    *This function deletes the product details from database
    *@return array $admin_data
    */
   public function delete_bannerData($product_id)
   {
	try{
	   //$this->db->trans_begin();
	  
	   $delete_product = $this->db->delete("banner",array('banner_id'=> $product_id));
	   if ($this->db->trans_status() === FALSE)
	   {
		$this->db->trans_rollback();
		return FALSE;
	   }
	   else
	   {
		$this->db->trans_commit();
		return TRUE;
	   }
	}catch(Exception $ex){
	   return FALSE;
	}
   }
   public function getBannerType()
   {
      $banner_data = array();
      $this->db->select('banner_type.*');
      $this->db->from('banner_type');
      
      $this->db->order_by('id','DESC');
      $query= $this->db->get();
      $banner_data = $query->result_array();
      return $banner_data;
   }
   public function getBannerTypeById()
   {
      $banner_data = array();
      $this->db->select('banner_type.*');
      $this->db->from('banner_type');
      
      $this->db->order_by('id','DESC');
      $query= $this->db->get();
      $banner_data = $query->result_array();
      return $banner_data;
   }
   public function getAdvertisementAllList($status = '')
   {
      $banner_data = array();
      $this->db->select('adv_plan.*');
      $this->db->from('adv_plan');

	  if($status !=""){
		 $this->db->where('cstatus',$status);
	  }
      $this->db->order_by('position asc, id DESC');
      $query= $this->db->get();
      $banner_data = $query->result_array();
      return $banner_data;
   }

   public function GeAdvertisementById($id = '')
   {
	$admin_data =array();
	if($id >0) {
	    $this->db->select('adv_plan.*');
	   $this->db->from('adv_plan');
	   $this->db->where('id',$id);
	   $query= $this->db->get();
	   $admin_data = $query->row_array();
	}
	return $admin_data;
   }

    /**
    *This function is used to add product data
    *@param array $productdata
    *@return int
    */
   public function save_advertisementData($rowdata)
   {
	if(isset($rowdata['id']) && $rowdata['id']>0){
	   $rowId = $rowdata['id'];
	   $query = $this->db->update('adv_plan', $rowdata ,array('id'=>$rowId));
	   return $query;
	}else{
	  $rowdata['added_on'] = date('Y-m-d H:i:s');
	  unset($rowdata['id']);
	   $this->db->insert('adv_plan', $rowdata);
	   $isert_id = $this->db->insert_id();
	   echo $this->db->last_query();
	   return $isert_id;
	}
   }

   public function GetBannerById($id = '')
   {
	$banner_data =array();
	if($id >0) {
	   $this->db->select('banner.*');
	   $this->db->from('banner');
	   $this->db->where('banner_id',$id);
	   $query= $this->db->get();
	   $banner_data = $query->row_array();
	}
	return $banner_data;
   }

   /**
    *This function is used to add edit banner data
    *@param array $productdata
    *@return int
    */
   public function save_bannerData($bannerdata)
   {

	if(isset($bannerdata['banner_id']) && $bannerdata['banner_id']>0){
	   $bannerId = $bannerdata['banner_id'];
	   $query = $this->db->update('banner', $bannerdata ,array('banner_id'=>$bannerId));

	   return $query;
	}else{
	   $this->db->insert('banner', $bannerdata);
	   $banner_id = $this->db->insert_id();
	   return $banner_id;
	}
   }
}
