<?php

class General_model extends CI_Model
{

   public function __construct() {
	$this->load->database();
	$this->load->library('mobile_notification');
	$this->load->library('email_notification');
	
	/*
	set_exception_handler('exception_handler');
	throw new Exception('Uncaught Exception');
	*/
   }

   
   public function insert($table_name,$insertArray)
   {
      if($insertArray && $table_name)
      {
	 $this->db->insert($table_name, $insertArray);
	 return  $this->db->insert_id();
      }
      else{
	 return FALSE;
      }
   }
   
   public function update($table_name,$insertArray,$where="")
   {
      if($insertArray && $table_name)
      {
	 if($where)
	    $this->db->where($where);
	 else
	    $this->db->where('id', $insertArray['id']);
	 
	 $query = $this->db->update($table_name, $insertArray);
	 return $query;
      }
      else{
	 return FALSE;
      }
   }
   
   public function select($table_name,$id,$where="")
   {
      $data = array();
      $this->db->select('*');
      if($id>0)
      {
	 $this->db->where('id',$id);
	 
	 if($where)
	 {
	    $this->db->where($where);
	 }
	 
	 $q = $this->db->get($table_name);
	 $data = $q->row_array();
      }
      else{

	 if($where)
	 {
	    $this->db->where($where);
	 }
	 
	 $q = $this->db->get($table_name);
	 $data = $q->result_array();
      }
      
	 return $data;      
   }
   
}
