<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cron extends CI_Controller
{

   /**
    * Index Page for this controller.
    *
    * Maps to the following URL
    * 		http://example.com/index.php/acron
    *	- or -  
    * 		http://example.com/index.php/cron/index
    *	- or -
    * Since this controller is set as the default controller in 
    * config/routes.php, it's displayed at http://example.com/
    *
    * So any other public methods not prefixed with an underscore will
    * map to /index.php/cron/<method_name>
    *
    *
    *@category 	controller
    *@package 	application_controllers
    *@author 	Singsys Pte. Ltd. (00130) <info@singsys.com>
    *@version 	0.0.1
    *dated  	2015-07-07
    */
   
   /**
    *Default class constructor
    */
   public function __construct()
   {
	//load parent class constructor
	parent::__construct();
	$this->load->model('webservice_model');
   }
   
 
   /**
    *generate log file
    */
   public function logCrawlErrors($msg="")
   {
	$myfile = APPPATH.'logs/cron-log.txt';
	if(file_exists($myfile)):
	   $write_txt  = file_get_contents($myfile);
	   $write_txt .= date('d M Y H:i:s')."\t\t".$msg."\r\n";
	   file_put_contents($myfile, $write_txt);
	else:
	   $myfile = fopen($myfile, "w") or die("Unable to open file!");
	   $write_txt = date('d M Y H:i:s')."\t\t".$msg."\r\n";
	   fwrite($myfile, $write_txt);
	   fclose($myfile);
	endif;
   }

}

/* End of file Cron.php */
/* Location: ./application/controllers/Cron.php */
?>