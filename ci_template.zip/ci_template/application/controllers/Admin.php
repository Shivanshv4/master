<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller
{

   /**
    * Index Page for this controller.
    *
    * Maps to the following URL
    * 		http://example.com/index.php/admin
    *	- or -  
    * 		http://example.com/index.php/admin/index
    *	- or -
    * Since this controller is set as the default controller in 
    * config/routes.php, it's displayed at http://example.com/
    *
    * So any other public methods not prefixed with an underscore will
    * map to /index.php/login/<method_name>
    *
    *
    *@category 	controller
    *@package 	application_controllers
    *@author 	Singsys Pte. Ltd. (00130) <info@singsys.com>
    *@version 	0.0.1
    *dated  	2015-07-07
    */
   
     /**
      *Default class constructor
      */
     public function __construct()
     {
	  //load parent class constructor
	  parent::__construct();
	  $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
	  $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
	  $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
	  $this->output->set_header('Pragma: no-cache');
	  $this->output->enable_profiler(FALSE);
	  $this->load->model('pages_model');
	  $this->load->model('webservice_model');
	  $this->load->model('banner_model');
     }
   
     /**
      *Default action for the admin controller or landing function
      */
     public function index()
     {
	  $email 	= $this->input->post('user_email');
	  $password 	= $this->input->post('password');
	  
	  if ($this->session->userdata('loggedin') == TRUE) {
	     redirect('admin/dashboard');
	  }else{
	       $data['title'] ="Login";
	       $this->form_validation->set_rules('user_email', 'Email', 'trim|required|valid_email');
	       $this->form_validation->set_rules('password', 'Password', 'trim|required|callback__verify_user');
	       if(trim($email) != '' && trim($password) != '' && valid_email($email))
	       {
		    $this->form_validation->set_rules('verify', 'Verify', 'callback__verify_user');
	       }
	       if ($this->form_validation->run() == false)
	       {
		    _getLoadViewAdmin('login', $data);
	       }else
	       {
		    $admin_data = $this->admin_model->adminUserData($email, $password);
		    $this->session->set_userdata('loggedin', TRUE);
		    $this->session->set_userdata('id_admin', $admin_data['id']);
		    $this->session->set_userdata('admin_name', $admin_data['user_name']);
		    $this->session->set_userdata('admin_email', $admin_data['email']);
		    redirect('admin/dashboard');
	       }
	  }
     }
   
    
     /**
      *Default action for the admin controller or landing function
      */
     public function dashboard()
     {
	  if ($this->session->userdata('loggedin') == TRUE) {
	     $data['title'] ="Dashboard";
	     $data['user_count'] = $this->admin_model->_getUserCountByType();
	     $data['contact_count'] = $this->admin_model->_getContactCount();
	   _getLoadViewAdmin('dashboard', $data);
	}
	  else
	  {
	     redirect('admin');
	  }
     }
   

     /**
      *Function to validate the user by useremail and password whether exists or not
      *@param $username user name entered by user
      *@param $password user password entered by user
      *@return boolean TRUE|FALSE if exists TRUE and set session
      */
     public function _verify_user()
     {
	  $useremail = trim($this->input->post('user_email'));
	  $password = trim($this->input->post('password'));
	  $admin_data = $this->admin_model->adminUserData($useremail, $password);
	  if ($admin_data['id'] >0)
	  {
	     return TRUE;
	  }
	  else
	  {
	     $this->form_validation->set_message('_verify_user', 'Incorrect Combination Of Email and Password');
	     return FALSE;
	  }
     }
   
     /**
      *Function to validate the user by useremail and password whether exists or not
      *@param $username user name entered by user
      *@param $password user password entered by user
      *@return boolean TRUE|FALSE if exists TRUE and set session
      */
     public function _checkAdminUser()
     {
	  $useremail = trim($this->input->post('user_email'));
	  $admin_data = $this->admin_model->_getAdminDataByEmail($useremail);
	  if ($admin_data['id'] >0)
	  {
	     return TRUE;
	  }
	  else
	  {
	     $this->form_validation->set_message('_checkAdminUser', 'Please enter valid admin email address.');
	     return FALSE;
	  }
     }
      
     /**
      *Function to is used to logout the current user and destroy session
      *@return array loaded view
      */
     public function logout()
     {
	  $insertArr = array('id'=>$this->session->userdata('id_admin'),'last_login'=>date('Y-m-d H:i:s'));
	  $this->admin_model->updateAdminUser($insertArr);
	  $this->session->unset_userdata('id_admin');
	  $this->session->unset_userdata('loggedin');
	  $this->session->unset_userdata('admin_name');
	  $this->session->unset_userdata('admin_email');
	  redirect('admin');
     }
   
     /**
      *This function is used to reset the password using forget password link
      *@param string $email
      *@return loaded view
      */
     public function forgot_password()
     {
	  if ($this->session->userdata('loggedin') == TRUE) {
	     redirect('admin/dashboard');
	}
	  $data['title'] ="Forgot Password";
	  if($this->input->server('REQUEST_METHOD') === "POST")
	  {
	     $email = trim($this->input->post('user_email'));
	     $data['user_details'] = array('user_email' => $email);
	     $this->form_validation->set_rules('user_email', 'Email', 'trim|required|strip_tags|callback__checkAdminUser');
	     if($this->form_validation->run() == TRUE){
		 
		$generated_code = random_string();
		$admin_data = $this->admin_model->_getAdminDataByEmail($email);
		
		$updateArray = array(
				     'code' => $generated_code,
				     );
		$DataArr1 = $this->admin_model->update_admin($updateArray,$admin_data['id']);
		
		$link = base_url().'admin/reset_password/'.$generated_code;
		
	     
		////////// send email
		 $email_data['link'] = $link;
  
		 if(send_email($email,"admin_forgot_password",$email_data))
		 {
			_showMessage("Please check your E-mail to reset your password.",'success');
		 }
		 else{
		      _showMessage("Mail not sent.",'error');
			  
		 }
	     }
	  }
	  _getLoadViewAdmin('forgot_password', $data);
	  
     }
   
/**
 *This function is used to reset the password using forget password link
 *@param string $email
 *@return loaded view
 */
public function reset_password()
{
     if ($this->session->userdata('loggedin') == TRUE) {
	redirect('admin/dashboard');
     }
     $data['title'] ="Reset Password";
     
     $code= $this->uri->segment(3);
     $admin_data = $this->admin_model->_getAdminDataById(1);
     
     if($this->input->server('REQUEST_METHOD') === "POST")
     {
	  $password = trim($this->input->post('password'));
	  $c_password = trim($this->input->post('c_password'));
	  $data['user_details'] = array('password' => $password, 'c_password' => $c_password,);
	  $this->form_validation->set_rules('password', 'Password', 'trim|required|strip_tags|min_length[6]|max_length[15]');
	  $this->form_validation->set_rules('c_password', 'Confirm Password', 'trim|required|strip_tags|min_length[6]|max_length[15]|matches[password]');
	  if($this->form_validation->run() == TRUE){
	      
	     
		 if($code==$admin_data['code'] && !empty($code))
		 {
		     $updateArray = array(
				    'code' => "",
				    );
		     $DataArr1 = $this->admin_model->update_admin($updateArray,$admin_data['id']);
	       
		     $admin_data = $this->admin_model->updateAdminPassword($data['user_details']);
		     
		     $data['user_details']="";
		     _showMessage('Password has been reset successfully.','success');
		     redirect(site_url("admin"));
		 }
		 else{
		     _showMessage('Password can not be reset code is expired.','error');
		     redirect(site_url("admin"));
		 }
	  }
     }
     else if($code!=$admin_data['code'] || $admin_data['code']=="")
     {
       
       _showMessage('Password can not be reset code is expired.','error');
	//redirect("admin/reset_password/".$code);
     }
     _getLoadViewAdmin('reset_password', $data);
     $this->session->set_flashdata('flash_msg');
}
     /**
      *This function is used to reset the password using forget password link
      *@param string $email
      *@return loaded view
      */
     public function users()
     {
	
	 if ($this->session->userdata('loggedin') == FALSE) {
	    redirect('admin');
	 }
	 $data['title'] ="User Management";
	 
	 //$data['users_data'] = $this->admin_model->getAllUsers('', 'All');
	 _getLoadViewAdmin('user_list', $data);
     }
     
     public function users_data()
     {
	 if ($this->session->userdata('loggedin') == FALSE) {
	     redirect('admin');
	  }
	   $requestData= $_REQUEST;
	  
	    $columns = array( 
	    // datatable column index  => database column name
	      0 =>'u.name', 1 =>'u.email');
     
	    $db_prefix=$this->db->dbprefix;
	    
	    $query = 'SELECT u.* from '.$db_prefix.'users as u where 1';
     
	    if( !empty($requestData['search']['value']) ) {   
	    // if there is a search parameter, $requestData['search']['value'] contains search parameter
	      $sql.=" and ( u.name LIKE '%".$requestData['search']['value']."%' or u.email LIKE '%".$requestData['search']['value']."%' or u.image_name LIKE '%".$requestData['search']['value']."%' ) ";   
	    } 
	    $q = $this->db->query($query. $sql);
	    $count = $q->result_array();
     
	    if(!empty($columns[$requestData['order'][0]['column']]))
	    {
	    $sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']." ";
	    }
	    
	    if(!empty($requestData['length']))
	    $sql.="   LIMIT ".$requestData['start']." ,".$requestData['length'];
	    
	    
	    $q = $this->db->query($query. $sql);
	    $admin_data = $q->result_array();
	    
	    $data = array();
	    foreach ($admin_data as $value)  {
	    
	    // preparing an array   
	    $link="";
	    
	    $link .='<a href="'.site_url('admin/add_user/'.base64_encode($value['id'])).'" alt="Edit User" title="Edit User"><img src="'.base_url().'lib/images/admin_edit.png"/></a>';
	    
		       
	    $link .='<a href="'.site_url('admin/delete_user/'.base64_encode($value['id'])).'" alt="Delete User" title="Delete User" onclick="return confirm(\'Are you sure to delete this user ?\');"><img src="'.base_url().'lib/images/delete_admin.png"/></a>';
			   
			 
	      $nestedData=array();
	      $nestedData[] = $value['name'];
	      $nestedData[] = $value['email'];
		  $nestedData[] = $value['image_name'];
	      $nestedData[] = $link;
	      
	      $data[] = $nestedData;
	    }
	    
	    $json_data = array(
		"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
		"recordsTotal"    => intval( count($admin_data) ),  // total number of records
		"recordsFiltered" => intval( count($count)  ), // total number of records after searching, if there is no searching then totalFiltered = totalData
		"data"            => $data   // total data array
	    );
	    
	    echo json_encode($json_data);
	    
     }
   

     /** 
      *This function is used to reset the password using forget password link
      *@param string $email
      *@return loaded view
      */
     public function add_user()
     {
       
	  if ($this->session->userdata('loggedin') == FALSE) {
	     redirect('admin');
	  }
	  $data['title'] ="Add User";
	  if(@$this->uri->segment(3) && @$this->uri->segment(3)!= FALSE){
	     $id_user = base64_decode(@$this->uri->segment(3));
	     if($id_user >0){
		  $data['user_details'] = $this->admin_model->getuser_byid($id_user);
		  $user_account_type = $data['user_details']['account_type'];

		   $data['title'] ="Edit User";
		  
		 $old_email 		= $data['user_details']['email'];
	     }
	     else{
		 $old_email 		= trim($this->input->post('old_email'));
	     }
	  }
	   $data['old_email']=$old_email;
	  if($this->input->server('REQUEST_METHOD') === "POST")
	  {
	       $name 		= strip_tags(trim($this->input->post('user_name')));
	       $email 		= strip_tags(trim($this->input->post('user_email')));
	       $password 	= strip_tags(trim($this->input->post('password')));
	       $cpassword 	= strip_tags(trim($this->input->post('cpassword')));

	       
	       
	       $data['user_details'] = array(
						  'name'         => $name,
						  'email'        => $email,
					     );
	       
	       $data['user_details']['id'] = trim($this->input->post('user_id'));
	       //Put all the required validations
	       $this->form_validation->set_rules('user_name', 'Name', 'trim|required|strip_tags');
	       if(empty($old_email) || $email!=$old_email)
	       {
		  $this->form_validation->set_rules('user_email', 'Email', 'trim|required|valid_email|strip_tags|callback__checkUserEmailIsUnique');
	       }

	       //run the validations
	       if($this->form_validation->run() == TRUE)
	       {

		    if($data['user_details']['id'] >0){
			
		       $user_id = $this->admin_model->save_userData($data['user_details']);
		       
		       
		       $this->session->set_flashdata('flash_msg','User account has been updated successfully.');
		    }
		    
	       
		   redirect('admin/users');
	       
	       }
	  }
	  _getLoadViewAdmin('add_user', $data);
     }
   
   /**
    *This function is used to delete the user from database
    *@param Request data
    *@return loaded view
    */
     public function delete_user()
     {
	  if ($this->session->userdata('loggedin') == FALSE) {
	     redirect('admin');
	}
	  $data['title'] ="Delete User";
	  $user_id = @$this->uri->segment(3);
	  
	  $type = @$this->uri->segment(4);
	  
	  if($user_id !=""){
	     $user_data = $this->admin_model->getuser_byid(base64_decode($user_id));
     
	     @unlink(FCPATH.'uploads/users_profile/'.$user_data['image_name']);
	     @unlink(FCPATH.'uploads/users_profile/thumb_'.$user_data['image_name']);
	     $del_user = $this->admin_model->delete_userData(base64_decode($user_id));
	     $this->session->set_flashdata('flash_msg','User account has been deleted successfully.');
	  }
	  
	  redirect('admin/users');
	  
     }
   
   /**
    *This function is used to view the user profile
    *@param Request data
    *@return loaded view
    */
     public function view_user()
     {
	  if ($this->session->userdata('loggedin') == FALSE) {
	     redirect('admin');
	}
	  $data['title'] ="View User Details";
	  $user_id = @$this->uri->segment(3);
	  if($user_id !=""){
	     $data['user_details'] = $user_data = $this->webservice_model->getUserDetails(base64_decode($user_id));
	     if(count($user_data) == 0){
		  $this->session->set_flashdata('flash_msg','User does not exists.');
		  redirect('admin/users');
	     }
	  }
	  _getLoadViewAdmin('user_details', $data);
     }
   
  
     /**
      *This function is used to check whether email is unique or not
      *@param int user id, string user email
      */
     function _checkUserEmailIsUnique()
     {
	  $user_id = trim($this->input->post('user_id'));
	  $user_email = trim($this->input->post('user_email'));
	  if($user_email){ 
	     $user_unique = $this->admin_model->checkemail_byemail($user_email);
	     
	     if($user_unique == TRUE){
		  $this->form_validation->set_message('_checkUserEmailIsUnique', 'The Email field must contain a unique value.');
		  return FALSE;
	     }
	  }
	  return TRUE;
     }
     /**
     *This function is used to validate the phone number
     *@param string $str
     *@return Boolean
     */
     function _valid_phone_number()
     {
	  $str = trim($this->input->post('phone_number'));
	  $regex = "/[0-9 ():.,+-]$/i";
	  if(preg_match($regex,$str)){
	     return true;
	  }
	  else{
	     $this->form_validation->set_message('_valid_phone_number', 'Invalid Contact Number.');
	     return FALSE;
	  }
     }
   
     /**
     *This function is used to validate the phone number
     *@param string $str
     *@return Boolean
     */
     function _fileNameValidation()
     {
	  $image_name = trim($this->input->post('image_name'));
	  if(empty($image_name)){
	     $this->form_validation->set_message('_fileNameValidation', 'Please select Profile Image.');
	     return FALSE;
	  }
	  return TRUE;
     }
     function _fileUploadValidation()
     {
	 $allowed_extension = array('jpg','jpeg','JPG','JPEG','gif','GIF','png','PNG');
	 $filename = $_FILES['profile_image']['name'];
	 $file_extension = _getExtension($filename);
	 $allowed_size = 2097152;//2mb
	 if(!in_array($file_extension, $allowed_extension)){
	    $this->form_validation->set_message('_fileUploadValidation', 'The filetype you are attempting to upload is not allowed.');
	    return FALSE;
	 }elseif(in_array($file_extension, $allowed_extension) && $_FILES['profile_image']['size'] > $allowed_size)
	 {
	    $this->form_validation->set_message('_fileUploadValidation', 'The file you are attempting to upload is larger than the permitted size.');
	    return FALSE;
	 }
	 return TRUE;
     }
   
     /**
    *This function is used to change the status of the user
    *@param  requested data
    *@return loadded view
    */
     public function change_status()
     {
	  $sdata = array();
	  if ($this->session->userdata('loggedin') == FALSE) {
	     redirect('admin');
	  }
	  $data['title'] ="Change Status";
	  $user_id = $this->input->post('user_id');
	  $status = $this->input->post('status');
	  if($user_id !=""){
	     $user_status = $this->admin_model->changeStatus($user_id,$status);
	     $this->session->set_flashdata('flash_msg','User status has been changed successfully.');
	     $sdata['success'] = 'success';
	  }
	  echo json_encode($sdata);
     }
   
   
   /**
    *This function is used to list the static content pages
    *@return loaded view
    */
   public function static_content()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Static Content Management";
	$data['content_list'] = $this->admin_model->getStaticContent();
	_getLoadViewAdmin('static_content', $data);
   }
   
   public function emailmessage()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Static Content Management";
	$data['message_list'] = $this->admin_model->getmessageConfig();
	_getLoadViewAdmin('message_config', $data);
   }
   
   /**
    *This function is used to add the product
    *@param string $email
    *@return loaded view
    */
   public function add_content()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Add Content";
	if(@$this->uri->segment(3) && @$this->uri->segment(3)!= FALSE){
	   $data['title'] ="Edit Content";
	   $id_content = base64_decode(@$this->uri->segment(3));
	   if($id_content >0){
		$data['content_details'] = $this->admin_model->getStaticContent($id_content);
	   }
	}
	if($this->input->server('REQUEST_METHOD') === "POST")
	{
	   $content_title = trim($this->input->post('content_title'));
	   $variable_name = trim($this->input->post('variable_name'));
	   $content = trim($this->input->post('content'));
	   $status = trim($this->input->post('status'));
	   $data['content_details'] = array(
						'content_title'=> strip_tags($content_title),
						'variable_name'=> strip_tags($variable_name),
						'content'      => strip_tags($content,'<br><br/><p><ul><li><strong><em>'),
						'status'       => $status
					   );
	   $data['content_details']['id'] = trim($this->input->post('content_id'));
	   //Put all the required validations
	   $this->form_validation->set_rules('content_title', 'Title', 'trim|required|strip_tags');
	   if(@$this->uri->segment(3) && @$this->uri->segment(3)!= FALSE){
		$this->form_validation->set_rules('variable_name', 'Variable Name', 'trim|required|strip_tags');
	   }else{
		$this->form_validation->set_rules('variable_name', 'Variable Name', 'trim|required|strip_tags|is_unique[cm_static_content.variable_name]');
	   }
	   
	   $this->form_validation->set_rules('content', 'Content', 'trim|required|strip_tags|callback__checkContentDescription');
	   $this->form_validation->set_rules('status', 'Status', 'trim|required|strip_tags');

	   //run the validations
	   if($this->form_validation->run() == TRUE)
	   {
		if($data['content_details']['id'] >0){
		   
		   $content_id = $this->admin_model->save_contentData($data['content_details']);
		   $this->session->set_flashdata('flash_msg','Content has been updated successfully.');
		}
		else{
		   $content_id = $this->admin_model->save_contentData($data['content_details']);
		   $this->session->set_flashdata('flash_msg','Content has been saved successfully.');
		}
		redirect('admin/static_content');
	   }
	}
	_getLoadViewAdmin('add_content', $data);
   }
   
   public function editmessage()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Add Message";
	if(@$this->uri->segment(3) && @$this->uri->segment(3)!= FALSE){
	   $data['title'] ="Edit Message";
	   $id_content = base64_decode(@$this->uri->segment(3));
	   if($id_content >0){
		$data['content_details'] = $this->admin_model->getmessageConfig($id_content);
	   }
	}
	if($this->input->server('REQUEST_METHOD') === "POST")
	{
	   $subject = trim($this->input->post('subject'));
	   //$variable_name = trim($this->input->post('variable_name'));
	   $content = trim($this->input->post('content'));
	   $status = trim($this->input->post('status'));
	   $data['content_details'] = array(
						'subject'=> strip_tags($subject),
						'content'      => strip_tags($content,'<br><br/><p><ul><li><strong><em>'),
						'status'       => $status
					   );
	   $data['content_details']['id'] = trim($this->input->post('content_id'));

	   $this->form_validation->set_rules('subject', 'Subject', 'trim|required|strip_tags');
	   $this->form_validation->set_rules('content', 'Message', 'trim|required|strip_tags|callback__checkContentDescription');
	   $this->form_validation->set_rules('status', 'Status', 'trim|required|strip_tags');

	   //run the validations
	   if($this->form_validation->run() == TRUE)
	   {
		if($data['content_details']['id'] >0){
		   
		   $content_id = $this->admin_model->save_messageconfig($data['content_details']);
		   $this->session->set_flashdata('flash_msg','Message has been updated successfully.');
		}
		else{
		   $content_id = $this->admin_model->save_messageconfig($data['content_details']);
		   $this->session->set_flashdata('flash_msg','Message has been saved successfully.');
		}
		redirect('admin/emailmessage');
	   }
	}
	_getLoadViewAdmin('edit_message', $data);
   }
   
   /**
    *This function is used to view the static content
    *@param Request data
    *@return loaded view
    */
   public function view_content()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="View Content Details";
	$id_content = @$this->uri->segment(3);
	if($id_content !="" || $id_content >0){
	   $data['content_details'] = $content_data = $this->admin_model->getStaticContent(base64_decode($id_content));
	   if(count($content_data) == 0){
		$this->session->set_flashdata('flash_msg','Content does not exists.');
		redirect('admin/static_content');
	   }
	}
	_getLoadViewAdmin('content_details', $data);
   }
   
   /**
    *This function is used to remove tags from content
    *@return boolean
    */
   function _checkContentDescription()
   {
	$str_description = strip_tags($this->input->post('content'));
	$description = str_replace('&nbsp;','',trim($str_description));
	if($description == "" || strlen($description) == 0){
	   $this->form_validation->set_message('_checkContentDescription', 'Please enter Content.');
	   return FALSE;
	}
	return TRUE;
   }
   
   /**
    *This function is used to change the status of the static content
    *@param  requested data
    *@return loadded view
    */
   public function change_content_status()
   {
	$sdata = array();
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Change Status";
	$content_id = $this->input->post('content_id');
	$status = $this->input->post('status');
	if($content_id !=""){
	   $content_status = $this->admin_model->changeContentStatus($content_id,$status);
	   $this->session->set_flashdata('flash_msg','Content status has been changed successfully.');
	   $sdata['success'] = 'success';
	}
	echo json_encode($sdata);
   }
   
    public function change_message_status()
   {
	$sdata = array();
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Change Status";
	$content_id = $this->input->post('content_id');
	$status = $this->input->post('status');
	if($content_id !=""){
	   $content_status = $this->admin_model->changeMessageStatus($content_id,$status);
	   $this->session->set_flashdata('flash_msg','Message status has been changed successfully.');
	   $sdata['success'] = 'success';
	}
	echo json_encode($sdata);
   }
   
   /**
    *This function is used to save the system configurations
    *@param requested data
    *@return array
    */
   public function system_configuration()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="System Configurations";
	$config = $this->admin_model->getconfig();
	
	$this->session->set_flashdata('flash_msg','');
	foreach($config as $key=>$val)
	{
	   $config_array[$val['key']] = $val['value'];
	}
	$data['config_details'] = $config_array;
	if($this->input->server('REQUEST_METHOD') === "POST")
	{
	   $admin_email      	= trim($this->input->post('admin_email'));
	   $signup_email 		= trim($this->input->post('signup_email'));
	   $smtp_port_number 	= trim($this->input->post('smtp_port_number'));
	   $smtp_server_host 	= trim($this->input->post('smtp_server_host'));
	   $smtp_uName  		= trim($this->input->post('smtp_uName'));
	   $smtp_uPass	   	= trim($this->input->post('smtp_uPass'));

	   $address	   		= trim($this->input->post('address'));
	   $latitude	   	= trim($this->input->post('latitude'));
	   $longitude	   	= trim($this->input->post('longitude'));
	   $contact_no	   	= trim($this->input->post('contact_no'));

	   $date_format	   	= trim($this->input->post('date_format'));
	   $time_format	   	= trim($this->input->post('time_format'));

	   $facebook_url	   	= trim($this->input->post('facebook_url'));
	   $linkedin_url	   	= trim($this->input->post('linkedin_url'));
	   $twitter_url	   	= trim($this->input->post('twitter_url'));
	   $pinterest_url	   	= trim($this->input->post('pinterest_url'));
	   $instagram_url	   	= trim($this->input->post('instagram_url'));
	   $allowed_otp_perday	   	= trim($this->input->post('allowed_otp_perday'));

	   $data['config_details'] = array(
			'admin_email'		=> $admin_email,
			'signup_email'		=> $signup_email,
			'smtp_port_number'	=> $smtp_port_number,
			'smtp_server_host'	=> $smtp_server_host,
			'smtp_uName'      	=> $smtp_uName,
			'smtp_uPass'      	=> $smtp_uPass,
			'address'      		=> $address,
			'latitude'      	=> $latitude,
			'longitude'      	=> $longitude,
			'contact_no'      	=> $contact_no,
			'date_format'      	=> $date_format,
			'time_format'      	=> $time_format,
			'facebook_url'      	=> $facebook_url,
			'linkedin_url'      	=> $linkedin_url,
			'twitter_url'      	=> $twitter_url,
			'pinterest_url'      	=> $pinterest_url,
			'instagram_url'      	=> $instagram_url,
			'allowed_otp_perday'      	=> $allowed_otp_perday,
		   );
	   //Put all the required validations
	   $this->form_validation->set_rules('admin_email', 'Admin Email', 'trim|required|strip_tags|valid_email');
	   $this->form_validation->set_rules('signup_email', 'Signup Email', 'trim|required|strip_tags|valid_email');
	   $this->form_validation->set_rules('smtp_port_number', 'SMTP Server Port', 'trim|required|strip_tags|numeric|is_natural|greater_than[0]');
	   $this->form_validation->set_rules('smtp_server_host', 'SMTP Server Host', 'trim|required|strip_tags');
	   $this->form_validation->set_rules('smtp_uName', 'SMTP User Email', 'trim|required|strip_tags|valid_email');
	   $this->form_validation->set_rules('smtp_uPass', 'SMTP Password', 'trim|required|strip_tags');
	   $this->form_validation->set_rules('facebook_url', 'Facebook Url', 'trim|strip_tags|prep_url|callback__valid_url_facebook');
	   $this->form_validation->set_rules('linkedin_url', 'Linkedin Url', 'trim|strip_tags|prep_url|callback__valid_url_linkedin');
	   $this->form_validation->set_rules('twitter_url', 'Twitter Url', 'trim|strip_tags|prep_url|callback__valid_url_twitter');
	   $this->form_validation->set_rules('pinterest_url', 'Pinterest Url', 'trim|strip_tags|prep_url|callback__valid_url_pinterest');
	   $this->form_validation->set_rules('instagram_url', 'Instagram Url', 'trim|strip_tags|prep_url|callback__valid_url_instagram');
	   $this->form_validation->set_rules('allowed_otp_perday', 'Allowed OTP in a day', 'trim|required|strip_tags|numeric|is_natural|greater_than[0]');
	   
	   if($this->form_validation->run() == TRUE)
	   {
		$this->admin_model->save_configData($data['config_details']);
		$this->session->set_flashdata('flash_msg','System configurations have been updated successfully.');
	   }
	}
	_getLoadViewAdmin('system_configuration', $data);
   }
   
   /**
    *This function is used to reset the password using forget password link
    *@param string $email
    *@return loaded view
    */
   public function contact_management()
   {
	  if ($this->session->userdata('loggedin') == FALSE)
	  {
	       redirect('admin');
	  }
	  $data['title'] ="Contact Us Management";
	  
	  $type = @$this->uri->segment(3);
	  
	  
	  $data['contact_data'] = $this->admin_model->getAllContacts(0,$type);
	  _getLoadViewAdmin('contact_management', $data);
   }
   
   /**
    *This unction is used to view the contact details
    *@param string $cobtact id
    *@return loaded view
    */
   public function view_contact()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="View Contact Details";
	$id_contact = @$this->uri->segment(3);
	$page = @$this->uri->segment(4);
	
	if($id_contact !="" || base64_decode($id_contact) >0){
	   $data['contact_data'] = $contact_data = $this->admin_model->getAllContacts(base64_decode($id_contact));
	   if(count($contact_data) == 0){
		$this->session->set_flashdata('flash_msg','Contact details does not exists.');
		
		if(!empty($page))
		{
		    redirect('admin/contact_management/'.$page);
		}
		else{
		    redirect('admin/contact_management');
		}
	   }
	}
	
	_getLoadViewAdmin('contact_details', $data);
   }
   
   /**
    *This function is used to delete the user from database
    *@param Request data
    *@return loaded view
    */
   public function delete_contact()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Delete Contact";
	$id_contact = @$this->uri->segment(3);
	$page = base64_decode(@$this->uri->segment(4));
	
	if($id_contact !="" && base64_decode($id_contact) >0){
	   $del_contact = $this->admin_model->delete_contactData(base64_decode($id_contact));
	   $this->session->set_flashdata('flash_msg','Contact detials has been deleted successfully.');
	}
	if(!empty($page))
	  {
	      redirect('admin/contact_management/'.$page);
	  }
	  else{
	  redirect('admin/contact_management');
	  }
   }
   
   /**
    *This function is used to save the system configurations
    *@param requested data
    *@return array
    */
   public function reply_contact()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Contact Reply";
	$page = base64_decode(@$this->uri->segment(4)); 
	
	if(@$this->uri->segment(3) && @$this->uri->segment(3)!= FALSE){
	   $id_contact = base64_decode(@$this->uri->segment(3));
	   if($id_contact >0){
		$data['contact_data'] = $this->admin_model->getAllContacts($id_contact);
	   }
	}
	if($this->input->server('REQUEST_METHOD') === "POST")
	{
	   $replyto_email = trim($this->input->post('email'));
	   $replyto_name = trim($this->input->post('name'));
	   $content = trim($this->input->post('content'));
	   $data['contact_data'] = array(
						'email'=> strip_tags($replyto_email),
						'name'=> strip_tags($replyto_name),
						'content'=> strip_tags($content)
					   );
	   $data['contact_data']['id'] = trim($this->input->post('contact_id'));
	   //Put all the required validations
	   $this->form_validation->set_rules('content', 'Message', 'trim|required|strip_tags|callback__checkContentDescription');

	   //run the validations
	   if($this->form_validation->run() == TRUE)
	   {
		$adminEmail = $this->admin_model->getconfig('signup_email');
		$msg = $this->pages_model->_getMessage('contact_us_reply');
	   
		$message  	= html_entity_decode($msg->content);
		$subject 	= html_entity_decode($msg->subject);
	   
		$patternFind1[0] 	= '/{name}/';
		$patternFind1[1] 	= '/{message}/';
	   
		$replaceFind1[0] 	= ucfirst(stripslashes($replyto_name));
		$replaceFind1[1] 	= ucfirst(stripslashes($content));
		
		$txtdesc_contact	= stripslashes($message);
		$contact_sub      = stripslashes($subject);
		$contact_sub      = preg_replace($patternFind1, $replaceFind1, $contact_sub);
		$ebody_contact 	= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);
		
		try
		{			   
		   $email_config = array(
					   'protocol'  => 'smtp',
					   'smtp_host' => $this->admin_model->getconfig('smtp_server_host'),
					   'smtp_port' => $this->admin_model->getconfig('smtp_port_number'),
					   'smtp_user' => $this->admin_model->getconfig('smtp_uName'),
					   'smtp_pass' => $this->admin_model->getconfig('smtp_uPass'),
					   'mailtype'  => 'html',
					   'starttls'  => true,
					   'newline'   => "\r\n"
					);
		   $this->load->library('email', $email_config);
		   $this->email->initialize($email_config);
		   $this->email->from($adminEmail, SITE_NAME);
		   $this->email->to($replyto_email);
		   $this->email->subject($contact_sub);
		   $this->email->message($ebody_contact);
		   
		   if($this->email->send()){
			$this->session->set_flashdata('flash_msg','Contact replied successfully.');
		   }else{
			// show_error($this->email->print_debugger());
		   }
		}catch(Exception $ex){
		   // show_error($this->email->print_debugger());
		}
		
		if(!empty($page))
		{
		    redirect('admin/contact_management/'.$page);
		}
		else{
		redirect('admin/contact_management');
		}
	   }
	}
	_getLoadViewAdmin('reply_contact', $data);
   }
   
   /**
    *This function is used to view the admin profile
    *@param requested data
    *@return loaded view
    */
   public function profile()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Admin Profile";
	$admin_dataArr = $this->admin_model->_getAdminDataById($this->session->userdata('id_admin'));
	$this->session->set_flashdata('flash_msg','');
	$data['admin_details'] = $admin_dataArr;
	if($this->input->server('REQUEST_METHOD') === "POST")
	{
	   $admin_name      = trim($this->input->post('user_name'));
	   $admin_email 	   = trim($this->input->post('email'));
	   $password = trim($this->input->post('password'));
	   $confirm_password = trim($this->input->post('confirm_password'));
	   $data['admin_details'] = array(
			'user_name'	=> $admin_name,
			'email'	=> $admin_email,
		   );
	   $data['admin_details']['id'] = $this->session->userdata('id_admin');
	   //Put all the required validations
	   $this->form_validation->set_rules('user_name', 'Admin Name', 'trim|required|strip_tags');
	   $this->form_validation->set_rules('email', 'Admin Email', 'trim|required|strip_tags|valid_email');
	   $this->form_validation->set_rules('password', 'Password', 'trim|strip_tags|min_length[6]|max_length[15]');
	   $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|strip_tags|min_length[6]|max_length[15]|matches[password]');
	   if($this->form_validation->run() == TRUE)
	   {
	       if(!empty($password) && !empty($confirm_password))
	       {
		    $data['admin_details']['password'] = $password;
	       }
	       
		$this->admin_model->updateAdminUser($data['admin_details']);
		$this->session->set_userdata('admin_name', $admin_name);
		$this->session->set_flashdata('flash_msg','Profile has been updated successfully.');
	   }
	}
	_getLoadViewAdmin('profile', $data);
   }
   
  
   /**
     * Validate URL format
     *
     * @access  public
     * @param   string
     * @return  string
     */
   function _valid_url_facebook($str_facebook){
      //$pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
	$pattern = '/^(http|https):\\/\\/[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}'.'((:[0-9]{1,5})?\\/.*)?$/i';
	if (trim($str_facebook) !="" && !preg_match($pattern, $str_facebook)){
	   $this->form_validation->set_message('_valid_url_facebook', 'The Facebook Url you entered is not correctly formatted.');
	   return FALSE;
	}
	return TRUE;
   }
   /**
     * Validate URL format
     *
     * @access  public
     * @param   string
     * @return  string
     */
   function _valid_url_linkedin($str_linkedin){
      //$pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
	$pattern = '/^(http|https):\\/\\/[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}'.'((:[0-9]{1,5})?\\/.*)?$/i';
	if (trim($str_linkedin) !="" && !preg_match($pattern, $str_linkedin)){
	   $this->form_validation->set_message('_valid_url_linkedin', 'The Linkedin Url you entered is not correctly formatted.');
	   return FALSE;
	}
	return TRUE;
   }
   /**
     * Validate URL format
     *
     * @access  public
     * @param   string
     * @return  string
     */
   function _valid_url_twitter($str_twitter){
      //$pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
	$pattern = '/^(http|https):\\/\\/[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}'.'((:[0-9]{1,5})?\\/.*)?$/i';
	if (trim($str_twitter) !="" && !preg_match($pattern, $str_twitter)){
	   $this->form_validation->set_message('_valid_url_twitter', 'The Twitter Url you entered is not correctly formatted.');
	   return FALSE;
	}
	return TRUE;
   }
   /**
     * Validate URL format
     *
     * @access  public
     * @param   string
     * @return  string
     */
   function _valid_url_pinterest($str_pinterest){
      //$pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
	$pattern = '/^(http|https):\\/\\/[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}'.'((:[0-9]{1,5})?\\/.*)?$/i';
	if (trim($str_pinterest) !="" && !preg_match($pattern, $str_pinterest)){
	   $this->form_validation->set_message('_valid_url_pinterest', 'The Pinterest Url you entered is not correctly formatted.');
	   return FALSE;
	}
	return TRUE;
   }
   /**
     * Validate URL format
     *
     * @access  public
     * @param   string
     * @return  string
     */
   function _valid_url_instagram($str_instagram){
      //$pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
	$pattern = '/^(http|https):\\/\\/[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}'.'((:[0-9]{1,5})?\\/.*)?$/i';
	if (trim($str_instagram) !="" && !preg_match($pattern, $str_instagram)){
	   $this->form_validation->set_message('_valid_url_instagram', 'The Instagram Url you entered is not correctly formatted.');
	   return FALSE;
	}
	return TRUE;
   }
   
   //////////////////////////////////// category
   /**
    *This function is used to get the categories list from database
    *@return loaded view
    */
   public function categories()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Category Management";
	$data['category_data'] = $this->admin_model->getCategoryList();
	_getLoadViewAdmin('category_list', $data);
   }
   
public function category_order (){
  if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
  	$data['title'] ="Set Category Order";
	$data['category_data'] = $this->admin_model->getCategoryList();
	_getLoadViewAdmin('order_category', $data);
}

     /**
      *This function is used to add the category
      *@param array requested data
      *@return loaded view
      */
     public function add_category()
     {
	  if ($this->session->userdata('loggedin') == FALSE) {
	     redirect('admin');
	    }
	  $data['title'] ="Add Category";
	  if(@$this->uri->segment(4) && @$this->uri->segment(4)!= FALSE){
	     $data['title'] ="Edit Category";
	     $id_category = base64_decode(@$this->uri->segment(4));
	     if($id_category >0){
		  $data['category_details'] = $this->admin_model->GetCategoryById($id_category);
		  $original_value = $data['category_details']['category_name'];
	     }
	  }
	  if($this->input->server('REQUEST_METHOD') === "POST")
	  {
	     $category_name = trim($this->input->post('category_name'));
	     $category_status = trim($this->input->post('category_status'));
	     $category_image = trim($this->input->post('category_image'));
	     $data['category_details'] = array(
						  'category_name'=> strip_tags($category_name),
						  'category_status' => $category_status,
						  'category_image'  => $category_image
					     );
	     $data['category_details']['id_category'] = trim($this->input->post('id_category'));
	     
	     if($this->input->post('category_name') != $original_value) {
	       $is_unique =  '|is_unique[category.category_name]';
	    } else {
	       $is_unique =  '';
	    }
	     
	     //Put all the required validations
	     $this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|strip_tags'.$is_unique.'');
	     $this->form_validation->set_rules('category_status', 'Category Status', 'trim|required|strip_tags');
	     if(!@$this->uri->segment(4) && @$this->uri->segment(4)== FALSE){
		  if(empty($_FILES['category_image']['name'])){
		     $this->form_validation->set_rules('category_image', 'Category Image', 'trim|required|strip_tags');
		  }
	     }
	     if(isset($_FILES['category_image']) && $_FILES['category_image']['name'] !="" && $_FILES['category_image']['error'] ==0){
		  $this->form_validation->set_rules('category_image', 'Category Image', 'trim|strip_tags|callback__CategoryfileValidation');
	     }
     
	     //run the validations
	     if($this->form_validation->run() == TRUE)
	     {
		  if(isset($_FILES['category_image']) && $_FILES['category_image']['name'] !="" && $_FILES['category_image']['error'] ==0){
		     $image = $_FILES['category_image']['name'];
		     $tmp_path = $_FILES['category_image']['tmp_name'];
		     $image_name = uploadImage($image, $tmp_path,'category_images','140');
		     @unlink(FCPATH.'uploads/category_images/'.$category_image);
		     @unlink(FCPATH.'uploads/category_images/thumb_'.$category_image);
		     $data['category_details']['category_image'] = $image_name;
		  }
		  
		  if($data['category_details']['id_category'] >0){
		     $user_id = $this->admin_model->save_categoryData($data['category_details']);
		     $this->session->set_flashdata('flash_msg','Category details has been updated successfully.');
		  }
		  else{
		     $user_id = $this->admin_model->save_categoryData($data['category_details']);
		     $this->session->set_flashdata('flash_msg','Category has been created successfully.');
		  }
		  redirect('admin/categories');
	     }
	  }
	  _getLoadViewAdmin('add_category', $data);
     }
   
   /**
    *This function is used to view the user profile
    *@param Request data
    *@return loaded view
    */
   public function view_category()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="View Category Details";
	$category_id = @$this->uri->segment(4);
	if($category_id !=""){
	   $data['category_details'] = $category_data = $this->admin_model->GetCategoryById(base64_decode($category_id));
	   if(count($category_data) == 0 || !$category_data){
		$this->session->set_flashdata('flash_msg','Category does not exists.');
		redirect('product/categories');
	   }
	}
	_getLoadViewAdmin('category_details', $data);
   }
   
   /**
    *This function is used to change the status of the product
    *@param  requested data
    *@return loadded view
    */
   public function change_category_status()
   {
	$sdata = array();
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Change Category Status";
	$id_category = $this->input->post('id_category');
	$status = $this->input->post('category_status');
	if($id_category !=""){
	   if($status=="Deleted")
	   {
	       $category_data = $this->admin_model->GetCategoryById($id_category);
	       
	   }
	   $user_status = $this->admin_model->changeCatgoryStatus($id_category,$status);
	   
	   if(!empty($category_data['category_image']) && $user_status)
	   {
	       $category_image = $category_data['category_image'];
	       @unlink(FCPATH.'uploads/category_images/'.$category_image);
	       @unlink(FCPATH.'uploads/category_images/thumb_'.$category_image);
	   }
	   
	   $this->session->set_flashdata('flash_msg','Category status has been changed successfully.');
	   $sdata['success'] = 'success';
	}
	echo json_encode($sdata);
   }
   
   /**
   *This function is used to validate the phone number
   *@param string $str
   *@return Boolean
   */
   function _CategoryfileValidation()
   {
	$allowed_extension = array('jpg','jpeg','JPG','JPEG','gif','GIF','png','PNG');
	$filename = $_FILES['category_image']['name'];
	$file_extension = _getExtension($filename);
	$allowed_size = 2097152;//2mb
	if(!in_array($file_extension, $allowed_extension)){
	   $this->form_validation->set_message('_CategoryfileValidation', 'The filetype you are attempting to upload is not allowed.');
	   return FALSE;
	}elseif(in_array($file_extension, $allowed_extension) && $_FILES['profile_image']['size'] > $allowed_size)
	{
	   $this->form_validation->set_message('_CategoryfileValidation', 'The file you are attempting to upload is larger than the permitted size.');
	   return FALSE;
	}
	return TRUE;
   }

   function setOrderCategory (){
	$idsData 	= $this->input->post('sort_order');
	$ids = explode(',',$idsData);

	foreach($ids as $index=>$id) {
	 if($id) {
	   $updatArray['cat_order'] =   ($index + 1);
	   $this->db->where('id_category', $id);
	   $this->db->update('category', $updatArray);
	   echo $this->db->last_query();
	   echo "<br/><br/>";
	 }
	}

   }
   
   /////////////////////////////////// end category
   
   //////////// crop image
    /*  Upload image in temp folder and crop*/
     public function temp_image_save_user()
        {
		    $folder_name = $this->uri->segment(3);

		  /*
		  *	!!! THIS IS JUST AN EXAMPLE !!!, PLEASE USE ImageMagick or some other quality image processing libraries
		  */
			  $imagePath = "uploads/temp/".$folder_name."/";
			  if(!is_dir($imagePath))
			  {
			      if(!mkdir($imagePath,0777,true))
			      {
				   $response = Array(
					  "status" => 'error',
					  "message" => 'Permission denied to create folder'
				  );
				  print json_encode($response);
				  return;
			      }
			  }

			 $maxSize = "2097152";
			  $allowedExts = array("gif", "jpeg", "jpg", "png", "GIF", "JPEG", "JPG", "PNG");
			  $temp = explode(".", $_FILES["img"]["name"]);
			  $extension = end($temp);
			  $mimeType = array("image/png","image/jpeg","image/gif");
			  $fileMime = trim($_FILES['img']['type']);

			  //Check write Access to Directory

			  if(!is_writable($imagePath)){
				  $response = Array(
					  "status" => 'error',
					  "message" => 'Can`t upload File; no write Access'
				  );
				  print json_encode($response);
				  return;
			  }

			  if ( in_array($extension, $allowedExts))
				{
				   $check = getimagesize($_FILES["img"]["tmp_name"]);
				   $imagewidth = $check[0];
				   $imageheight = $check[1];
			
				if ($_FILES["img"]["error"] > 0)
				  {
					   $response = array(
						  "status" => 'error',
						  "message" => 'ERROR Return Code: '. $_FILES["img"]["error"],
					  );
				  }elseif($_FILES["img"]["size"] <= 0 || $_FILES["img"]["size"] > $maxSize){
				    $response = array(
						  "status" => 'error',
						  "message" => 'Maybe '.$_FILES["img"]["name"]. ' exceeds max 2 MB size',
					  );
				  }elseif(!in_array($fileMime, $mimeType)){
					$response = array(
						  "status" => 'error',
						  "message" => 'Image type not supported',
					  );
				  }
			          else if ( (1920 > $imagewidth || 370 > $imageheight) && $folder_name=="banner_images" ) {
				   $response = array(
						  "status" => 'error',
						  "message" => 'Recommended Image size 1920x370 px Your image size is '.$imagewidth.'X'.$imageheight.' px.',
					  );
				  
	 
				  }
				else
				  {

					$temp_filename = $_FILES["img"]["tmp_name"];
					list($width, $height) = getimagesize( $temp_filename );
					
					 $fileName = $_FILES["img"]["name"];
					$fileName = str_replace(" ","-",$fileName);
					$fileName = str_replace("%","",$fileName);
					$fileName = str_replace(",","",$fileName);
					$fileName = str_replace("'","",$fileName);
					$fileName = time().'_'.$fileName;

					move_uploaded_file($temp_filename,  $imagePath .$fileName );

					$response = array(
					  "status" => 'success',
					  "url" => base_url().$imagePath.$fileName,
					  "image"=>$fileName,
					  "width" => $width,
					  "height" => $height
					);

				  }
				}
			  else
				{
				 $response = array(
					  "status" => 'error',
					  "message" => 'Only jpg,jpeg,png and gif image is allowed.',
				  );
				}

				print json_encode($response);
     }
     
     public function temp_image_crop_user()
        {
	  
	    $folder_name = $this->uri->segment(3);
	    $imagePath = "uploads/temp/".$folder_name."/";
			  if(!is_dir($imagePath))
			  {
			      if(!mkdir($imagePath,0777,true))
			      {
				   $response = Array(
					  "status" => 'error',
					  "message" => 'Permission denied to create folder'
				  );
				  print json_encode($response);
				  return;
			      }
			  }
	    $response = Array();
		  /*
		  *	!!! THIS IS JUST AN EXAMPLE !!!, PLEASE USE ImageMagick or some other quality image processing libraries
		  */
		  $imgUrl = $_POST['imgUrl'];
		  // original sizes
		  $imgInitW = $_POST['imgInitW'];
		  $imgInitH = $_POST['imgInitH'];
		  // resized sizes
		  $imgW = $_POST['imgW'];
		  $imgH = $_POST['imgH'];
		  // offsets
		  $imgY1 = $_POST['imgY1'];
		  $imgX1 = $_POST['imgX1'];
		  // crop box
		  $cropW = $_POST['cropW'];
		  $cropH = $_POST['cropH'];
		  // rotation angle
		  $angle = $_POST['rotation'];

		  $jpeg_quality = 100;
		  
		  
		  $imgUrlArray = explode("/", $imgUrl);
		  $imageName = end($imgUrlArray);

		  $typeArray = explode(".", $imageName);

		  $num = count($typeArray);
		  $num = $num-1;
		  $type = '.'.$typeArray[$num];
		  unset($typeArray[$num]);


		  $imageName = implode(".", $typeArray);
                   
	          $org_image_name =     $imageName.$type;
		  $imageName = "thumb_".$imageName;

		  $output_filename = $imagePath.$imageName;
		  
		
		  $what = getimagesize($imgUrl);

		  switch(strtolower($what['mime']))
		  {
			  case 'image/png':
				  $img_r = imagecreatefrompng($imgUrl);
				  $source_image = imagecreatefrompng($imgUrl);
				  //$type = '.png';
				  break;
			  case 'image/jpeg':
				  $img_r = imagecreatefromjpeg($imgUrl);
				  $source_image = imagecreatefromjpeg($imgUrl);
				  error_log("jpg");
				  //$type = '.jpeg';
				  break;
			  case 'image/gif':
				  $img_r = imagecreatefromgif($imgUrl);
				  $source_image = imagecreatefromgif($imgUrl);
				  //$type = '.gif';
				  break;
			  default:
			  $response = Array(
				  "status" => 'error',
				  "message" => 'Image type not supported'
			  );

		  }


		  //Check write Access to Directory
	        if(empty($response)){
		  if(!is_writable(dirname($output_filename))){
			  $response = Array(
				  "status" => 'error',
				  "message" => 'Can`t write cropped File'
			  );
		  }else{

			  // resize the original image to size of editor
			  $resizedImage = imagecreatetruecolor($imgW, $imgH);
			  imagecopyresampled($resizedImage, $source_image, 0, 0, 0, 0, $imgW, $imgH, $imgInitW, $imgInitH);
			  // rotate the rezized image
			  $rotated_image = imagerotate($resizedImage, -$angle, 0);
			  // find new width & height of rotated image
			  $rotated_width = imagesx($rotated_image);
			  $rotated_height = imagesy($rotated_image);
			  // diff between rotated & original sizes
			  $dx = $rotated_width - $imgW;
			  $dy = $rotated_height - $imgH;
			  // crop rotated image to fit into original rezized rectangle
			  $cropped_rotated_image = imagecreatetruecolor($imgW, $imgH);
			  imagecolortransparent($cropped_rotated_image, imagecolorallocate($cropped_rotated_image, 0, 0, 0));
			  imagecopyresampled($cropped_rotated_image, $rotated_image, 0, 0, $dx / 2, $dy / 2, $imgW, $imgH, $imgW, $imgH);
			  // crop image into selected area
			  $final_image = imagecreatetruecolor($cropW, $cropH);
			  imagecolortransparent($final_image, imagecolorallocate($final_image, 0, 0, 0));
			  imagecopyresampled($final_image, $cropped_rotated_image, 0, 0, $imgX1, $imgY1, $cropW, $cropH, $cropW, $cropH);
			  // finally output png image
			 
			  imagejpeg($final_image, $output_filename.$type, $jpeg_quality);
			  $response = Array(
				  "status" 			=> 'success',
				  "profile_image" 	=> $imageName.$type,
				  "org_image_name"      =>$org_image_name,
				  "url" 			=> base_url().$output_filename.$type
			  );
			 

		  }
		}
		  print json_encode($response);
     }
   
}

/* End of file Admin.php */
/* Location: ./application/controllers/Admin.php */
?>
