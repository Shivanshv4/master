<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages extends YS_Controller
{
   public function __construct()
   {
	parent::__construct();
	$this->load->model('Pages_model','pages');
	$this->load->model('Dashboard_model','dashboard');
	$this->load->helper('functions');
	$this->load->helper('date');
	$this->load->library('error_handler');
	$email_config = Array(
		  'protocol'  => 'smtp',
		  'smtp_host' =>  $this->admin_model->getconfig('smtp_server_host'),
		  'smtp_port' => $this->admin_model->getconfig('smtp_port_number'),
		  'smtp_user' => $this->admin_model->getconfig('smtp_uName'),
		  'smtp_pass' => $this->admin_model->getconfig('smtp_uPass'),
		  'mailtype'  => 'html',
		  'starttls'  => true,
		  'newline'   => "\r\n"
		);
	$this->load->library('email', $email_config);
   }

     public function templateHome($template_name, $data = array())
     {
	  $this->load->view('templates/header', $data);
	  $this->load->view('withoutlogin/header_section', $data);
	  $this->load->view('withoutlogin/'.$template_name, $data);
	  $this->load->view('withoutlogin/footer_section', $data);
	  $this->load->view('templates/footer', $data);
     }

     public function index()
     {
	  $data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
	  
	  $this->templateHome('index',$data);
     }

    
    
     /**
    ***************************************************************************
    * code for login page of web admin.                                      **
    * User can login the website after entered correct email and password.   **
    * *****************************************************************************
    */

   public function login()
   {
	$this->_sessionLogin();
	$data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
	$email 	= $this->input->post('loginemail');
	$password 	= $this->input->post('loginpassword');
	$backurl 	= $_REQUEST['backurl'];


	$data['backurl']= $backurl;
	$remember 	= $this->input->post('remember');
	$data['user_data'] = array(
				  'email' => $email,
				  'password' => $password,
				  'remember' => $remember
			  );

	$is_post = $this->input->post();
	
	$newdata = array();
	$this->session->set_userdata($newdata);

	$this->form_validation->set_rules('loginemail', 'Email', 'trim|strip_tags|required|valid_email');
	$this->form_validation->set_rules('loginpassword', 'Password', 'trim|strip_tags|required');
	if(trim($email) != '' && trim($password) != '' && valid_email($email))
	{
	   $this->form_validation->set_rules('verify', 'Verify', 'callback__isValid_user');
	}
	if ($this->form_validation->run() === FALSE)
	{
	   $this->template('index',$data);
	}
	else
	{ 
		$DataArr = $this->pages->_getUser_by_email($email);

		
		$Data['user_data'] = array('email'=>$DataArr['email'],'name'=>$DataArr['name'],'Userid'=>$DataArr['id']);
		$this->session->set_userdata($Data);

		//$update_status = $this->pages->update_user($DataArr['id'], array('is_login'=>1));

         
		//print_r($backurl);exit; 
		if($backurl){
		    redirect($backurl);
		} else {
		   redirect(site_url("dashboard"));
		}
	}
   }

   /**
    ************************************************************
    * Code to view the dashboard page after successfull login.**
    * **********************************************************
    */
   
   public function dashboard()
   {
	$this->_checkLogin();
	$data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
	$ses_data=$this->session->userdata('user_data');

	$user_data=$this->pages->_getUser_by_id($ses_data['Userid']);
	$data['account_type']=$ses_data['account_type'];
	$data['user_data']=$user_data;
	$this->template('dashboard',$data);
   }
   public function signup()
   {
	//$data['success_msg'] = '';
	$data['success'] = '';
	$data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
	$data['name'] = $name 	= $this->input->post('name') ? $this->input->post('name') : '';
	$data['email'] = $email = $this->input->post('email') ? $this->input->post('email') : '';
	$data['password'] = $password = $this->input->post('password') ? $this->input->post('password') : '' ;
	$data['confirm_password'] = $confirm_password = $this->input->post('confirm_password') ? $this->input->post('confirm_password') : '';
	

		$data['userData'] = array(
						'name'			=> $name,
						'email'			=> $email,
						'password'		=> md5($password),
					  );
		
		$this->form_validation->set_rules('name', 'Name', 'trim|alpha_numeric_spaces|required|max_length[20]');
		

		$this->form_validation->set_rules('email', 'Email', 'trim|strip_tags|required|valid_email|callback_isuniqueEmail');
		$this->form_validation->set_rules('password', 'Password', 'trim|strip_tags|required|min_length[6]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|strip_tags|required|min_length[6]|callback_isPasswordConfirm');
		if (empty($_FILES['image']['name'])){
			$this->form_validation->set_rules('image','Image', 'trim|strip_tags|required');
		}

		if ($this->form_validation->run() === FALSE)
        {

			$data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
			//_print_r($data);
			$this->template('sign_up',$data);
		}
		else
        {
			if(($_FILES['image']['name'] !="") && ($_FILES['image']['size'])>0){
					$image = @$_FILES['image']['name'];
					$tmp_path = @$_FILES['image']['tmp_name'];
					
					$image_name = uploadImage($image, $tmp_path,'','140');
				}
			$password=$password!=""?md5($password):"";

			$dataAdd['userData'] = array(
						'name'		=> $name,
						'email'		=> $email,
						'password'	=> $password,
						'image_name' => $_FILES['image']['name'],
					  );

            $udata=$this->pages->_getUserbyEmail($email);
            //_print_r($udata);exit;
			if($udata->id>0)
			{
				$this->pages->update_user($udata->id,$dataAdd['userData']);
				$insertID=$udata->id;
			}
			else
				$insertID = $this->pages->create_user($dataAdd['userData']);

			if($insertID)
			{ 
				//$this->App->message('Personal Information have been updated successfully.','success');
				$data['success'] = 'User Registered Successfully.';
				$this->_showMessage('asdfgh','success');
			}
			
			$this->template('sign_up',$data);
		}
	}
	
	public function ajax_signup()
   {
   	//exit;

   	//echo json_encode(array('mrp_charges' => $html['mrp'],'d_price'=> $html['d_price'])); 
	//$data['success_msg'] = '';

	$data['success'] = '';
	$data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
	$data['name'] = $name 	= $this->input->post('name') ? $this->input->post('name') : '';
	$data['email'] = $email = $this->input->post('email') ? $this->input->post('email') : '';
	$data['password'] = $password = $this->input->post('password') ? $this->input->post('password') : '' ;
	$data['confirm_password'] = $confirm_password = $this->input->post('confirm_password') ? $this->input->post('confirm_password') : '';
	$err = '';
	$error = '';
	

		$data['userData'] = array(
						'name'			=> $name,
						'email'			=> $email,
						'password'		=> md5($password),
					  );

		if(empty($name)){
			$error['name'] = 'Please enter Username.';
			$err = 1;
		} elseif(strlen ($name) > 21 ){
			$error['name'] = 'Maximum 20 characters can be entered.';
			$err = 1;
		} else {
			$error['name'] ='';
		}

		$userEmail=$this->pages->_getUserbyEmail($email);
		if(empty($email)){
			$error['email'] = 'Please enter Email.';
			$err = 1;
		} elseif($userEmail->id>0){
			$error['email'] = 'Email already exists.';
			$err = 1;
		} elseif(!strpos($email, "@") OR !strpos($email, ".")){
			$error['email'] = 'Please enter valid email.';
			$err = 1;
		} else {
			$error['email'] ='';
		}

		if(empty($password)){
			$error['password'] = 'Please enter Password.';
			$err = 1;
		} elseif(strlen ($password ) < 5 ){
			$error['password'] = 'Minimum 6 character can be entered.';
			$err = 1;
		} else {
			$error['password'] ='';
		}

		if(empty($confirm_password)){
			$error['confirm_password'] = 'Please enter Confirm Password.';
			$err = 1;
		} elseif(strlen ($confirm_password ) < 5 ){
			$error['confirm_password'] = 'Minimum 6 character can be entered.';
			$err = 1;
		} elseif($password != $confirm_password){
			$error['confirm_password'] = 'Password does not match with Confirm Password.';
			$err = 1;
		} else {
			$error['confirm_password'] ='';
		}
		$image_explode  = explode('.',$_REQUEST['image']);
		$exp = $image_explode[1];
		if(empty($_REQUEST['image'])){
			$error['image'] = 'Please select Image to upload.';
			$err = 1;
		} elseif(!in_array($exp,array('jpg','jpeg','JPG','JPEG','png'))){
			$error['image'] = 'Please select image of type jpg,jpeg,JPG,JPEG,png.';
			$err = 1;
		} else {
			$error['image'] ='';
		}

		if ($err == 1)
        {
        	echo json_encode(array('data' => $data,'error'=> $error,'response'=>'failure')); 
			
		}
		else
        {
			
        	file_put_contents("uploads/",$_REQUEST['image']);
			$password=$password!=""?md5($password):"";
			$dataAdd['userData'] = array(
						'name'		=> $name,
						'email'		=> $email,
						'password'	=> $password,
						'image_name' => $_REQUEST['image'] ? $_REQUEST['image'] : 'abc.jpg',
					  );

            $udata=$this->pages->_getUserbyEmail($email);
			if($udata->id>0)
			{
				$this->pages->update_user($udata->id,$dataAdd['userData']);
				$insertID=$udata->id;
			}
			else
				$insertID = $this->pages->create_user($dataAdd['userData']);

			if($insertID)
			{ 
				
				$data['success'] = 'User Registered Successfully.';
				
			}
			
			echo json_encode(array('data' => $data,'error'=> '','response'=>'success'));
		}
	}

	/**
	 ************************************************************
	 * Code to logout the user                 **
	 * **********************************************************
	 */

	public function logout()
	{
	
	   $sess_data = $this->session->userdata('user_data');
	   $update_status = $this->pages->update_user($sess_data['Userid'], array('is_login'=>'0'));
	   $this->session->sess_destroy();
	   //$this->facebook->destroySession();
	   redirect(base_url());
	}

        /**
         **********************************************
         * Code to check the valid user during login.**
         * @return boolean                           **
         * ********************************************
         */

        function _isValid_user()
        {
		$username = $this->input->post('loginemail');
		$password = $this->input->post('loginpassword');
		$return_value = $this->pages->_isValid_user($username,$password);
		if (!$return_value)
		{
                        $this->form_validation->set_message('_isValid_user', $this->error_handler->_getStatusMessage('invalid_credential'));
                        return FALSE;
		}
		else
			return TRUE;
	}
	function isuniqueEmail()
	{
		$email = $this->input->post('email');
		$data=$this->pages->_getUserbyEmail($email);

		if ($data->id>0 && $data->status!="Pending")
		{
			$this->form_validation->set_message('isuniqueEmail', 'Email already exists.');
			return false;
		}
		return true;
	}
	
	function isPasswordConfirm()
	{
		$password = $this->input->post('password');
		$confirm_password = $this->input->post('confirm_password');
		if($password != $confirm_password){
		
		$this->form_validation->set_message('isPasswordConfirm', 'Password does not match with Confirm Password.');
			return false;
		} else  {
			return true;
		}
	}
	
	function isValidImage()
	{
		echo "in" ;exit;
		$image = $this->input->post('image');
		
		$extention = explode('.',$_FILES['image']['name']);
		print_r($extention);exit;
		$this->form_validation->set_message('isValidImage', 'Password does not match with Confirm Password.');
		//if( $info['extension'] == 'jpg' ||  $info['extension'] == 'jpeg' ||  $info['extension'] == 'JPG' ||  $info['extension'] == 'JPEG')
		
	}

	function _isuser_exist($email)
	{
		if (!$this->pages->_getUser_by_email($email))
		{
			$this->form_validation->set_message('_isuser_exist', $this->error_handler->_getStatusMessage('not_email_exist'));
			return false;
		}
		return true;
	}
	function _isActiveEmail($email)
	{
		$data=$this->pages->_is_active_user($email);

		if ($data['id']>0)
		{
			return true;
		}
		else{
			$this->form_validation->set_message('_isActiveEmail', $this->error_handler->_getStatusMessage('inactive_account'));
			return false;
		}

	}

        /**
         *******************************************************
         * Code to include header, view page than footer html.**
         * *****************************************************
         */

        public function template($template_name, $data = array())
	{
		$this->load->view('templates/header', $data);
		$this->load->view('pages/'.$template_name, $data);
		$this->load->view('templates/footer', $data);
	}

        /**
         *******************************************
         * Code to check if user is login or not. **
         * *****************************************
         */

        function _checkLogin()
        {
                $sessData = $this->session->userdata;
		if($sessData['user_data']['Userid'] == '')
                {
			$this->session->sess_destroy();
			redirect(base_url());
		}
	}

        function uniqueimgtype()
	{
		if($_FILES['image']['name']=="")
		{
			$this->form_validation->set_message('uniqueimgtype', 'Please select image');
				return false;
		}
		else{
			$img = array("jpeg","jpg","png");
			$ext = pathinfo(@$_FILES['image']['name'], PATHINFO_EXTENSION);
			if (!in_array($ext, $img))
			{
				$this->form_validation->set_message('uniqueimgtype', 'Please upload jpg,jpeg and png image only.');
				return false;
			}
			return true;
		}
	}
        /**
         ********************************************
         * Code to check if session is set or not. **
         * ******************************************
         */

        function _sessionLogin()
        {
                $sessData = $this->session->userdata;
                $currentUrl = $this->router->uri->uri_string;
		if(@$sessData['user_data']['Userid'] != '' && @$currentUrl == '')
                {
                        redirect('dashboard');
                }
	}

	function _showMessage($message,$status){
		if($status == 'warning')
		{
			return $this->session->set_flashdata('msg', '<div class="alert alert-warning alert-dismissable">

                                        <b>Warning! </b>'.$message.'</div>');
		}
		if($status == 'success')
		{
			return $this->session->set_flashdata('msg', '<div class="alert alert-success alert-dismissable">

                                        <b>Success! </b>'.$message.'</div>');
		}
		if($status == 'error')
		{
			return $this->session->set_flashdata('msg', '<div class="alert alert-danger alert-dismissable">

                                        <b>Error! </b>'.$message.'</div>');
		}
	}
     
     ////////////////////// image cropper
     public function postimage()
     {
	  $this->template('postimage',$data);
     }
     public function cropper()
     {
	  $data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
	  
	  $this->load->view('pages/cropper', $data);
	
     }
     
     // End cropper
}
