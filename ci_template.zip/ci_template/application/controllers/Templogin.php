<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Templogin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        
        $temp_sess_data = $this->session->userdata('templogin');

 
    }
    
        public function index()
        {
	    
		
		if($_SESSION['templogin'] == 1 )
		{
			redirect(base_url());
		}
		
		$data['tempdata'] = $this->session->all_userdata();
		
                if (! file_exists('application/views/withoutlogin/templogin.php'))
                {
                        // Whoops, we don't have a page for that!
                         show_404();
                }
				$data['title'] = 'Temp Login';
        		$username = $this->input->post('login_name');
        		$password = $this->input->post('password');
				
	       //$this->form_validation->set_rules('login_name', 'User Name', 'trim|required|callback__validTempLogin['.$password.']');
                $this->form_validation->set_rules('password', 'Password', 'trim|required|callback__validTempLogin');
        
                if ($this->form_validation->run() === FALSE)
                {
                    $this->load->view('templates/header', $data);
	            $this->load->view('withoutlogin/templogin', $data);
						
                } 
		else
                {
		    
			
			 $Data = array('tempUser' => $username,'tempPass'=> $password);
			 $this->session->set_userdata("templogin",$Data);
					
			 $this->load->view('templates/header', $data);
	                $this->load->view('withoutlogin/templogin', $data);

			redirect(base_url());
			
                }
			
        }
		
        function _validTempLogin($uname,$upass){
             $upass = $this->input->post('password');
             if($upass != 'singsys8goto9')
             {
                  $this->form_validation->set_message('_validTempLogin', 'Please enter correct password.');
                  return false;
             }
             return true;
        }
    
}


?>