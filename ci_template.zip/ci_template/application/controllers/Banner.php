<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Banner extends CI_Controller
{

   /**
    * Index Page for this controller.
    *
    * Maps to the following URL
    * 		http://example.com/index.php/admin
    *	- or -
    * 		http://example.com/index.php/admin/index
    *	- or -
    * Since this controller is set as the default controller in
    * config/routes.php, it's displayed at http://example.com/
    *
    * So any other public methods not prefixed with an underscore will
    * map to /index.php/login/<method_name>
    *
    *
    *@category 	controller
    *@package 	application_controllers
    *@author 	Singsys Pte. Ltd. (00130) <info@singsys.com>
    *@version 	0.0.1
    *dated  	2015-07-07
    */

   /**
    *Default class constructor
    */
   public function __construct()
   {
	//load parent class constructor
	parent::__construct();
	$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
	$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
	$this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
	$this->output->set_header('Pragma: no-cache');
	$this->output->enable_profiler(FALSE);
	$this->load->model('pages_model');
	$this->load->model('webservice_model');
        $this->load->model('banner_model');
   }

   /**
    *Default action for the admin controller or landing function
    *dated : 2015-08-07
    */
   public function index()
   {
        $email 	= $this->input->post('user_email');
	$password 	= $this->input->post('password');

    if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }else{
	   $data['title'] ="Banner Management";
	   $data['banner_data'] = $this->banner_model->getBannerList();
           //print_r($data);
	   _getLoadViewAdmin('banner_list', $data);
	}
   }

   /**
    *This function is used to edit the banner
    *@param string $email
    *@return loaded view
    */
   public function edit_banner()
   {
    if ($this->session->userdata('loggedin') == FALSE) {
	redirect('admin');
    }
	$data['title'] ="Add Banner";
	$data['users_data'] = $this->admin_model->getAllActiveUsers();
	if(@$this->uri->segment(3) && @$this->uri->segment(3)!= FALSE){
	   $data['title'] ="Edit Banner";
	   $id_product = base64_decode(@$this->uri->segment(3));
	   if($id_product >0){
		$data['banner_details'] = $this->banner_model->GetBannerById($id_product);

	   }
	}
	if($this->input->server('REQUEST_METHOD') === "POST")
	{

           $banner_title = trim($this->input->post('banner_title'));
	   $link_one = $this->input->post('link_one');
	   $link_two = $this->input->post('link_two');
	   $cstatus = trim($this->input->post('banner_status'));
	   $banner_type = trim($this->input->post('banner_type'));
	   $imageName = trim($this->input->post('image_name'));
	   $banner_old_image = trim($this->input->post('banner_old_image'));
	  
	  $image_url = trim($this->input->post('image_url'));
	  $org_image_name = trim($this->input->post('org_image_name'));
	  
	   $data['banner_details']['banner_id'] = trim($this->input->post('banner_id'));

	   $data['banner_details'] = array(
				   'banner_title'  => $banner_title,
				   'link_one'      => $link_one,
				   'link_two'      => $link_two,
				   'cstatus'       => $cstatus,
				   'banner_type'       => $banner_type,
				   'banner_id'     => $data['banner_details']['banner_id'],
				   'banner_image'  => $banner_old_image
			      );


	   $this->form_validation->set_rules('banner_title', 'Banner Name', 'trim|required|strip_tags');
	   
	   $this->form_validation->set_rules('banner_type', 'Banner Type', 'callback__checkBanner["banner_type"]');
	  $this->form_validation->set_rules('banner_status', 'Status', 'callback__checkBanner["banner_status"]');
	  
	  /*
	  if(!$banner_old_image){
	       $this->form_validation->set_rules('banner_image', 'Banner Image', 'trim|strip_tags|callback__fileUploadValidation');
	  }
	  if(isset($_FILES['banner_image']) && $_FILES['banner_image']['name'] !="" && $_FILES['banner_image']['error'] ==0){
	       $this->form_validation->set_rules('banner_image', 'Banner Image', 'trim|strip_tags|callback__filesizeValidation');
	  }
	  */
	  if(empty($org_image_name) && empty($data['banner_details']['banner_id']))
	  {
	       //$this->form_validation->set_rules('org_image_name', 'Banner Image', 'trim|required');
	       $this->form_validation->set_rules('org_image_name', 'Banner Image', 'trim|strip_tags|callback__fileUploadValidation');
	  }
	  //if(isset($_FILES['banner_image']) && $_FILES['banner_image']['name'] !="" && $_FILES['banner_image']['error'] ==0){
	  //     $this->form_validation->set_rules('banner_image', 'Category Image', 'trim|strip_tags|callback__fileUploadValidation');
	  //}

	   //run the validations
	   if($this->form_validation->run() == TRUE)
	   {
	       /*
		if(isset($_FILES['banner_image']) && $_FILES['banner_image']['name'] !="" && $_FILES['banner_image']['error'] ==0){
		   $image = $_FILES['banner_image']['name'];
		   $tmp_path = $_FILES['banner_image']['tmp_name'];
		   $image_name = uploadImage($image, $tmp_path,'banner_images','140');

		    //$image_name =uploadResizeImage($tmp_path, $image, $midSize='370', $thumbSize='100', $folder='banner_images', $byHor_W='H');
		    
		   $source_imagepath='./uploads/banner_images/'.$image_name;


		   $data['banner_details']['banner_image'] = $image_name;
		}
	       */
	       
	       $source_temp_path = "uploads/temp/banner_images/".$org_image_name;
		    $dest_path = "uploads/banner_images/".$org_image_name;
		    
		    if(file_exists($source_temp_path))
		    {
			 if(@copy($source_temp_path,$dest_path))
			 {
			      ///////// resize in 100px of cropped image
			      $this->load->library('image_lib');
			      
				$source_imagepath = "uploads/temp/banner_images/thumb_".$org_image_name;
				$thumbimage_name="sm_".$org_image_name;
				$dest_imagepath='./uploads/banner_images/'.$thumbimage_name;
				$config1['image_library'] = 'gd2';
				$config1['source_image']	= $source_imagepath;
				
				$config1['maintain_ratio'] = true;
				$config1['width']	= 100;
	      
				$config1['new_image']   = $dest_imagepath;
				
				$this->image_lib->initialize($config1);
				 
				$this->image_lib->resize();
				$this->image_lib->clear();
				// end

			      $data['banner_details']['banner_image'] = $org_image_name;
			      
			      $source_temp_path = "uploads/temp/banner_images/thumb_".$org_image_name;
			      $dest_path = "uploads/banner_images/thumb_".$org_image_name;
			 
			      @copy($source_temp_path,$dest_path);
			      
			      // unlink temp images
			      @unlink(FCPATH.'uploads/temp/banner_images/'.$org_image_name);
			      @unlink(FCPATH.'uploads/temp/banner_images/thumb_'.$org_image_name);
			      /*
			      if(file_exists(FCPATH.'uploads/banner_images/'.$imageName))
			      {
				   @unlink(FCPATH.'uploads/banner_images/'.$imageName);
				   @unlink(FCPATH.'uploads/banner_images/thumb_'.$imageName);
				   @unlink(FCPATH.'uploads/banner_images/sm_'.$imageName);
			      }
			      */
			 }
		    }
	       
		if($data['banner_details']['banner_id'] >0){
		    
		    
		    if(!empty($banner_old_image) && $org_image_name !="")
		    {
			 @unlink(FCPATH.'uploads/banner_images/'.$banner_old_image);
			 @unlink(FCPATH.'uploads/banner_images/thumb_'.$banner_old_image);
			 @unlink(FCPATH.'uploads/banner_images/sm_'.$banner_old_image);
		    }
		   $user_id = $this->banner_model->save_bannerData($data['banner_details']);
		   $this->session->set_flashdata('flash_msg','Product details has been updated successfully.');
		}
		else{
		   $user_id = $this->banner_model->save_bannerData($data['banner_details']);
		   $this->session->set_flashdata('flash_msg','Product has been created successfully.');
		}
		redirect('banner');
	   }
	   else{
	       $data['banner_details']['image_url']=$image_url;
	       $data['banner_details']['org_image_name']=$org_image_name;
	   }
	}
	_getLoadViewAdmin('edit_banner', $data);
   }
   
   public function delete_banner()
   {
	if ($this->session->userdata('loggedin') == FALSE) {
	   redirect('admin');
      }
	$data['title'] ="Delete Product";
	$product_id = @$this->uri->segment(3);
	if($product_id !=""){
	   $product_data = $this->banner_model->GetBannerById(base64_decode($product_id));
	   @unlink(FCPATH.'uploads/banner_images/'.$product_data['banner_image']);
	   @unlink(FCPATH.'uploads/banner_images/thumb_'.$product_data['banner_image']);
	   $del_product = $this->banner_model->delete_bannerData(base64_decode($product_id));
	   $this->session->set_flashdata('flash_msg','Banner has been deleted successfully.');
	}
	redirect('banner');
   }
   function _checkBanner($t){ 
	  
	 if($t === 0 || $t =="") {
	  
	 $this->form_validation->set_message('_checkBanner', 'Please select %s ');
	
	 return FALSE;
	 }
	 return true;
    }
   function _fileUploadValidation()
   {
	$allowed_extension = array('jpg','jpeg','JPG','JPEG','gif','GIF','png','PNG');
	$filename = $_FILES['banner_image']['name'];
	$file_extension = _getExtension($filename);
	$allowed_size = 2097152;//2mb
	if(!in_array($file_extension, $allowed_extension)){
	   $this->form_validation->set_message('_fileUploadValidation', 'The filetype you are attempting to upload is not allowed.');
	   return FALSE;
	}elseif(in_array($file_extension, $allowed_extension) && $_FILES['profile_image']['size'] > $allowed_size)
	{
	   $this->form_validation->set_message('_fileUploadValidation', 'The file you are attempting to upload is larger than the permitted size.');
	   return FALSE;
	}
	return TRUE;
   }
    function _filesizeValidation()
   {
	$allowed_extension = array('jpg','jpeg','JPG','JPEG','gif','GIF','png','PNG');
	$filename = $_FILES['banner_image']['name'];
	$size = getimagesize($_FILES['banner_image']['tmp_name']);
	
	if(empty($size) || $size[0]!="1920" || $size[1]!="370"){
	   $this->form_validation->set_message('_filesizeValidation', 'Please upload 1920x370 px size image.');
	   return FALSE;
	}
	return TRUE;
   }

   /**
    *This function is used to remove tags from description
    *@return boolean
    */

}
?>
