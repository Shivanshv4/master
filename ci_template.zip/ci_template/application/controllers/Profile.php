<?php
class Profile extends CI_Controller {
        
        /***
         ***********************************************
         * Code to include model helper and libraries **
         ***********************************************
         */
        
        public function __construct()
        {
             parent::__construct();
            $this->load->model('Pages_model','pages');
            $this->load->model('Dashboard_model','dashboard');
             $this->load->helper('functions');
            $this->load->library('error_handler');
             
        }
		public function img_save_to_file()
        {

		  /*
		  *	!!! THIS IS JUST AN EXAMPLE !!!, PLEASE USE ImageMagick or some other quality image processing libraries
		  */
			  $imagePath = "uploads/cover_images/";

			  $allowedExts = array("gif", "jpeg", "jpg", "png", "GIF", "JPEG", "JPG", "PNG");

			  $temp = explode(".", $_FILES["img"]["name"]);
			  $extension = end($temp);
			  $mimeType = array("image/png","image/jpeg","image/gif");
			  $fileMime = trim($_FILES['img']['type']);

			 $maxSize = "2097152";
			  //Check write Access to Directory
			 //print_r($_FILES);
			  if(!is_writable($imagePath)){
				  $response = Array(
					  "status" => 'error',
					  "message" => 'Can`t upload File; no write Access'
				  );
				  print json_encode($response);
				  return;
			  }

			  if ( in_array($extension, $allowedExts))
				{
				if ($_FILES["img"]["error"] > 0)
				  {
					   $response = array(
						  "status" => 'error',
						  "message" => 'ERROR Return Code: '. $_FILES["img"]["error"],
					  );
				  }elseif($_FILES["img"]["size"] <= 0 || $_FILES["img"]["size"] > $maxSize){
				    $response = array(
						  "status" => 'error',
						  "message" => 'Maybe '.$_FILES["img"]["name"]. ' exceeds max 2 MB size',
					  );
				  }elseif(!in_array($fileMime, $mimeType)){
					$response = array(
						  "status" => 'error',
						  "message" => 'Image type not supported',
					  );
				  }
				else
				  {

					$filename = $_FILES["img"]["tmp_name"];
					list($width, $height) = getimagesize( $filename );

					move_uploaded_file($filename,  $imagePath . $_FILES["img"]["name"]);

					$response = array(
					  "status" => 'success',
					  "url" => base_url().$imagePath.$_FILES["img"]["name"],
					  "width" => $width,
					  "height" => $height
					);

				  }
				}
			  else
				{
				 $response = array(
					  "status" => 'error',
					  "message" => 'Only jpg,jpeg,png and gif image is allowed.',
				  );
				}

				print json_encode($response);
		}

		public function img_crop_to_file()
        {
	  $response = Array();
		  /*
		  *	!!! THIS IS JUST AN EXAMPLE !!!, PLEASE USE ImageMagick or some other quality image processing libraries
		  */
		  $imgUrl = $_POST['imgUrl'];
		  // original sizes
		  $imgInitW = $_POST['imgInitW'];
		  $imgInitH = $_POST['imgInitH'];
		  // resized sizes
		  $imgW = $_POST['imgW'];
		  $imgH = $_POST['imgH'];
		  // offsets
		  $imgY1 = $_POST['imgY1'];
		  $imgX1 = $_POST['imgX1'];
		  // crop box
		  $cropW = $_POST['cropW'];
		  $cropH = $_POST['cropH'];
		  // rotation angle
		  $angle = $_POST['rotation'];

		  $jpeg_quality = 100;
		  $imageName = "croppedImg_".time();
		  $output_filename = "uploads/cover_images/".$imageName;
		
		  $what = getimagesize($imgUrl);

		  switch(strtolower($what['mime']))
		  {
			  case 'image/png':
				  $img_r = imagecreatefrompng($imgUrl);
				  $source_image = imagecreatefrompng($imgUrl);
				  $type = '.png';
				  break;
			  case 'image/jpeg':
				  $img_r = imagecreatefromjpeg($imgUrl);
				  $source_image = imagecreatefromjpeg($imgUrl);
				  error_log("jpg");
				  $type = '.jpeg';
				  break;
			  case 'image/gif':
				  $img_r = imagecreatefromgif($imgUrl);
				  $source_image = imagecreatefromgif($imgUrl);
				  $type = '.gif';
				  break;
			  default:
			   $response = Array(
				  "status" => 'error',
				  "message" => 'Image type not supported'
			  );

			 // die('image type not supported');
		  }


		  //Check write Access to Directory
	       if(empty($response)){
		  if(!is_writable(dirname($output_filename))){
			  $response = Array(
				  "status" => 'error',
				  "message" => 'Can`t write cropped File'
			  );
		  }else{

			  // resize the original image to size of editor
			  $resizedImage = imagecreatetruecolor($imgW, $imgH);
			  imagecopyresampled($resizedImage, $source_image, 0, 0, 0, 0, $imgW, $imgH, $imgInitW, $imgInitH);
			  // rotate the rezized image
			  $rotated_image = imagerotate($resizedImage, -$angle, 0);
			  // find new width & height of rotated image
			  $rotated_width = imagesx($rotated_image);
			  $rotated_height = imagesy($rotated_image);
			  // diff between rotated & original sizes
			  $dx = $rotated_width - $imgW;
			  $dy = $rotated_height - $imgH;
			  // crop rotated image to fit into original rezized rectangle
			  $cropped_rotated_image = imagecreatetruecolor($imgW, $imgH);
			  imagecolortransparent($cropped_rotated_image, imagecolorallocate($cropped_rotated_image, 0, 0, 0));
			  imagecopyresampled($cropped_rotated_image, $rotated_image, 0, 0, $dx / 2, $dy / 2, $imgW, $imgH, $imgW, $imgH);
			  // crop image into selected area
			  $final_image = imagecreatetruecolor($cropW, $cropH);
			  imagecolortransparent($final_image, imagecolorallocate($final_image, 0, 0, 0));
			  imagecopyresampled($final_image, $cropped_rotated_image, 0, 0, $imgX1, $imgY1, $cropW, $cropH, $cropW, $cropH);
			  // finally output png image
			  //imagepng($final_image, $output_filename.$type, $png_quality);
			  imagejpeg($final_image, $output_filename.$type, $jpeg_quality);
			  $response = Array(
				  "status" => 'success',
				  "cover_image" => $imageName.$type,
				  "url" => base_url().$output_filename.$type
			  );
			

		  }
	       }
		  print json_encode($response);
		}

		public function profile_image_save()
        {

		  /*
		  *	!!! THIS IS JUST AN EXAMPLE !!!, PLEASE USE ImageMagick or some other quality image processing libraries
		  */
			  $imagePath = "uploads/users_profile/";
			 $maxSize = "2097152";
			  $allowedExts = array("gif", "jpeg", "jpg", "png", "GIF", "JPEG", "JPG", "PNG");
			  $temp = explode(".", $_FILES["img"]["name"]);
			  $extension = end($temp);
			  $mimeType = array("image/png","image/jpeg","image/gif");
			  $fileMime = trim($_FILES['img']['type']);

			  //Check write Access to Directory

			  if(!is_writable($imagePath)){
				  $response = Array(
					  "status" => 'error',
					  "message" => 'Can`t upload File; no write Access'
				  );
				  print json_encode($response);
				  return;
			  }

			  if ( in_array($extension, $allowedExts))
				{
				if ($_FILES["img"]["error"] > 0)
				  {
					   $response = array(
						  "status" => 'error',
						  "message" => 'ERROR Return Code: '. $_FILES["img"]["error"],
					  );
				  }elseif($_FILES["img"]["size"] <= 0 || $_FILES["img"]["size"] > $maxSize){
				    $response = array(
						  "status" => 'error',
						  "message" => 'Maybe '.$_FILES["img"]["name"]. ' exceeds max 2 MB size',
					  );
				  }elseif(!in_array($fileMime, $mimeType)){
					$response = array(
						  "status" => 'error',
						  "message" => 'Image type not supported',
					  );
				  }
				else
				  {

					$filename = $_FILES["img"]["tmp_name"];
					list($width, $height) = getimagesize( $filename );

					move_uploaded_file($filename,  $imagePath . $_FILES["img"]["name"]);

					$response = array(
					  "status" => 'success',
					  "url" => base_url().$imagePath.$_FILES["img"]["name"],
					  "width" => $width,
					  "height" => $height
					);

				  }
				}
			  else
				{
				 $response = array(
					  "status" => 'error',
					  "message" => 'Only jpg,jpeg,png and gif image is allowed.',
				  );
				}

				print json_encode($response);
		}

		public function profile_image_crop()
        {
	    $response = Array();
		  /*
		  *	!!! THIS IS JUST AN EXAMPLE !!!, PLEASE USE ImageMagick or some other quality image processing libraries
		  */
		  $imgUrl = $_POST['imgUrl'];
		  // original sizes
		  $imgInitW = $_POST['imgInitW'];
		  $imgInitH = $_POST['imgInitH'];
		  // resized sizes
		  $imgW = $_POST['imgW'];
		  $imgH = $_POST['imgH'];
		  // offsets
		  $imgY1 = $_POST['imgY1'];
		  $imgX1 = $_POST['imgX1'];
		  // crop box
		  $cropW = $_POST['cropW'];
		  $cropH = $_POST['cropH'];
		  // rotation angle
		  $angle = $_POST['rotation'];

		  $jpeg_quality = 100;
		  $imageName = "croppedImg_".time();
		  $output_filename = "uploads/users_profile/".$imageName;
		
		  $what = getimagesize($imgUrl);

		  switch(strtolower($what['mime']))
		  {
			  case 'image/png':
				  $img_r = imagecreatefrompng($imgUrl);
				  $source_image = imagecreatefrompng($imgUrl);
				  $type = '.png';
				  break;
			  case 'image/jpeg':
				  $img_r = imagecreatefromjpeg($imgUrl);
				  $source_image = imagecreatefromjpeg($imgUrl);
				  error_log("jpg");
				  $type = '.jpeg';
				  break;
			  case 'image/gif':
				  $img_r = imagecreatefromgif($imgUrl);
				  $source_image = imagecreatefromgif($imgUrl);
				  $type = '.gif';
				  break;
			  default:
			  $response = Array(
				  "status" => 'error',
				  "message" => 'Image type not supported'
			  );

			 // die('image type not supported');
		  }


		  //Check write Access to Directory
	        if(empty($response)){
		  if(!is_writable(dirname($output_filename))){
			  $response = Array(
				  "status" => 'error',
				  "message" => 'Can`t write cropped File'
			  );
		  }else{

			  // resize the original image to size of editor
			  $resizedImage = imagecreatetruecolor($imgW, $imgH);
			  imagecopyresampled($resizedImage, $source_image, 0, 0, 0, 0, $imgW, $imgH, $imgInitW, $imgInitH);
			  // rotate the rezized image
			  $rotated_image = imagerotate($resizedImage, -$angle, 0);
			  // find new width & height of rotated image
			  $rotated_width = imagesx($rotated_image);
			  $rotated_height = imagesy($rotated_image);
			  // diff between rotated & original sizes
			  $dx = $rotated_width - $imgW;
			  $dy = $rotated_height - $imgH;
			  // crop rotated image to fit into original rezized rectangle
			  $cropped_rotated_image = imagecreatetruecolor($imgW, $imgH);
			  imagecolortransparent($cropped_rotated_image, imagecolorallocate($cropped_rotated_image, 0, 0, 0));
			  imagecopyresampled($cropped_rotated_image, $rotated_image, 0, 0, $dx / 2, $dy / 2, $imgW, $imgH, $imgW, $imgH);
			  // crop image into selected area
			  $final_image = imagecreatetruecolor($cropW, $cropH);
			  imagecolortransparent($final_image, imagecolorallocate($final_image, 0, 0, 0));
			  imagecopyresampled($final_image, $cropped_rotated_image, 0, 0, $imgX1, $imgY1, $cropW, $cropH, $cropW, $cropH);
			  // finally output png image
			  //imagepng($final_image, $output_filename.$type, $png_quality);
			  imagejpeg($final_image, $output_filename.$type, $jpeg_quality);
			  $response = Array(
				  "status" 			=> 'success',
				  "profile_image" 	=> $imageName.$type,
				  "url" 			=> base_url().$output_filename.$type
			  );
			

		  }
		}
		  print json_encode($response);
		}

        public function edit()
        {
		  checkLogin();
		  $data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
                
		  $sesion_data = $this->session->userdata('user_data');
		
		if($sesion_data['account_type'] == 'shopowner'){
		   $data['user_name'] = 'Shop Name';
	       } else {
		    $data['user_name'] = 'Name';
	       }

		  $user_data=$this->pages->_getUser_by_id($sesion_data['Userid']);
		  $country_data=$this->dashboard->getCountries();
              
		  $data['account_type']		= $sesion_data['account_type'];
		  $data['user_data']		= $user_data;
		  $data['product_count']	= $product_count;
		  $data['reviews_count']	= $reviews_count;
		  $data['products']			= $product;
		  $data['country']			= $country_data;
                
		if($user_data['cover_image'] && file_exists("uploads/cover_images/".$user_data['cover_image']) ) {
		  $coverImage =   base_url()."uploads/cover_images/".$user_data['cover_image'];
		} else {
	           $coverImage =  base_url().'lib/images/cover-img.jpg';
		}

		if($user_data['image_name'] && file_exists("uploads/users_profile/".$user_data['image_name']) ) {
		  $profileImage =   base_url()."uploads/users_profile/".$user_data['image_name'];
		} else {
	           $profileImage =  base_url().'lib/images/no_user_image.png';
		}


                $data['userData'] = array(
                                        'name'				=> $user_data['name'],
                                        'email'				=> $user_data['email'],
                                        'dob'				=> $user_data['dob'],
                                        'gender'			=> $user_data['gender'],
                                        'phone_number'		=> $user_data['phone_number'],
                                        'address'			=> $user_data['address'],
                                        'image_name'		=> $profileImage, //$user_data['image_name'],
										'cover_image'		=> $coverImage, //$user_data['cover_image'],
										'country'			=> $user_data['country_id'],
										'shop_description'	=> $user_data['shop_description'],
										'website_url'		=> $user_data['website_url'],
										'show_contact'		=> $user_data['show_contact'],
                                        );
               
                if(count($this->input->post()) > 0 )
                {
                   
					$name	= $this->input->post('name');
					$email	= $this->input->post('email');
					$dob	= $this->input->post('dob');
					$gender	= $this->input->post('gender');
					$phone_number	= $this->input->post('contact');
					$show_contact = $this->input->post('show_contact');
					if(empty($show_contact))
						 $show_contact = 'No';
                    $address	= $this->input->post('address');
                    $country	= $this->input->post('country');
                    $image_data = $this->input->post('image_data');
					$cover_data = $this->input->post('cover_data');
					$shop_description = $this->input->post('shop_description');
					$website_url = $this->input->post('website_url');
                    
					if($cover_data && file_exists("uploads/cover_images/".$cover_data) ) {
						 $coverImage =   base_url()."uploads/cover_images/".$cover_data;
					}

					if($image_data && file_exists("uploads/users_profile/".$image_data) ) {
						 $profileImage =   base_url()."uploads/users_profile/".$image_data;
					}

                    $data['userData']=array(
                                        'name' 		=> $name,
                                        'email'		=> $email,
                                        'dob'		=> $dob,
                                        'gender'	=> $gender,
                                        'phone_number'	=> $phone_number,
                                        'address'	=> $address,
                                        'image_data'	=> $image_data,
                                        'image_name'	=> $profileImage, //$user_data['image_name'],
										'cover_data'	=> $cover_data,
										'image_name_hidden'	=> $image_data, //$user_data['image_name'],
										'cover_data_hidden'	=> $cover_data,
										'cover_image'	=> $coverImage, //$user_data['cover_image'],
                                        'country'	=> $country,
										'shop_description'=>$shop_description,
										'website_url'=>$website_url,
										'show_contact'=> $show_contact,
                                        );
                  
                    $this->form_validation->set_rules('name', $data['user_name'], 'trim|alpha_numeric_spaces|required|max_length[20]');

                    if($user_data['email']!=$email)
                    $this->form_validation->set_rules('email', 'Email', 'trim|strip_tags|required|valid_email|callback_isuniqueEmail');
                    $this->form_validation->set_rules('dob', 'Date of Birth', 'trim|strip_tags|required');
                    $this->form_validation->set_rules('contact', 'Contact No', 'trim|strip_tags|required|callback_isvalidNumber');
                    $this->form_validation->set_rules('address', 'Address', 'trim|strip_tags|required');
                    $this->form_validation->set_rules('country', 'Country', 'trim|strip_tags|required');



			  if($data['account_type'] == "shopowner"){
				 $this->form_validation->set_rules('shop_description', 'Description', 'trim|strip_tags|required');
				 
				 if(!empty($website_url))
				 $this->form_validation->set_rules('website_url', 'Website URL', 'trim|callback_valid_url_format'); // valid_url
			  }
                    ///if($image_data=="")
			//$this->form_validation->set_rules('image','Image', 'callback_uniqueimgtype');
                        
                    if ($this->form_validation->run() === FALSE)
                    {			
                            $this->template('profile_edit',$data);
                    }
                    else
                    {
                         $dataupdate['userData']=array(
                                        'name'		=> $name,
                                        'email'		=> $email,
                                        'dob'		=> date('Y-m-d',strtotime($dob)),
                                        'gender'	=> $gender,
                                        'phone_number'	=> $phone_number,
                                        'address'	=> $address,
                                        'country_id'	=> $country,
										'shop_description'=> $shop_description,
										'website_url'	=> $website_url,
										'show_contact'	=> $show_contact,
                                        );
						 if($image_data) {
							  $dataupdate['userData']['image_name'] = $image_data;
						 }
						 if($cover_data){
							  $dataupdate['userData']['cover_image'] = $cover_data;
						 }
                      
			 ##################### CODE FOR COVER IMAGE #####################
                         
                         $this->pages->update_user($user_data['id'],$dataupdate['userData']);
                         _showMessage($this->error_handler->_getStatusMessage('user_updated'),'success');
			 if($sesion_data['account_type'] == 'shopowner'){
			      header('refresh: 3; url='.base_url('dashboard'));
			 } else {
			      header('refresh: 3; url='.base_url('shopnow'));
			 }


                         $this->template('profile_edit',$data);
                    }
                }
                else{
                    $this->template('profile_edit',$data);
                }

	}

	function valid_url_format($str){
		$pattern = "/^(http\:\/\/|https\:\/\/)?([a-z0-9][a-z0-9\-]*\.)+[a-z0-9][a-z0-9\-]*$|i";
		$pattern = "/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i";
       // $pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
        if (!preg_match($pattern, $str)){
			   $this->form_validation->set_message('valid_url_format', 'The URL you entered is not correctly formatted.');
               //$this->set_message('valid_url_format', 'The URL you entered is not correctly formatted.');
            return FALSE;
        }

        return TRUE;
    }

       function view (){
			   checkLogin();
			   $data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
			   $sesion_data = $this->session->userdata('user_data');
			   $shopId = @base64_decode($this->uri->segment(3));
			   if($shopId) {

			   }
	   }
       function isvalidNumber()
       {
                $value = $this->input->post('contact');
                if ($value == '') {
                       $this->form_validation->set_message('isvalidNumber', 'Contact Number is required');
			return false;
                }
                else
                {
                        if (preg_match('/^\+?([0-9]{2})\)?[-. ]?([0-9]{4,10})$/', $value))
                        {
                            
                             return preg_replace('/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/', '($1) $2-$3', $value);
                        }
                        else
                        {
                              $this->form_validation->set_message('isvalidNumber', 'Please enter valid contact number.');
			      return false;
                        }
                }
       }
          function uniqueimgtype()
	{
		if($_FILES['image']['name']=="")
		{
			$this->form_validation->set_message('uniqueimgtype', 'Please select image');
				return false;
		}
		else{
			$img = array("jpeg","jpg","png");
			$ext = pathinfo(@$_FILES['image']['name'], PATHINFO_EXTENSION);
			if (!in_array($ext, $img))
			{
				$this->form_validation->set_message('uniqueimgtype', 'Please upload jpg,jpeg and png image only.');
				return false;
			}
			return true;
		}
	}
       function isuniqueEmail()
	{
		$email = $this->input->post('email');
		
		if ($this->pages->valid_all_email($email))
		{
			$this->form_validation->set_message('isuniqueEmail', 'Email already exists.');
			return false;
		}
		return true;
	}
        public function template($template_name, $data = array())
	{	
		$this->load->view('templates/header', $data);
		$this->load->view('pages/'.$template_name, $data);
                $this->load->view('templates/myaccount_footer', $data);
		$this->load->view('templates/footer', $data);
	}
}
?>
