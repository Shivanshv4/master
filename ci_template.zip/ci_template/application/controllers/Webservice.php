<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Webservice extends CI_Controller
{
  /**
    * Index Page for this controller.
    *
    * Maps to the following URL
    * 		http://example.com/index.php/webservice
    *	- or -  
    * 		http://example.com/index.php/webservice/index
    **	- or -
    * Since this controller is set as the default controller in 
    * config/routes.php, it's displayed at http://example.com/
    *
    * So any other public methods not prefixed with an underscore will
    * map to /index.php/webservice/<method_name>
    *
    *
    *@category 	controller
    *@package 	application_controllers
    *@author 	Singsys Pte. Ltd. (00130) <info@singsys.com>
    *@version 	0.0.1
    *dated  	2015-08-06
    */

   var $status = "failed";
   var $message = "Invalid Operation";
   private $isError = FALSE;
   private $record_per_page =10;

   /**
    *Class default constructor
    */
   public function __construct()
   {
	parent::__construct();
	$this->load->model('Webservice_model','webservice');
	$this->load->model('Pages_model','pages');
	$this->load->helper('functions');
	$this->load->library('error_handler');
	
	$lang = $this->input->post('lang');
	$lang_arr = $this->config->item("available_language");
	if(!empty($lang) && array_key_exists($lang,$lang_arr))
	{
	  $this->lang->load("webservice",$lang);
	}
	else
	{
	  $this->lang->load("webservice","english");
	}
   }
   /**
    *This function serves the view file to test webservices
    */
   public function index()
   {
	$this->load->view('webservice/index');
   }
   /**
    *Get All country List
    */
     public function country_list()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr1 = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	  {
	  
	       if($this->isError === FALSE)
	       {
		    $DataArr = $this->webservice->_getCountryList();
		    $this->status = "success";
		    $this->message = $this->lang->line("msg_country_list");
	       }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
     
     /**
    *Get OTP
    */
     public function get_otp()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr1 = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	  {
	       foreach($postData as $key => $post)
	       {
		    $$key = self::_stripTags_trim($post);
		    $insertArr[$key] = self::_stripTags_trim($post);
	       }
	       
	       $otp_count = $this->webservice->_otpcount($phone_no);
	       
	       if($this->isError === FALSE)
	       {
		    $allowed_otp_perday = $this->admin_model->getconfig('allowed_otp_perday');
		    
		    //echo $otp_count.'<='.$allowed_otp_perday;
		    if(trim($phone_no) == ''){
		       $this->message = $this->lang->line("empty_phone");
		       $this->isError = TRUE;
		    }
		    else if(!_isValidPhone($phone_no)){
		       $this->message = $this->lang->line("invalid_phone");
		       $this->isError = TRUE;
		    }
		    elseif($otp_count >= $allowed_otp_perday){
		       $this->message = $this->lang->line("otp_limit");
		       $this->isError = TRUE;
		    }
	       }
	  
	       if($this->isError === FALSE)
	       {
		    $otp = $this->webservice->add_otp($phone_no);
		    if($otp)
		    {
			 
			 $DataArr['otp_no']=$otp;
			 $DataArr['otp_count']=$otp_count;
			  
			 $this->status = "success";
			 $this->message = $this->lang->line("otp_number");
		    }
	       }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
   
     /**
    *Verify OTP
    */
     public function verify_otp()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr1 = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	  {
	       foreach($postData as $key => $post)
	       {
		    $$key = self::_stripTags_trim($post);
		    $insertArr[$key] = self::_stripTags_trim($post);
	       }
	       if($this->isError === FALSE)
	       {
		    if(trim($phone_no) == ''){
		       $this->message = $this->lang->line("empty_phone");
		       $this->isError = TRUE;
		    }
		    else if(!_isValidPhone($phone_no)){
		       $this->message = $this->lang->line("invalid_phone");
		       $this->isError = TRUE;
		    }
		    if(trim($otp_no) == ''){
		       $this->message = $this->lang->line("empty_otp");
		       $this->isError = TRUE;
		    }
		    if(!$this->webservice->isvalidotp($phone_no,$otp_no))
		    {
			 $this->message = $this->lang->line("enter_valid_otp");
			 $this->isError = TRUE;
		    }
	       }
	  
	       if($this->isError === FALSE)
	       {
		    $otp = $this->webservice->update_otp($phone_no,$otp_no);
		    if($otp)
		    {
			 $this->status = "success";
			 $this->message = $this->lang->line("success_verify_otp");
		    }
	       }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
   
    /**
    *signup
    */
     public function signup()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr1 = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	  {
	       foreach($postData as $key => $post)
	       {
		    $$key = self::_stripTags_trim($post);
		    $insertArr[$key] = self::_stripTags_trim($post);
	       }
	       if($this->isError === FALSE)
	       {
		    if(trim($phone_no) == ''){
		       $this->message = $this->lang->line("empty_phone");
		       $this->isError = TRUE;
		    }
		    else if(!_isValidPhone($phone_no)){
		       $this->message = $this->lang->line("invalid_phone");
		       $this->isError = TRUE;
		    }
		    else if(trim($password) == ''){
		       $this->message = $this->lang->line("empty_password");
		       $this->isError = TRUE;
		    }
		    if(trim($otp_no) == ''){
		       $this->message = $this->lang->line("empty_otp");
		       $this->isError = TRUE;
		    }
		    if(!$this->webservice->isvalidotp($phone_no,$otp_no))
		    {
			 $this->message = $this->lang->line("enter_valid_otp");
			 $this->isError = TRUE;
		    }
	       }
	  
	       if($this->isError === FALSE)
	       {
		    
		    $insertArr=array(
			"phone_number"=>$phone_no,
			"password"=>md5($password),
		    );
		    
		    $insert_id = $this->general->insert("users",$insertArr);
		    
		    if($insert_id)
		    {
			 $DataArr=$this->webservice->getUserDetails($insert_id);
			 $this->status = "success";
			 $this->message = $this->lang->line("signup_success");
		    }
	       }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
   
   
     /**
       * Method name: email_login
       * @description :  Used to login into mobile app
       * @param:  Request data
       * @return:  user detail array with success message
       */
     public function email_login()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr1 = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	$data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
     
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
	     if($this->isError === FALSE)
	     {
		  if(trim($email) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_email');
		     $this->isError = TRUE;
		  }
		  else if(!valid_email($email)){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_email');
		     $this->isError = TRUE;
		  }
		  else if(trim($password) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_password');
		     $this->isError = TRUE;
		  }
		  else if(!$this->pages->_isValid_user_webser($email,$password)){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_credential');
		     $this->isError = TRUE;
		  } else {
		      $DataArr = $this->pages->_getUser_by_email($email);
		      if($DataArr['status'] != 'Active'){
			   $this->message = $this->error_handler->_getStatusMessage('invalid_activate');
			   $this->isError = TRUE;
		      }
		  }
	     }
	     if($this->isError === FALSE)
	     {
		  $DataArr = $this->pages->_getUser_by_email($email);
		  $time_zone = __getTimeZone();
		  $updatArray = array(
					   'device_token' => $device_token,
					     'device_type' => $device_type,
					     'app_version' => $app_version,
					     'is_login' => 1,
					     'time_zone' =>$time_zone,
					   );
		  
		  //$insertID = $this->webservice->update_user($DataArr['id'], $updatArray);
		  
		  $insertID = $this->general->update("users",$updatArray,array("id"=>$DataArr['id']));
     
		     $DataArr = $this->pages->_getUser_by_email($email);
		     $DataArr['dob'] = $DataArr['dob'] !="0000-00-00" ? date('d-m-Y',strtotime($DataArr['dob'])) :  "00-00-0000";
		     $config = $this->admin_model->getconfig();
		     foreach($config as $key=>$val)
		      {
			 $config_array[$val['key']] = $val['value'];
		      }
		     $adminSetting['admin_address'] 	= $config_array['address'];
		     $adminSetting['admin_contact_no'] 	= $config_array['contact_no'];
		     $adminSetting['admin_email'] 	= $config_array['admin_email'];
		     $adminSetting['admin_longitude'] 	= $config_array['longitude'];
		     $adminSetting['admin_latitude'] 	= $config_array['latitude'];
		     $adminSetting1 = $DataArr;
		     $DataArr = array_merge($adminSetting, $adminSetting1);
		     $this->message = $this->error_handler->_getStatusMessage('success_login');
		     $this->status = "success";
		     
		     $this->pages->updateUserLoginHistory($DataArr['id']);
		  
	     }
	  }
	  //$data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr1, 'message' => $this->message));
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
   
     /**
       * Method name: user_signup
       * @description :  Used to signup user account
       * @param:  Request data
       * @return:  user detail array with success message
       */
     public function user_signup()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $image = $image_name = '';
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
     
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
     
	     if($this->isError === FALSE)
	     {
		  if(trim($name) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_name');
		     $this->isError = TRUE;
		  }
		  else if(strlen($name) > 50){
		     $this->message = $this->error_handler->_getStatusMessage('empty_name_length');
		     $this->isError = TRUE;
		  }
		  else if(trim($email) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_email');
		     $this->isError = TRUE;
		  }
		  else if(!valid_email($email)){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_email');
		     $this->isError = TRUE;
		  }
		  else if($this->webservice->sg_email_exist($email,0,'Pending')){
		     $this->message = $this->error_handler->_getStatusMessage('email_exists');
		     $this->isError = TRUE;
		  }
		  else if(trim($dob) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_dob');
		     $this->isError = TRUE;
		  }
		  else if(trim($gender) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_gender');
		     $this->isError = TRUE;
		  }
		  else if(trim($password) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_password');
		     $this->isError = TRUE;
		  }
		  else if(strlen($password) < 6){
		     $this->message = $this->error_handler->_getStatusMessage('minlen_password');
		     $this->isError = TRUE;
		  }
		  else if(trim($account_type) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_acctype');
		     $this->isError = TRUE;
		  }
		  elseif(isset($_FILES['image_name']) && ($_FILES['image_name']['name'] =="") && $_FILES['image_name']['error'] >0)
		  {
		     $this->message = $this->error_handler->_getStatusMessage('empty_image');
		     $this->isError = TRUE;
		  }
		  elseif(isset($_FILES['image_name']) && ($_FILES['image_name']['name'] !="") && ($this->_fileUploadValidation($_FILES['image_name']['name']) == FALSE))
		  {
		     $this->message = $this->error_handler->_getStatusMessage('invalid_filetype');
		     $this->isError = TRUE;
		  }
	     }
	     if($this->isError === FALSE)
	     {
		  if(isset($_FILES['image_name']) && $_FILES['image_name']['name'] !="" && $_FILES['image_name']['error'] ==0){
		     $image = $_FILES['image_name']['name'];
		     $tmp_path = $_FILES['image_name']['tmp_name'];
		     $image_name = uploadImage($image, $tmp_path,'users_profile');
		     //create thumbnail
		     $this->load->library('upload');
		     $this->load->library('image_lib');
		     
		     $source_imagepath='./uploads/users_profile/'.$image_name;
		     
		     $thumbimage_name="thumb_".$image_name;
		     $dest_imagepath='./uploads/users_profile/'.$thumbimage_name;
		     $config1['image_library'] = 'gd2';
		     $config1['source_image']	= $source_imagepath;
		     $user_image_size=$this->config->item('user_thumbimage_size');
		     $user_image_size=$user_image_size[0];
		     $config1['maintain_ratio'] = TRUE;
		     $config1['width']	= $user_image_size[0];
		     //$config1['height']	= $user_image_size[1];
		     $config1['new_image']   = $dest_imagepath;
		     
		     $this->image_lib->initialize($config1);
		     $this->image_lib->resize();
		     $this->image_lib->clear();
		  }
		  $insertArr['image_name'] = $image_name ;
		  $insertArr['password'] = md5($insertArr['password']);
		  $insertArr['created_on'] = date('Y-m-d H:i:s');
		  $insertArr['dob'] = date('Y-m-d',strtotime($dob));
		  $insertID = $this->webservice->create_user($insertArr);
		  $DataArr = $this->pages->_getUser_by_email($email);
		  $DataArr['dob'] = date('d-m-Y',strtotime($dob));
		  $generated_code = random_string();
		  $updateArray = array(
				       'activate_code' => $generated_code,
				       );
		  $DataArr1 = $this->pages->update_user($DataArr['id'],$updateArray);	
		  $link = base_url().'activateaccount/'.base64_encode($DataArr['id'].'/'.$generated_code);
		  $mail_send = $this->_send_email($postData['email'], $postData['name'], $link,'sign_up');
		  //$insertArr['image_name'] = $image_name;
		  //$insertArr['password'] = md5($insertArr['password']);
		  if($insertID)
		  {
		     $this->message = $this->error_handler->_getStatusMessage('success');
		     $this->status = "success";
		  }
	     }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
     
     /**
      * Method name: user_signup
      * @description :  Used to signup user account
      * @param:  Request data
      * @return:  user detail array with success message
     */
     public function userSignupFacebook()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $image ='';
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
     
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
	  }
	  if($this->isError === FALSE)
	  {
	     $user_details_by_fb = $this->webservice->_getUser_by_fb_id($fb_id);
	     
	     if(trim($fb_id) == ''){
		  $this->message = $this->error_handler->_getStatusMessage('empty_fbid');
		  $this->isError = TRUE;
	     }
	     else if(trim($name) == ''){
		  $this->message = $this->error_handler->_getStatusMessage('empty_name');
		  $this->isError = TRUE;
	     }
	     else if(trim($email) == ''){
		  $this->message = $this->error_handler->_getStatusMessage('empty_email');
		  $this->isError = TRUE;
	     }
	     else if(!valid_email($email)){
		  $this->message = $this->error_handler->_getStatusMessage('invalid_email');
		  $this->isError = TRUE;
	     }
	     else if(count($user_details_by_fb)>0 && $user_details_by_fb['status'] !='Pending'){
		  $this->message = $this->error_handler->_getStatusMessage('already_exists');
		  $this->isError = TRUE;
	     }
	     else if(trim($dob) == ''){
		  $this->message = $this->error_handler->_getStatusMessage('empty_dob');
		  $this->isError = TRUE;
	     }
	     else if(trim($account_type) == ''){
		  $this->message = $this->error_handler->_getStatusMessage('empty_acctype');
		  $this->isError = TRUE;
	     }
	     elseif(trim($image_name)==""  && (isset($_FILES['image_name']) && ($_FILES['image_name']['name'] =="") && $_FILES['image_name']['error'] >0))
	     {
		  $this->message = $this->error_handler->_getStatusMessage('empty_image');
		  $this->isError = TRUE;
	     }
	     elseif(isset($_FILES['image_name']) && ($_FILES['image_name']['name'] !="") && ($this->_fileUploadValidation($_FILES['image_name']['name']) == FALSE))
	     {
		  $this->message = $this->error_handler->_getStatusMessage('invalid_filetype');
		  $this->isError = TRUE;
	     }
	  }
	  if($this->isError === FALSE)
	  {
	     if(isset($_FILES['image_name']) && $_FILES['image_name']['name'] !="" && $_FILES['image_name']['error'] ==0){
		  $image = $_FILES['image_name']['name'];
		  $tmp_path = $_FILES['image_name']['tmp_name'];
		  $image_name = uploadImage($image, $tmp_path,'users_profile');
		  
		  //create thumbnail
		  $this->load->library('upload');
		  $this->load->library('image_lib');
		  
		  $source_imagepath='./uploads/users_profile/'.$image_name;
		  
		  $thumbimage_name="thumb_".$image_name;
		  $dest_imagepath='./uploads/users_profile/'.$thumbimage_name;
		  $config1['image_library'] = 'gd2';
		  $config1['source_image']	= $source_imagepath;
		  $user_image_size=$this->config->item('user_thumbimage_size');
		  $user_image_size=$user_image_size[0];
		  $config1['maintain_ratio'] = TRUE;
		  $config1['width']	= $user_image_size[0];
		  //$config1['height']	= $user_image_size[1];
		  $config1['new_image']   = $dest_imagepath;
		  
		  $this->image_lib->initialize($config1);
		  $this->image_lib->resize();
		  $this->image_lib->clear();
		  
	     }
	     $insertArr['image_name'] = $image_name ;
	     $insertArr['created_on'] = date('Y-m-d H:i:s');
	     $insertArr['dob'] = date('Y-m-d',strtotime($dob));
	     $insertID = $this->webservice->createUserByFb($insertArr);
	     $DataArr = $this->pages->_getUser_by_email($email);
	     $DataArr['dob'] = date('d-m-Y',strtotime($dob));
	     if($is_verified == 'No'){
		  $generated_code = random_string();
		  $updateArray = array(
				    'activate_code' => $generated_code,
				    );
		  $DataArr1 = $this->pages->update_user($DataArr['id'],$updateArray);	
		  $link = base_url().'activateaccount/'.base64_encode($DataArr['id'].'/'.$generated_code);
		  $mail_send = $this->_send_email($postData['email'], $postData['name'], $link,'sign_up');
	     }
	     //$insertArr['image_name'] = $image_name;
	     //$insertArr['password'] = md5($insertArr['password']);
	     if($insertID)
	     {
		  if($mail_send){
		     $this->message = $this->error_handler->_getStatusMessage('success');
		  }else{
		     $this->message = $this->error_handler->_getStatusMessage('fb_login_success');
		  }
		  $this->status = "success";
	     }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }	
	
     /**
       * Method name: facebook_login
       * @description :  Used to signup user account via facebook
       * @param:  Request data
       * @return:  user detail array with success message
       */   
     public function facebook_login()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr1 = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
     
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  @$_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
     
	     if($this->isError === FALSE)
	     {
		  $user_details_by_fb = $this->webservice->get_fb_id_exist($fb_id, $email);
		   if(trim($fb_id) == ''){
		    $this->message = $this->error_handler->_getStatusMessage('empty_fbid');
		    $this->isError = TRUE;
		   }elseif(!valid_email($email) && $email){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_email');
		     $this->isError = TRUE;
		   }else if(!$this->webservice->sg_fb_id_exist($fb_id, $email)){
		    $this->message = $this->error_handler->_getStatusMessage('invalid_fb_id');
		    $this->isError = TRUE;
		   }elseif($this->webservice->sg_fb_id_exist($fb_id, $email) && count($user_details_by_fb)>0 && $user_details_by_fb['status'] !='Active')
		   {
		    $this->message = $this->error_handler->_getStatusMessage('not_active');
		    $this->isError = TRUE;
		   }
	     }
	     if($this->isError === FALSE)
	     {
		  $DataArr = $this->webservice->get_fb_id_exist($fb_id, $email);
		  
		  $time_zone = __getTimeZone();
		  if(!empty($DataArr))
		  {
		     $updatArray = array(
					     'fb_id'	=> $fb_id,
					     //'email'	=> $email,
					     'device_token' => $device_token,
					     'device_type' => $device_type,
					     'app_version' => $app_version,
					     'is_login' => 1,
					     'time_zone' => $time_zone,
					     'image_name'	=> $DataArr['image_name'] ? $DataArr['image_name'] : $image_name,
					     );
		     // update login history
		      $this->pages->updateUserLoginHistory($DataArr['id']);
		      
		     $updateID = $this->webservice->update_user($DataArr['id'], $updatArray);
		     //$DataArr1 = $this->webservice->_getUser_by_fb_id($fb_id);
		     $DataArr1 = $this->webservice->_getUser_by_fb_id($fb_id);
		     $this->message = $this->error_handler->_getStatusMessage('success_login');
		     $this->status = "success";
		  }
	     }
	  }
	  //$data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr1, 'message' => $this->message));
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
   
     /**
       * Method name: forgetpassword
       * @description :  Used to retrieve account password
       * @param:  Request data
       * @return:  user detail array with success message
       */	
     public function forgetpassword()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr1 = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
		  
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	  {
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
	     if($this->isError === FALSE)
	     {
		  if(trim($email) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_email');
		     $this->isError = TRUE;
		  }
		  else if(!valid_email($email)){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_email');
		     $this->isError = TRUE;
		  }
		  //else if(!$this->webservice->sg_email_exist($email)){
		  else if($this->pages->_isexist_user($email) == FALSE){
		     $this->message = $this->error_handler->_getStatusMessage('not_email_exist');
		     $this->isError = TRUE;
		  }
	     }
	     if($this->isError === FALSE)
	     {
		  $DataArr = $this->pages->_getuserdetail_by_email($email);
		  $generated_code = random_string();
		  $updateArray = array(
				       'generated_code' => $generated_code,
				       );
		  $DataArr1 = $this->pages->update_user($DataArr['id'],$updateArray);
		  $link = base_url().'changepassword/'.base64_encode($DataArr['id']);
		  $mail_send =  $this->_send_email($email, $DataArr['name'], $link,'forgot_password');
		  if($mail_send == 1){
		     $this->status = "success";
		     $this->message = $this->error_handler->_getStatusMessage('send_link_mail');
		     $DataArr1 = array();
		  }
	     }
	  }
	  //$data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr1, 'message' => $this->message));
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
   
   /**
    * Method name: viewProfile
    * @description :  used to view the user profile
    * @param:  int $user_id
    * @return:  array
    */
   public function viewProfile()
   {
	$insertArr = array();
	$DataArr = array();
	$DataArr1 = array();
	$DataArr = $this->_debugMode();
	$postData = $this->input->post();
	$data['showHtml'] = @$postData['showHtml'];
	
	unset($postData['showHtml']);
	unset($postData['submit']);
	unset($postData['mode']);

	if($this->input->server('REQUEST_METHOD') === "POST" &&  @$_POST['mode'] != "debug")
        {
	   foreach($postData as $key => $post)
	   {
		$$key = self::_stripTags_trim($post);
		$insertArr[$key] = self::_stripTags_trim($post);
	   }

	   if($this->isError === FALSE)
	   {
		$shopData = $this->webservice->getUserDetails($shop_id);
		$userData = $this->webservice->getUserDetails($user_id);
		
		if(trim($user_id) ==""){
		   $this->message = $this->error_handler->_getStatusMessage('empty_user_id');
		   $this->isError = TRUE;
		}
		elseif(count($userData) == 0 ||  ($userData['status']!='Active'))
		{
		   $this->message = $this->error_handler->_getStatusMessage('invalid_user_id');
		   $this->isError = TRUE;
		}
		elseif($shop_id >0 && (count($shopData) == 0 ||  ($shopData['status']!='Active')))
		{
		   $this->message = $this->error_handler->_getStatusMessage('invalid_shop_id');
		   $this->isError = TRUE;
		}
	   }
	   if($this->isError === FALSE)
	   {
		$DataArr_one =array('total_reviews'=>0,'total_products'=>0,'total_rating'=>0,'follow_status'=>"",'total_followers'=>0, 'total_following'=>0,'total_request'=>0,'blacklist_status'=>"");
		$DataArr = $this->webservice->getUserDetails($shop_id);
		
		$DataArr['dob'] = $DataArr['dob'] !="0000-00-00" ? date('d-m-Y',strtotime($DataArr['dob'])) :  "00-00-0000";
		$insertArr['account_type'] = $DataArr['account_type'];
		if($shop_id > 0)
		{
		   $DataArr_one = $this->webservice->get_shopDetailCount($insertArr);
		}
		
		$DataArr = array_merge($DataArr,$DataArr_one);
		if($shop_id == $user_id){
		   $DataArr['follow_status'] = "";
		}
		
		$posted_reviews = $this->webservice->getShopReviewsByUserId($user_id,$shop_id);
		$DataArr['posted_reviews'] =empty($posted_reviews)?"":$posted_reviews; 
		
		$this->message = $this->error_handler->_getStatusMessage('user_found');
		$this->status = "success";
	   }
	}
	
	$data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	$this->template('output',$data);
   }
   
     /**
      * Method name: editProfile
      * @description :  used to edit the user profile
      * @param:  Request data
      * @return:  array
      */
     public function editProfile()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $image = $image_name = '';
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  //_print_r($postData);exit;
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
     
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
     
	     if($this->isError === FALSE)
	     {
		  $userData = $this->webservice->getUserDetails($user_id);
		  if(trim($user_id) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_user_id');
		     $this->isError = TRUE;
		  }elseif(count($userData)==0){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_user_id');
		     $this->isError = TRUE;
		  }
		  elseif(trim($name) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_name');
		     $this->isError = TRUE;
		  }
		  else if(trim($email) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_email');
		     $this->isError = TRUE;
		  }
		  else if(!valid_email($email)){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_email');
		     $this->isError = TRUE;
		  }
		  else if($this->webservice->sg_email_exist($email,$user_id)){
		     $this->message = $this->error_handler->_getStatusMessage('email_exists');
		     $this->isError = TRUE;
		  }
		  else if(trim($dob) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_dob');
		     $this->isError = TRUE;
		  }
		  else if(trim($gender) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_gender');
		     $this->isError = TRUE;
		  }
		  else if($phone_number !="" && _valid_phone_number($phone_number)!=true){
		     $this->message = $this->error_handler->_getStatusMessage('validcontact_no');
		     $this->isError = TRUE;
		  }
		  else if($phone_number !="" && strlen($phone_number) < 8){
		     $this->message = $this->error_handler->_getStatusMessage('min_contactnumber');
		     $this->isError = TRUE;
		  }
		  else if($phone_number !="" && strlen($phone_number) > 15){
		     $this->message = $this->error_handler->_getStatusMessage('max_contactnumber');
		     $this->isError = TRUE;
		  }
		  elseif($userData['account_type'] == "shopowner" && trim($website_url) !="" && _valid_website_url($website_url)!=true){
		     $this->message = $this->error_handler->_getStatusMessage('validwebsite_url');
		     $this->isError = TRUE;
		  }
		  elseif($userData['account_type'] == "shopowner" && trim($shop_description) ==""){
		     $this->message = $this->error_handler->_getStatusMessage('empty_shop_description');
		     $this->isError = TRUE;
		  }
		  /*elseif(strlen(trim($shop_description)) >250)
		  {
		     $this->message = $this->error_handler->_getStatusMessage('shop_description_maxlen');
		     $this->isError = TRUE;
		  }*/
		  elseif(trim($image_name)==""  && (isset($_FILES['image_name']) && ($_FILES['image_name']['name'] =="") && $_FILES['image_name']['error'] >0))
		  {
		     $this->message = $this->error_handler->_getStatusMessage('empty_image');
		     $this->isError = TRUE;
		  }
		  elseif(isset($_FILES['image_name']) && ($_FILES['image_name']['name'] !="") && ($this->_fileUploadValidation($_FILES['image_name']['name']) == FALSE))
		  {
		     $this->message = $this->error_handler->_getStatusMessage('invalid_filetype');
		     $this->isError = TRUE;
		  }
	     }
	     if($this->isError === FALSE)
	     {
		  $user_dataArr = $this->webservice->getUserDetails($user_id);
		  if(isset($_FILES['image_name']) && $_FILES['image_name']['name'] !="" && $_FILES['image_name']['error'] ==0){
		     $image = $_FILES['image_name']['name'];
		     $tmp_path = $_FILES['image_name']['tmp_name'];
		     $image_name = uploadImage($image, $tmp_path,'users_profile');
		     $insertArr['image_name'] = $image_name ;
		     //create thumbnail
		     $this->load->library('upload');
		     $this->load->library('image_lib');
		     
		     $source_imagepath='./uploads/users_profile/'.$image_name;
		     
		     $thumbimage_name="thumb_".$image_name;
		     $dest_imagepath='./uploads/users_profile/'.$thumbimage_name;
		     $config1['image_library'] = 'gd2';
		     $config1['source_image']	= $source_imagepath;
		     $user_image_size=$this->config->item('user_thumbimage_size');
		     $user_image_size=$user_image_size[0];
		     $config1['maintain_ratio'] = TRUE;
		     $config1['width']	= $user_image_size[0];
		     //$config1['height']	= $user_image_size[1];
		     $config1['new_image']   = $dest_imagepath;
		     
		     $this->image_lib->initialize($config1);
		      
		     $this->image_lib->resize();
		     $this->image_lib->clear();
		     
		     @unlink('./uploads/users_profile/'.$user_dataArr['image_name']); 
		     @unlink('./uploads/users_profile/thumb_'.$user_dataArr['image_name']); 	
		  }
		  unset($insertArr['user_id']);
		  //$insertArr['created_on'] = date('Y-m-d H:i:s');
		  $insertArr['dob'] = date('Y-m-d',strtotime($dob));
		  $insertID = $this->webservice->update_user($user_id,$insertArr);
		  $DataArr = $this->pages->_getUser_by_email($email);
		  $DataArr['dob'] = date('d-m-Y',strtotime($DataArr['dob']));
		  $this->message = $this->error_handler->_getStatusMessage('user_updated');
		  $this->status = "success";
	     }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }

     /**
      * Method name: editProfile
      * @description :  used to edit the user profile
      * @param:  Request data
      * @return:  array
      */
     public function updateUserTimeZone()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $image = $image_name = '';
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
     
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	  {
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
     
	     if($this->isError === FALSE)
	     {
		  $userData = $this->webservice->getUserDetails($user_id);
		  if(trim($user_id) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_user_id');
		     $this->isError = TRUE;
		  }elseif(count($userData)==0){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_user_id');
		     $this->isError = TRUE;
		  }
		  
	     }
	     if($this->isError === FALSE)
	     {
		  
		  $time_zone = __getTimeZone();
		   $updatArray = array(
					    
					     'time_zone' => $time_zone,
					    
					     );
		  
		  $insertID = $this->webservice->update_user($user_id,$updatArray);
		  
		  $this->message = $this->error_handler->_getStatusMessage('user_updated');
		  $this->status = "success";
	     }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $time_zone, 'message' => $this->message));
	  $this->template('output',$data);
     }

    
     /**
      * Method name: _debugMode
      * @description :  used for debug the posted data
      * @param:  Request data
      * @return:  array
      */
     public function _debugMode()
     {
	  $DataArr = array();
	  if(isset($_POST['mode']) && $_POST['mode'] == "debug")
	  {
	     $this->status = "debug";
	     $this->message = "Debug Mode";
	     $DataArr = $_POST;
	     return $DataArr;
	  }
	  else{
	     return array();
	  }
     }
   
     /**
      * Method name: _send_email
      * @description :  used to send emails
      * @param:  string $email, $string $name, string $link,string $mail_obj
      * @return:  array
      */
     public function _send_email($email, $name, $link,$mail_obj)
     {
	  $adminEmail =  $this->admin_model->getconfig('signup_email');
	  $msg = $this->webservice->_getMessage($mail_obj);
     
	  $message  	= html_entity_decode($msg->content);
	  $subject 	= html_entity_decode($msg->subject);
     
	  $patternFind1[0] 	= '/{name}/';
	  $patternFind1[1] 	= '/{link}/';
     
	  $replaceFind1[0] 	= $name;
	  $replaceFind1[1] 	= '<a href="'.$link.'" target="_blank">'.$link.'</a>';
     
	  $txtdesc_contact		= stripslashes($message);
	  $contact_sub		= stripslashes($subject);
	  $contact_sub		= preg_replace($patternFind1, $replaceFind1, $contact_sub);
	  $ebody_contact 		= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);
	  
	  try
	  {
	     $email_config = array(
	     'protocol'  => 'smtp',
	     'smtp_host' => $this->admin_model->getconfig('smtp_server_host'),
	     'smtp_port' => $this->admin_model->getconfig('smtp_port_number'),
	     'smtp_user' => $this->admin_model->getconfig('smtp_uName'),
	     'smtp_pass' => $this->admin_model->getconfig('smtp_uPass'),
	     'mailtype'  => 'html',
	     'starttls'  => true,
	     'newline'   => "\r\n"
	     );
	     $contact_sub = '['.SITE_NAME.']  '. $contact_sub;
	     $this->load->library('email', $email_config);
	     $this->email->initialize($email_config);
	     $this->email->from($adminEmail, SITE_NAME);
	     $this->email->to($email);
	     $this->email->subject($contact_sub);
	     $this->email->message($ebody_contact);
	     if($this->email->send()){
		  return 1;
	     }else{
		  return 0;
	     }
	  }catch(Exception $ex){
	     return 0;
	  }
     }
     
     
     /*
     * Method name: getCountryCode
     * @return:  json
     *
     */
     public function getCountryCode(){
	  $DataArr = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $limit = array('limit'=>45,'offset'=>0);
	  $data['showHtml'] = $postData['showHtml'];
	  unset($postData['showHtml']);
	  $DataArr = $this->webservice->_getCountryCode();
	  $this->message = $this->error_handler->_getStatusMessage('data_fetch');
	  $this->status = "success";
	  if($DataArr)
	  array_walk_recursive($DataArr, 'replacer');
     
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     
     }
   
     /**
      *This function is used to get list of categories
      *@param requested data
      *@return $array
      */
     public function getAllCategories()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
     
	     if($this->isError === FALSE)
	     {
		  $DataArr = $this->webservice->getCategoryList($category_status);
		  if(count($DataArr)>0){
		     if($page_no > 0)
		     {
		       $DataArr = getPaginationOnData($page_no,$DataArr,$this->record_per_page);
		     }
		     $this->status = "success";
		     $this->message = $this->error_handler->_getStatusMessage('category_list_found');
		  }else{
		     $this->message = $this->error_handler->_getStatusMessage('category_list_not_found');
		  }
	     }
	  }
	  //$data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr1, 'message' => $this->message));
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message,'base_url'=> CATEGORY_IMAGE));
	  $this->template('output',$data);
     }
   
     /**
      *This function is used to test the push notification
      *
      */
     public function testPushNotificationAndroid()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     $tokenArr = array_values(array_filter($postData['push_token']));
	     $message = "Test notification";
	     $notifyTo = 64;
	     $notifyFrom = 1;
	     $notifType = "Product";
     
	     $androidApiKey = $postData['api_key'];
	     $androidUrl = "https://android.googleapis.com/gcm/send";
	     //echo $this->androidApiKey . '---';
	     //print_r($tokenArr);
	     //echo '---';
     
	     $datetime = date('Y-m-d H:i:s');
	     $data = array("payload" => $message, 'action' => $notifType, 'sname' => "Test", 'dt' => $datetime,'badge'=>0);
	     $fields = array(
		   'registration_ids' => $tokenArr,
		   'data' => $data,
	     );
	     $headers = array(
		       'Authorization: key=' . $androidApiKey,
		       'Content-Type: application/json'
	     );
	     // Open connection
	     $ch = curl_init();
     
	     // Set the url, number of POST vars, POST data
	     curl_setopt($ch, CURLOPT_URL, $androidUrl);
     
	     curl_setopt($ch, CURLOPT_POST, true);
	     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
     
	     // Disabling SSL Certificate support temporarly
	     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
     
	     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
     
	     // Execute post
	     $result = curl_exec($ch);
     
	     curl_close($ch);
	     //        echo 'Result from google:' . $result . '---';
	     $res_dec = json_decode($result);
	     if($res_dec->success >= 1){
		  $this->message = $this->error_handler->_getStatusMessage('notification_sent');
		  $this->status = "success";
	     }else{
		  $this->message = $this->error_handler->_getStatusMessage('notification_not_sent');
	     }
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $res_dec, 'message' => $this->message));
	  $this->template('output',$data);
     }

     /**
      *This function is used to send push notification to apple device
      */
     public function testPushNotificationApple()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     $deviceToken = trim($postData['push_token']);
	     $message = "Test notification";
	     $notifyTo = 64;
	     $notifyFrom = 1;
	     $notifType = "Product";
     
	     $appleKey = APPPATH.'third_party/apns-dev.pem';
	    // $ios_cert_server = "ssl://gateway.push.apple.com:2195";
	     $ios_cert_server = "ssl://gateway.sandbox.push.apple.com:2195";
	     $ios_cert_pwd = "";
     
	     $ctx = stream_context_create();
	     stream_context_set_option($ctx, 'ssl', 'local_cert', $appleKey);
	     stream_context_set_option($ctx, 'ssl', 'passphrase', $ios_cert_pwd);
	     $fp = stream_socket_client($ios_cert_server, $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
     
	     if (!$fp){
		  exit("Failed to connect: $err $errstr" . PHP_EOL);
	     }
     
	     //echo '<br>'.date("Y-m-d H:i:s").' Connected to APNS' . PHP_EOL;
     
	     $body['aps'] = array(
				  'alert'         => $message,
				  'badge'     => '0',
				  'sound'     => 'default',
				  'action' => $notifType
		     );
     
	     // Encode the payload as JSON
	     $payload = json_encode($body);
	     //echo $payload;
	     // Build the binary notification
	     $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
     
	     // Send it to the server
	     $result = fwrite($fp, $msg, strlen($msg));
     
	     if (!$result) {
		  //echo '<br>'.date("Y-m-d H:i:s").' Message not delivered' . PHP_EOL;
		  $this->status = 'failed';
		  $this->message = date("Y-m-d H:i:s").' Message not delivered';
	     } else {
		  //echo '<br>'.date("Y-m-d H:i:s").' Message successfully delivered' . PHP_EOL;
		  $this->status = 'success';
		  $this->message = date("Y-m-d H:i:s").' Message successfully delivered';
	     }
	     // Close the connection to the server
	     fclose($fp);
	     echo '<br>'.date("Y-m-d H:i:s").' Connection closed to APNS' . PHP_EOL;
	  }
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $result, 'message' => $this->message));
	  $this->template('output',$data);
     }
     
     /**
      *This function is used to make user logged out form application
      *@param int $user_id
      *@return array
      */
     public function logout()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
	     if($this->isError === FALSE)
	     {
		  if(trim($user_id) == ''){
		     $this->message = $this->error_handler->_getStatusMessage('empty_user_id');
		     $this->isError = TRUE;
		  }elseif(count($this->webservice->getUserDetails($user_id))==0){
		     $this->message = $this->error_handler->_getStatusMessage('invalid_user_id');
		     $this->isError = TRUE;
		  }
	     }
	     if($this->isError === FALSE)
	     {
		  $updatArray = array(
					     'device_token' => '',
					     'device_type' => '',
					     'app_version' => '',
					     'is_login' => 0,
					   );
		  $insertID = $this->webservice->update_user($user_id, $updatArray);
		  $this->message = $this->error_handler->_getStatusMessage('user_logout');
		  $this->status = "success";
	     }
	  }
	  
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }
     
     /**
      *This function is used to make user logged out form application
      *@param int $user_id
      *@return  json
      */
     public function updateDeviceToken()
     {
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->post();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  if($this->input->server('REQUEST_METHOD') === "POST" &&  $_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
     
	     $userData = $this->webservice->getUserDetails($user_id);
     
	     if(trim($user_id) == '')
	     {
		  $this->message = $this->error_handler->_getStatusMessage('empty_user_id');
		  $this->isError = TRUE;
	     }
	     elseif(count($userData) == 0 || ($userData['status']!='Active'))
	     {
		  $this->message = $this->error_handler->_getStatusMessage('invalid_user_id');
		  $this->isError = TRUE;
	     }
     
	     if($this->isError === FALSE && $postData['user_id'] && $postData['device_token'] && $postData['app_version'] && $postData['device_type'] )
	     {
		  $DataArr = $this->webservice->create_user($postData);
		  if( count($DataArr) > 0){
		     $this->status = "success";
		     $this->message = $this->error_handler->_getStatusMessage('user_updated');
		  }else{
		     $this->message = $this->error_handler->_getStatusMessage('user_not_exist');
		  }
	     }
	  }
	  //$data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr1, 'message' => $this->message));
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
	  $this->template('output',$data);
     }

     /**
     *This function is used to validate the phone number
     *@param string $str
     *@return Boolean
     */
     function _fileUploadValidation($filename)
     {
	 $allowed_extension = array('jpg','jpeg','JPG','JPEG','gif','GIF','png','PNG');
	 $file_extension = _getExtension($filename);
	 $allowed_size = 2097152;//2mb
	 if(!in_array($file_extension, $allowed_extension)){
	    return FALSE;
	 }
	 return TRUE;
     }

     /**
      * Method name: _send_email
      * @description :  used to send emails
      * @param:  string $email, $string $name, string $link,string $mail_obj
      * @return:  array
      */
     public function _send_email_contact($data, $mail_obj)
     {
	  $adminEmail =  $this->admin_model->getconfig('signup_email');
	  $msg = $this->webservice->_getMessage($mail_obj);
     
	  $message  	= html_entity_decode($msg->content);
	  $subject 	= html_entity_decode($msg->subject);
     
	  $patternFind1[0] 	= '/{name}/';
	  $patternFind1[1] 	= '/{email}/';
	  $patternFind1[2] 	= '/{message}/';
     
	  $replaceFind1[0] 	= $data['name'];
	  $replaceFind1[1] 	= $data['email'];
	  $replaceFind1[2] 	= $data['message'];
     
	  $txtdesc_contact	= stripslashes($message);
	  $contact_sub		= stripslashes($subject);
	  $contact_sub		= preg_replace($patternFind1, $replaceFind1, $contact_sub);
	  $ebody_contact 		= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);
     
	  try
	  {
	     $email_config = array(
	     'protocol'  => 'smtp',
	     'smtp_host' => $this->admin_model->getconfig('smtp_server_host'),
	     'smtp_port' => $this->admin_model->getconfig('smtp_port_number'),
	     'smtp_user' => $this->admin_model->getconfig('smtp_uName'),
	     'smtp_pass' => $this->admin_model->getconfig('smtp_uPass'),
	     'mailtype'  => 'html',
	     'starttls'  => true,
	     'newline'   => "\r\n"
	     );
     
	     $this->load->library('email', $email_config);
	     $this->email->initialize($email_config);
	     $this->email->from($data['email'], $data['name']);
	     $this->email->to($adminEmail);
	     $this->email->subject($contact_sub);
	     $this->email->message($ebody_contact);
	     if($this->email->send()){
		  return 1;
	     }else{
		  return 0;
	     }
	  }catch(Exception $ex){
	     return 0;
	  }
     }

     /**
      *This fucntion is used to add contact into database posted by consumers
      *@param requested data
      *@return json
      */
     public function staticpage()
     {
     
	  $insertArr = array();
	  $DataArr = array();
	  $DataArr = $this->_debugMode();
	  $postData = $this->input->get();
	  $data['showHtml'] = @$postData['showHtml'];
	  unset($postData['showHtml']);
	  unset($postData['submit']);
	  unset($postData['mode']);
	  if($this->input->server('REQUEST_METHOD') === "GET" &&  $_POST['mode'] != "debug")
	{
	     foreach($postData as $key => $post)
	     {
		  $$key = self::_stripTags_trim($post);
		  $insertArr[$key] = self::_stripTags_trim($post);
	     }
     
	     if($this->isError === FALSE)
	     {
		 $DataArr = $this->webservice->getStaticContentByVariable($insertArr);
		 //print_r($DataArr);
		  if( $DataArr >0){
		     $this->load->view('webservice/staticpages', array('content_title' => $DataArr['content_title'], 'content' => $DataArr['content']));
		     $this->status = "success";
		     $this->message = $this->error_handler->_getStatusMessage('contact_success');
		  }else{
		     $this->message = $this->error_handler->_getStatusMessage('contact_error');
		  }
	     }
	  }
	  
	  $data['jsonData'] = json_encode(array('status' => $this->status, 'data'=> $DataArr, 'message' => $this->message));
     }
     function _stripTags_trim($string)
     {
	  return  strip_tags(trim($string));
     }
   
     public function template($template_name, $data = array())
     {	
	  $this->load->view('webservice/'.$template_name, $data);
     }
}

/* End of file webservice.php **/
/* Location: ./application/controllers/webservice.php */
?>
