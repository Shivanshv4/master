<?php
class Dashboard extends YS_Controller
{
   /***
    ***********************************************
    * Code to include model helper and libraries **
    ***********************************************
    */

   public function __construct()
   {
	parent::__construct();
	$this->load->model('Pages_model','pages');
	$this->load->model('Webservice_model','webservice');
	$this->load->model('Dashboard_model','dashboard');
	$this->load->helper('functions');
	$this->load->library('error_handler');
	$this->load->model('banner_model');

	$this->date_format = $this->admin_model->getconfig('date_format');
        $this->time_format = $this->admin_model->getconfig('time_format');

	$this->address = $this->admin_model->getconfig('address');
	$this->latitude = $this->admin_model->getconfig('latitude');
	$this->longitude = $this->admin_model->getconfig('longitude');
	$this->admin_email = $this->admin_model->getconfig('admin_email');
	$this->contact_no = $this->admin_model->getconfig('contact_no');


	  $ths->actionName = $this->uri->segment(1);
	  $actionNameArray = array('about', 'privacy','termsconditions','help','faq','guidelines');
	  if (!in_array($ths->actionName, $actionNameArray)){
	       checkLogin();
	  }
	//$this->output->enable_profiler(TRUE);
   }
   
   public function deleteProductImage(){
	 $imageId = $this->input->post('imageId');
	 // code to delete image
	 $this->webservice->deleteProductImage($imageId);	
   }
   
   public function myaccount()
   {
		
      checkLogin();
		include_once APPPATH.'/third_party/TweetPHP.php';
		
		//echo $TweetPHP->get_tweet_list();
		
      $data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
      
      $this->template('myaccount',$data);
   }
   
   public function dashboard() 
   {
     

	$this->template('dashboard',$data);

   }
   
   /**
    *This function is used to add the product by shopowner on front end
    *@param requested data
    */
   public function addProduct()
   {
	  set_time_limit(0);
      checkShopOwnerLogin();
	$name 			= $this->input->post('title');
	$price 			= $this->input->post('price');
	$description 	= $this->input->post('description');
	$id_category 	= $this->input->post('id_category');
	$product_type	= $this->input->post('product_type');
	$ses_data		= $this->session->userdata('user_data');
	$shop_id		= $ses_data['Userid'];

	$insertArr=array(
			     "shop_id"=>$shop_id,  
			     "name"=>$name,
			     "price"=>$price,
			     "description"=>$description,
			     "id_category"=>$id_category,
			     'product_type'=> $product_type
			     );

	$insertArr['cstatus'] = 'Active' ;

	$insertID = $this->dashboard->add_product($insertArr);

	if($insertID)
	{
	  
	   $product_images = $this->input->post('txtproduct_image');
	 
	   if(count($product_images)) {
		foreach($product_images as $prod_image) {
		 if(trim($prod_image)) {

		  
		  $product_image_name = $org_image_name = $prod_image;
		  $insertImagesArray['image'] = $product_image_name;
		  $insertImagesArray['product_id'] = $insertID;
		  $this->webservice->shop_product_image($insertImagesArray);
		  
		   /// copy image from temp to product image folder
		  $source_temp_path = "uploads/temp/product_image/".$org_image_name;
		    $dest_path = "uploads/product_image/".$org_image_name;
		    
		    if(file_exists($source_temp_path))
		    {
			 if(@copy($source_temp_path,$dest_path))
			 {
			 
			      $source_temp_path = "uploads/temp/product_image/thumb_".$org_image_name;
			      $dest_path = "uploads/product_image/thumb_".$org_image_name;
			     
			     $new_image = $org_image_name;
			     
			      @copy($source_temp_path,$dest_path);
			      
			 }
		    }
		  
		  ///////// resize in 100px of cropped image
		  $this->load->library('image_lib');
		  
		    $source_imagepath='./uploads/temp/product_image/thumb_'.$org_image_name;
		    $thumbimage_name="sm_".$org_image_name;
		    $dest_imagepath='./uploads/product_image/'.$thumbimage_name;
		    $config1['image_library'] = 'gd2';
		    $config1['source_image']	= $source_imagepath;
		    $product_image_sizes=$this->config->item('product_thumbimage_size');
		    
		    $product_image_size=$product_image_sizes[2];
		    $config1['maintain_ratio'] = true;
		    $config1['width']	= $product_image_size[0];
  
		    $config1['new_image']   = $dest_imagepath;
		    
		    $this->image_lib->initialize($config1);
		     
		    $this->image_lib->resize();
		    $this->image_lib->clear();
		    // end
		    
		    // delete image from temp folder
		    if(file_exists(FCPATH.'uploads/temp/product_image/'.$org_image_name))
		    {
			 @unlink(FCPATH.'uploads/temp/product_image/'.$org_image_name);
			 @unlink(FCPATH.'uploads/temp/product_image/thumb_'.$org_image_name);
		    }
		  
		 }
		}
	   }
	   
	   $this->message = $this->error_handler->_getStatusMessage('shop_product_success');
	   $successMessage = $ses_data['name'].' added a new product: '.$name;
	   $this->status = "success";

	   $product=$this->dashboard->getProductByID($insertID);
	   $imagePth = $this->dashboard->getProductImageById($insertID);
		 $product_html = '<div class="thumbnail">
				    <div class="thumb">
				      <img src="'.$imagePth.'" alt="'.$name.'">
				      <span class="overlay">
					<span>
					    <a href="'.site_url('shop/product/edit/'.base64_encode($product['id'])).'" alt="Edit" class="edit">Edit</a>
					    <a onclick="return confirm(\'Are you sure to delete this product?\')" href="'.site_url('shop/product/delete/'.base64_encode($product['id'])).'" class="delete" alt="Delete">Delete</a>
					</span>
				      </span>
				    </div>
				    <div class="caption">
					<div class="row">
					    <h3 class="col-md-7 col-sm-6 col-xs-12"><a href="'.site_url('shop/product/detail/'.base64_encode($product['id'])).'" class="color-black">'.ucfirst($name).'</a></h3>
					    <h3 class="col-md-5 col-sm-6 col-xs-12 text-right color-red">$'.$product['price'].'</h3>
					</div>
					<!--<p>Minnion Swan</p>-->
				    </div>
				</div>';
	  
	  //save into notification table
	   $notiArray = array('detail_id'=>$insertID, 'from_id'=>$shop_id,'to_id'=> "",'type'=>'new_product');
	   $notification_id = $this->pages->addNotifications($notiArray);
	   			
				
	   $r= new stdClass();
	   $r->error=0;
	   $r->id=$insertID;
	   $r->message=$successMessage;
	   $r->product_html=$product_html;
	   echo json_encode($r);
      }
	else
	{
	   $r= new stdClass();
	   $r->error=1;
	   $r->message=$this->error_handler->_getStatusMessage('shop_product_error');
	   echo json_encode($r);
	}
   }
   
   /**
    *This function is used to update the product by shopowner on front end
    *@param requested data
    */
   public function editproduct()
   {
     
	checkShopOwnerLogin();
	$sesion_data = $this->session->userdata('user_data');
	$data['title'] = ucfirst('Welcome To '.SITE_NAME.'');
	$productId = @base64_decode($this->uri->segment(4));
	$product_data = $this->dashboard->getProductByID($productId);
	$data['featured_count'] =  count($this->dashboard->getFeaturedProduct($sesion_data['Userid']));

	
	if(count($product_data)>0 && $product_data['cstatus'] == 'Active')
	{
	   $productImages = $this->webservice->get_product_image($product_data['id']);
	   

	   $data['productData']=array(
			   'name'		=> $product_data['name'],
			   'price'		=> $product_data['price'],
			   'description'=> $product_data['description'],
			   'cstatus'	=> $product_data['cstatus'],
			   'image'		=> $product_data['image'],
			   'productimages'		=> $productImages,
			   'id_category'=> $product_data['id_category'],
			   'product_type'=> $product_data['product_type'],
			   'featured'=> $product_data['featured']
			 );

	   if(count($this->input->post()) > 0 )
	   {
		$name	= $this->input->post('name');
		$price	= $this->input->post('price');
		$description	= $this->input->post('description');
		
		$cstatus	= $this->input->post('cstatus');
		$image_data= $this->input->post('image_data');
		$id_category= $this->input->post('id_category');
		$product_type	= $this->input->post('product_type');
		$imageIds	= $this->input->post('imageIds');
		$featured	= $this->input->post('featured');
		$product_images = $this->input->post('txtproduct_image');

		$productImages = $this->webservice->get_product_image($product_data['id']);
		
		$data['productData']=array(
			'name'			=> $name,
			'price'			=> $price,
			'description'	=> $description,
			//'cstatus'		=> $cstatus,
			'id_category'	=> $id_category,
			'image_data'	=> $image_data,
			'image'			=> $product_data['image'],
			'productimages'		=> $productImages,
			'product_type'	=> $product_type,
			'featured'	=> $featured,
			'product_images'	=> $product_images,
		);
		
		 
		$this->form_validation->set_rules('name', 'Product Name', 'trim|strip_tags|required');
		$this->form_validation->set_rules('id_category', 'Category', 'trim|strip_tags|required');
		$this->form_validation->set_rules('price', 'Price', 'trim|strip_tags|required|callback_isvalidPrice');
		$this->form_validation->set_rules('description', 'Description', 'trim|strip_tags|required');
		if($product_data['featured'] != 'Yes')
		  $this->form_validation->set_rules('featured', 'Featured', 'trim|required|callback_check_equal_less['.$data['featured_count'].']');

	   // $this->form_validation->set_rules('featured', 'Featured', 'trim|greater_than[3]');

		//$this->form_validation->set_rules('cstatus', 'Status', 'trim|strip_tags|required');
		  
		if ($this->form_validation->run() === FALSE)
		{
		    if(count($product_images)) {
			 $data['temp_product_images']=$product_images;
		    }
		   $this->template('product_edit',$data);
		}
		else
		{
		   $productupdate['productData']=array(
				'name'			=> $name,
				'id_category'	=> $id_category,
				'price'			=> $price,
				'description'	=> $description,
				//'cstatus'		=> $cstatus,
				'product_type'	=> $product_type,
				'featured'	=> $featured,
		   );
		   

		 if(count($product_images)) {
		  foreach($product_images as $prod_image) {
		   if(trim($prod_image)) {
			
			
			 $product_image_name = $org_image_name = $prod_image;
			 $insertImagesArray['image'] = $product_image_name;
			 $insertImagesArray['product_id'] = $productId;
			 $this->webservice->shop_product_image($insertImagesArray);
			
			 /// copy image from temp to product image folder
			 $source_temp_path = "uploads/temp/product_image/".$org_image_name;
			 $dest_path = "uploads/product_image/".$org_image_name;
			   
			 if(file_exists($source_temp_path))
			 {
			      if(@copy($source_temp_path,$dest_path))
			      {
				   
				   $source_temp_path = "uploads/temp/product_image/thumb_".$org_image_name;
				   $dest_path = "uploads/product_image/thumb_".$org_image_name;
				  
				  $new_image = $org_image_name;
				  
				   @copy($source_temp_path,$dest_path);
				   
				  
			      }
			      
			      ///////// resize in 100px of cropped image
			      $this->load->library('image_lib');
			      
				$source_imagepath='./uploads/temp/product_image/thumb_'.$org_image_name;
				$thumbimage_name="sm_".$org_image_name;
				$dest_imagepath='./uploads/product_image/'.$thumbimage_name;
				$config1['image_library'] = 'gd2';
				$config1['source_image']	= $source_imagepath;
				$product_image_sizes=$this->config->item('product_thumbimage_size');
				
				$product_image_size=$product_image_sizes[2];
				$config1['maintain_ratio'] = true;
				$config1['width']	= $product_image_size[0];
	      
				$config1['new_image']   = $dest_imagepath;
				
				$this->image_lib->initialize($config1);
				 
				$this->image_lib->resize();
				$this->image_lib->clear();
				// end
				
				// delete image from temp folder
				if(file_exists(FCPATH.'uploads/temp/product_image/'.$org_image_name))
				{
				     @unlink(FCPATH.'uploads/temp/product_image/'.$org_image_name);
				     @unlink(FCPATH.'uploads/temp/product_image/thumb_'.$org_image_name);
				}
			 }
			
		   }
		  }
		 }
		  $productImages = $this->webservice->get_product_image($productId);
		  $data['productData']['productimages'] = $productImages;
		   
		 
		   
		   $this->dashboard->update_product($productId,$productupdate['productData']);
		   _showMessage("Product has been updated successfully",'success');
		    header('refresh: 3; url='.base_url('dashboard'));
		   $this->template('product_edit',$data);
		}
	   }
	   else
	   {
	     $this->template('product_edit',$data);
	   }
	}
	else
	{
	   redirect('dashboard');
	   //$this->template('product_edit',$data);
	}
   }

  function check_equal_less($featured__field, $featurCount)
  {
  $totalFeatu = 3;

  if($featured__field == 'Yes')
	 $totalFeatu = $totalFeatu-1;
   
   if ($featurCount >  $totalFeatu)
   {
	$this->form_validation->set_message('check_equal_less', 'Only a maximum of 3 products can be featured.');
	return false;
   }
   else
   {
	return true;
   }
  }

  
     
  
     function isvalidPrice()
     {
	  $value = $this->input->post('price');
	  if ($value == '') {
		 $this->form_validation->set_message('isvalidPrice', 'Price is required');
		  return false;
	  }
	  else
	  {
		  if (!preg_match('/[0-9]|\./', $value))
		  {
		       $this->form_validation->set_message('isvalidPrice', 'Please enter valid price');
			return false;
		      
		  }
	  }
     }
     public function template($template_name, $data = array())
     {	
	  $ses_data = $this->session->userdata('user_data');
	  if(count($ses_data)) {
	       $this->load->view('templates/header', $data);
	       $this->load->view('pages/'.$template_name, $data);
	      // $this->load->view('templates/myaccount_footer', $data);
	       $this->load->view('templates/footer', $data);
	  } else {
	       $this->load->view('templates/header', $data);
	       $this->load->view('withoutlogin/header_section', $data);
	       $this->load->view('withoutlogin/'.$template_name, $data);
	       $this->load->view('withoutlogin/footer_section', $data);
	       $this->load->view('templates/footer', $data);
	  }

     }

     function about (){
       $data['title'] = 'About Us';
       $data['pagedate'] = $this->dashboard->getStaticContentByVari('about_us','Active');
       $this->template('staticpage',$data);
     }

	function privacy (){ 
	   $data['title'] = 'Privacy Policy';
	   $data['pagedate'] = $this->dashboard->getStaticContentByVari('privacy_policy','Active');
	   $this->template('staticpage',$data);
	}

	function termsconditions (){
	   $data['title'] = 'Terms Conditions';
	   $data['pagedate'] = $this->dashboard->getStaticContentByVari('terms_conditions','Active');
	   $this->template('staticpage',$data);
	}
        function help()
	{
	  $data['title'] = 'Help';
	   $data['pagedate'] = $this->dashboard->getStaticContentByVari('help','Active');
	   $this->template('staticpage',$data);
	}
	function faq()
	{
	  $data['title'] = 'FAQ';
	   $data['pagedate'] = $this->dashboard->getStaticContentByVari('faq','Active');
	   $this->template('staticpage',$data);
	}
	function guidelines()
	{
	   $data['title'] = 'Community Guidelines';
	   $data['pagedate'] = $this->dashboard->getStaticContentByVari('community_guidelines','Active');
	   $this->template('staticpage',$data);
	}
	function contactus (){
	  
	  $planId = @base64_decode($this->uri->segment(2));
	  $data['ses_data'] = $this->session->userdata('user_data');
	  
	  $data['title'] 	= 'Contact Us';
	  $data['address'] 	= $this->address;
	  $data['latitude'] 	= $this->latitude;
	  $data['longitude'] 	= $this->longitude;
	  $data['admin_email'] 	= $this->admin_email;
	  $data['contact_no'] 	= $this->contact_no;
	  $data['planId'] 	= $planId;
	  if($planId) {
	   $data['title'] 	= 'Advertise With Us';
	   $data['plan_data'] = $this->banner_model->GeAdvertisementById($planId);

	  }
	   $this->template('contactus',$data);
	}
     function followers()
	{
	   $data['title'] = 'Followers';
	   $ses_data=$this->session->userdata('user_data');

	  $data['date_format'] = $this->date_format;
	  $data['time_format'] = $this->time_format;
	 $followersList = $this->dashboard->getShopFollowers($ses_data['Userid'],$ses_data['account_type']);
	   $data["total_followers"] = count($followersList);

	   $DataArr = getPaginationOnData(1,$followersList,$this->config->item('listperpage'));
	  $data["followers"] = $DataArr;
	  $this->template('followers',$data);
	}
	function notification()
	{
	   $data['title'] = 'Notification';
	   $ses_data=$this->session->userdata('user_data');
	  $data['sess_data'] = $ses_data;
	  $data['date_format'] = $this->date_format;
	  $data['time_format'] = $this->time_format;
	  
	   $notification_list = $this->dashboard->getNotification(array('notification.to_id' => $ses_data['Userid']),'',$ses_data['Userid']);

	   $data["total_notification"] = count($notification_list);

	   $DataArr = getPaginationOnData(1,$notification_list,$this->config->item('listperpage'));

	  $data["notification"] = $DataArr;
	  $this->template('notification',$data);
	}

        function follower_loadmore()
	{
	  $pages =$this->input->post('page_num');

	  $data['title'] = 'Notification';
	  $ses_data=$this->session->userdata('user_data');

	  $data['date_format'] = $this->date_format;
	  $data['time_format'] = $this->time_format;

	  $followersList = $this->dashboard->getShopFollowers($ses_data['Userid'],$ses_data['account_type']);

	  $data["total_followers"] = count($followersList);
	  $DataArr = getPaginationOnData($pages,$followersList,$this->config->item('listperpage'));

	  $data["followers"] = $DataArr;

	  $this->load->view('pages/follower_loadmore', $data);
	}


	function notification_loadmore()
	{
	  $pages =$this->input->post('page_num');

	  $data['title'] = 'Notification';
	  $ses_data=$this->session->userdata('user_data');

	  $data['date_format'] = $this->date_format;
	  $data['time_format'] = $this->time_format;

	  $notification_list = $this->dashboard->getNotification(array('notification.to_id' => $ses_data['Userid']));

	  $data["total_notification"] = count($notification_list);
	  $DataArr = getPaginationOnData($pages,$notification_list,$this->config->item('listperpage'));

	  $data["notification"] = $DataArr;

	  $this->load->view('pages/notification_loadmore', $data);
	}


	function wishlist (){
	 $data['title'] = 'Wishlist';
	 $ses_data = $this->session->userdata('user_data');
	 $requested_page = $this->input->post('page_num');
	 $page_no = (!$requested_page) ? 1 : $requested_page;
	 $listperpage = $this->config->item('listperpage');
	 $DataArr = $this->webservice->getWishlistProudcts($ses_data['Userid']);
	 $data['total_products'] = count($DataArr);
	 $DataLists = getPaginationOnData($page_no,$DataArr,$listperpage);
	 $data['properdLists'] = $DataLists;
	if($page_no != 1) {
	  echo $this->load->view('pages/loadmore_wishlist', $data);
	} else {
	  $this->template('wishlist',$data);
	}

	}
	/**
	 *This function is used to alerts setting
	 *@param login user id
	 */

	function alerts (){
	   $data['title'] = 'Settings';
	   $ses_data = $this->session->userdata('user_data');
	   $data['ses_data'] = $ses_data;
	   $data['user_data'] = $this->admin_model->getAllUsers($ses_data['Userid']);
	   $this->template('alerts',$data);
	}

	/**
	 *
	 */
	public function saveUserSettings()
	{
	   $settingsArr = array();
	   $type = trim($this->input->post('type'));
	   $value = trim($this->input->post('value'));
	   $ses_data = $this->session->userdata('user_data');
	   if($type !="" && $value!=""){
		if($type == "notifications"){
		   $settingsArr['notifications'] = $value;
		}elseif($type == "email_alert"){
		   $settingsArr['email_alert'] = $value;
		}elseif($type == "new_chat"){
		   $settingsArr['new_chat'] = $value;
		}
		elseif($type == "new_product_posted"){
		   $settingsArr['new_product_posted'] = $value;
		}
		$save_settings = $this->pages->update_user($ses_data['Userid'],$settingsArr);
		if($save_settings){
		   $r= new stdClass();
		   $r->error=0;
		   $r->message="Settings have been saved successfully.";
		   echo json_encode($r);
		}else{
		   $r= new stdClass();
		   $r->error=1;
		   $r->message="Unable to update the user.";
		   echo json_encode($r);
		}
	   }else{
		$r= new stdClass();
		$r->error=1;
		$r->message="Unable to process the request.";
		echo json_encode($r);
	   }
	}

	/**
	 *This function is used to change password
	 *@param login user id
	 */
	function security (){
	   $data['title'] = 'Settings';
	   $ses_data = $this->session->userdata('user_data');

	   $data['ses_data'] = $ses_data;

	   $data['user_data'] = $this->admin_model->getAllUsers($ses_data['Userid']);
	   $this->template('security',$data);
	}

	public function saveUserPassword()
	{
	   $settingsArr = array();
	   $current_password = trim($this->input->post('current_password'));
	   $new_password = trim($this->input->post('new_password'));
	   $confirm_password = trim($this->input->post('confirm_password'));
	   $ses_data = $this->session->userdata('user_data');
	   $userData = $this->admin_model->getAllUsers($ses_data['Userid']);
	   if($current_password !="" && $new_password!="" && $confirm_password !=""){
		if($userData['password'] != md5($current_password)){
		   $r= new stdClass();
		   $r->error=2;
		   $r->message="The current password does not match.";
		   echo json_encode($r);
		}else{
		   $settingsArr['password'] = md5($new_password);
		   $save_settings = $this->pages->update_user($ses_data['Userid'],$settingsArr);
		   $r= new stdClass();
		   $r->error=0;
		   $r->message="Password has been updated successfully.";
		   echo json_encode($r);
		}
	   }else{
		$r= new stdClass();
		$r->error=1;
		$r->message="Unable to process the request.";
		echo json_encode($r);
	   }
	}

	/**
	 *This function is used to manage Block users
	 *@param login user id
	 */
	function blockusers (){
	  checkLogin();

	  $ses_data = $this->session->userdata('user_data');

	  $requested_page = $this->input->post('page_num');
	  $page_no = (!$requested_page) ? 1 : $requested_page;

	  $DataArrLists = $this->webservice->getBlockUsersList($ses_data['Userid'], 'Block');

	  $DataArr = getPaginationOnData($page_no,$DataArrLists,$this->record_per_page);

	 // print_r($DataArr);
	  $data['title'] = 'Settings';
	  $data['userLists'] = $DataArr;
	  $data['userListsCount'] = count($DataArr);
	  $data['date_format'] = $this->date_format;
	  $data['time_format'] = $this->time_format;

	  if($page_no != 1) {
	       echo $this->load->view('shopnow/loadmore_mrequestlist', $data);
	  } else {
	       $this->template('block_users',$data);
	  }

	}

	/**
	 *This function is used to change the status of users (blocked/unblock)
	 *@param Requested data
	 *@return json
	 */
	public function doUserUnblock()
	{
	   $status = trim($this->input->post('status'));
	   $id_block = trim($this->input->post('id_block'));
	   if($id_block >0){
		$dataArr =array('id_block'=>$id_block, 'status'=>$status);
		$return_status = $this->webservice->updateBlockedUserStatus($dataArr);
		if($return_status ==1){
		   $r= new stdClass();
		   $r->error= 0;
		   $r->message="User has been unblocked successfully.";
		   echo json_encode($r);
		}else{
		   $r= new stdClass();
		   $r->error=1;
		   $r->message="Unable to update the user status.";
		   echo json_encode($r);
		}
	   }else{
		$r= new stdClass();
		$r->error=1;
		$r->message="Unable to process the request.";
		echo json_encode($r);
	   }
	}

	/**
	 *This function is used to change the status of users (blocked/unblock)
	 *@param Requested data
	 *@return json
	 */
	public function doUserBlock()
	{
	   $status = trim($this->input->post('status'));
	   $shop_id = trim($this->input->post('shop_id'));
	   $user_id = trim($this->input->post('user_id'));
	   if($shop_id >0 && $user_id){
		$dataArr =array('user_id'=>$user_id,'shop_id'=>$shop_id, 'status'=>$status);
		$return_status = $this->webservice->updateBlockedUserStatus($dataArr);
		if($return_status ==1){
		   $r= new stdClass();
		   $r->error= 0;
		   $r->message="User has been blocked successfully.";
		   echo json_encode($r);
		}else{
		   $r= new stdClass();
		   $r->error=1;
		   $r->message="Unable to update the user status.";
		   echo json_encode($r);
		}
	   }else{
		$r= new stdClass();
		$r->error=1;
		$r->message="Unable to process the request.";
		echo json_encode($r);
	   }
	}

     public function _send_email_contact($data, $mail_obj)
     {
	  $adminEmail =  $this->admin_model->getconfig('admin_email');
	  $msg = $this->webservice->_getMessage($mail_obj);

	  $message  	= html_entity_decode($msg->content);
	  $subject 	= html_entity_decode($msg->subject);

	  $patternFind1[0] 	= '/{name}/';
	  $patternFind1[1] 	= '/{email}/';
	  $patternFind1[2] 	= '/{message}/';

	  $replaceFind1[0] 	= $data['name'];
	  $replaceFind1[1] 	= $data['email'];
	  $replaceFind1[2] 	= $data['message'];

	  $txtdesc_contact	= stripslashes($message);
	  $contact_sub		= stripslashes($subject);
	  $contact_sub		= preg_replace($patternFind1, $replaceFind1, $contact_sub);
	  $ebody_contact 		= preg_replace($patternFind1, $replaceFind1, $txtdesc_contact);

	  try
	  {
	     $email_config = array(
	     'protocol'  => 'smtp',
	     'smtp_host' => $this->admin_model->getconfig('smtp_server_host'),
	     'smtp_port' => $this->admin_model->getconfig('smtp_port_number'),
	     'smtp_user' => $this->admin_model->getconfig('smtp_uName'),
	     'smtp_pass' => $this->admin_model->getconfig('smtp_uPass'),
	     'mailtype'  => 'html',
	     'starttls'  => true,
	     'newline'   => "\r\n"
	     );

	     $this->load->library('email', $email_config);
	     $this->email->initialize($email_config);
	     $this->email->from($data['email'], $data['name']);
	     $this->email->to($adminEmail);
	     $this->email->subject($contact_sub);
	     $this->email->message($ebody_contact);
	     if($this->email->send()){
		  return 1;
	     }else{
		  return 0;
	     }
	  }catch(Exception $ex){
	     return 0;
	  }
     }

/****
    *This function is used to post the contact request
    */
     public function post_contact()
     {
	  
	  $data['title']  = "POST NEW REQUEST";
	  if($this->input->server('REQUEST_METHOD') === "POST")
	  {
	       $ses_data=$this->session->userdata('user_data');
	       $user_id=$ses_data['Userid'];
	       $date_time=currentDateTime();
	       $plane_id = trim(strip_tags($this->input->post('txt_plan_id')));
	       
	       $subj_arr=array(
				   "reportbugs"=>"Report Bugs",
				   "enquiry"=>"Enquiry",
				   "reportabuse"=>"Report Abuse",
				   "others"=>"Others",
			      );
	       
	       if($plane_id>0)
	       {
		    $sbj_text = "";
		    $sbj_type = "advertisement";
	       }
	       else{
		    $subj = trim(strip_tags($this->input->post('subject')));
		    $sbj_text = $subj_arr[$subj]!=""?$subj_arr[$subj]:"others";
		    
		    $sbj_type = $subj;
	       }
	       
	       $insertArr=array(
		  "user_id"	=> $user_id,
		  "name"	=> trim(strip_tags($this->input->post('txt_name'))),
		  "phone"	=> trim(strip_tags($this->input->post('txt_phone'))),
		  "email"	=> trim(strip_tags($this->input->post('txt_email'))),
		  "message" 	=> trim(strip_tags($this->input->post('txt_message'))),
		  "plan_id" 	=> $plane_id,
		  "subject" 	=> $sbj_text,
		  "type"	=> $sbj_type,
		  "added_on"	=> $date_time
	     );
	     
	     $insertID = $this->webservice->add_contact($insertArr);
	     if($insertID)
	     {
		  $mail_send = $this->_send_email_contact($insertArr,'contactUsAdmin');
		  $r= new stdClass();
		  $r->error=0;
		  if($plane_id>0)
		  {
		    $r->message= "Admin will contact you shortly. Thank You!";
		  }
		  else{
		    $r->message= "Thank you! Your suggestions and queries are valuable to us."; 
		  }
		  $r->product_html=$product_html;
		  echo json_encode($r);
	     }
	     else
	     {
		  $r= new stdClass();
		  $r->error=1;
		  $r->message="Request not added successfully.";
		  echo json_encode($r);
	     }
	  }

     }
}
?>
