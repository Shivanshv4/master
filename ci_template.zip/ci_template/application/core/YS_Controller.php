<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class YS_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        /*
         *Temp Login
         *
         *Comment below codes to disable temp login
         */
        
        if(@$this->config->item('templogin')=="enable")
        {
            $temp_sess_data = $this->session->userdata("templogin");

            if($temp_sess_data['tempPass']!="singsys8goto9")
            {
               redirect(site_url('templogin'));
            }
        }
        /*End Temp Login*/
    }
}


?>