    <div class="wrapper">

        <!-- Dadhboard Header -->
    	<header class="dashboard-header">
        	<nav class="navbar navbar-default bg-yellow">
              <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
 <div class="navbar-header"> <a class="navbar-brand" href="<?php echo site_url() ?>">
 <!--<img src="<?php echo base_url().'lib/images/logo.png';?>" alt="<?php echo SITE_NAME;?>" title="<?php echo SITE_NAME;?>"/>-->
<div class="logo" style="padding:2px; font-size:22px;color:#fff"><?php echo SITE_NAME;?></div>
 </a> </div>

                <!-- Toggle Sidebar Button -->
                <button type="button" class="btn toggle-btn"><span class="fa fa-navicon"></span></button>

                <!-- Get App Button -->
                <a href="<?php echo site_url('login') ?>" class="btn btn-default join-now"><span data-content="Join Now">Join Now</span></a>

                <!-- Advertise Button -->
                <a href="<?php echo site_url('login') ?>" class="btn btn-default sign-in"><span data-content="Sign in">Sign in</span></a>

		<!-- Get App Button -->
	   <button type="button" class="btn btn-default get-app-btn getappbtn-wlogin">GET THE FREE APP!</button>
                <!-- Search Form -->
                <form class="navbar-form navbar-right" role="search">
                    <div class="form-group">
                      <input type="text" class="form-control" name="keyword" placeholder="Search">
                      <button type="submit" class="btn btn-default search-btn" aria-label="search">
                      <span class="glyphicon glyphicon-search color-yellow" aria-hidden="true"></span>
                    </div>
                  </button>
                </form>

              </div><!-- /.container-fluid -->
            </nav>
        </header>
        <!-- Dadhboard Header End -->
