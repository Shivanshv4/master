<div class="temp-login-wrapper">
        <section class="login">
            <div class="login-form">
            	<div class="logo">
		    <!--<img src="<?php echo base_url() ?>lib/images/logo.png" alt="" />-->
		    <div class="logo" style="padding:2px; font-size:22px;color:#fff"><?php echo SITE_NAME; ?></div>
		</div>
                <form class="form-horizontal" action="<?php echo base_url('templogin') ?>" method="POST">
                  <div class="form-group <?php echo ((form_error('password') !="") ? 'has-error' : ''); ?>">
                    <div class="col-sm-12">
                     <input type="password" class="form-control" name="password" id="inputPassword3" placeholder="Password">
			<?php echo form_error('password','<span class="error-msg ">','</span></br>')?>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-12">
                      <input type="submit" value="Login" class="btn btn-default btn-block">
                    </div>
                  </div>
                </form>
                <!-- Login Form End -->
            </div>

        </section>

    </div>

<style>
    /* Temp Login */

.temp-login-wrapper{
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background: #87CEEB;
	padding: 0 20px;
}
.temp-login-wrapper .login{ display: table;
width: 320px;
max-width: 100%;
height: 100%;
margin: 0 auto;
 }


.temp-login-wrapper .login-form{ display: table-cell; vertical-align: middle;}
.temp-login-wrapper .logo{ text-align: center; margin-bottom: 20px; }


/*  Styles  */
body{
    background: #fff;
    font-family: Roboto;
    font-size: 14px;
    font-weight: 400;
    margin: 0;
    padding: 0;
}
</style>

</body>
</html>
