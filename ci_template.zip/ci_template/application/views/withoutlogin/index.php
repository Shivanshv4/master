<!-- Dadhboard Banner -->
<section class="banner">

        <ul class="bxslider">
      <li>
        <img src="<?php echo base_url()?>lib/images/Banner-1.jpg" />
        <div class="bx-caption">
                <h2>Get your products listed.</h2>
                <h2>Reach to the crowd.</h2>
            <p>Download our free mobile app!</p>
            <div class="get-app-btns">
                <a href="javascript:void(0)" class="btn btn-default ios"></a>
                <a href="javascript:void(0)" class="btn btn-default android"></a>
            </div>
        </div>
      </li>
      <li>
        <img src="<?php echo base_url()?>lib/images/Banner-2.jpg" />
        <div class="bx-caption">
                <div class="banner-icon"><img src="<?php echo base_url()?>lib/images/shop-banner-logo.png" alt="" /></div>
                <h2>Our quality is remembered long after the price is forgotten.</h2>
            <div class="explore-btn">
                <a href="javascript:void(0)" class="btn btn-default">Explore</a>
            </div>
        </div>
      </li>
      <li>
        <img src="<?php echo base_url()?>lib/images/Banner-3.jpg" />
        <div class="bx-caption">
                <div class="banner-icon"><img src="<?php echo base_url()?>lib/images/banner-icon.png" alt="" /></div>
                <h2>Follow our shop and become a star among the crowd.</h2>
            <div class="explore-btn">
                <a href="javascript:void(0)" class="btn btn-default">Explore</a>
            </div>
        </div>
      </li>
    </ul>

</section>
<!-- Dadhboard Banner -->
<section class="categories">
    <!--div class="category-heading"><h3>Categories</h3></div-->
    <ul>
	<?php
	if(count($categories)) {
		echo '<li '.($catId ? '' : 'class="active"').'><a href="#">All Categories</a></li>';
		foreach($categories as $category) {
			//print_r($category);
			echo '<li '.($catId == $category['id_category'] ? 'class="active"' : '' ).'><a href="'.base_url().'product_list/'.base64_encode($category['id_category']).'" title="'.$category['category_name'].'">'.$category['category_name'].'</a></li>';
		}
	} else {
		echo '<li class="color-red">No record found.</li>';
	}
	?>
    </ul>
</section>
<!-- Dadhboard Left Section End -->

<!-- Dadhboard Right Section -->
        <section class="dashboard-right shop-products-list">

            <!-- Notifications For Mobile -->
        	<div class="notifications">
            	<ul class="text-center">
                	<li><a href="#"><span class="glyphicon glyphicon-cog color-white"></span></a></li>
                	<li><a href="#"><span class="glyphicon glyphicon-bell color-white"></span><span class="notification-count">4</span></a></li>
                	<li><a href="#"><span class="glyphicon glyphicon-envelope color-white"></span></a></li>
                </ul>
            </div>

            <div class="row">

                <!-- Product Panel -->
                <div class="col-md-12 col-sm-12 col-xs-12 product-panel">

                    
                    
		
		</div>

            </div>

        </section>
        <!-- Dadhboard Right Section End -->
