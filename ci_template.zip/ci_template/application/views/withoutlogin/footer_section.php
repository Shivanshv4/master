  <!-- Footer -->
  <footer class="footer home-footer">
    <div class="bottom-nav">
      <ul>
        <li><a href="<?php echo site_url('about') ?>" title="About Us">About Us</a></li>
        <li><a href="<?php echo site_url('privacy') ?>" title="Privacy Policy">Privacy Policy</a></li>
        <li><a href="<?php echo site_url('termsconditions') ?>" title="Terms & Conditions">Terms & Conditions</a></li>
        <li><a href="<?php echo site_url('help') ?>" title="Terms & Conditions">Help</a></li>
        <li><a href="<?php echo site_url('faq') ?>" title="Terms & Conditions">FAQ</a></li>
        <li><a href="<?php echo site_url('guidelines') ?>" title="Terms & Conditions">Community Guidelines</a></li>
      </ul>
    </div>
    <div class="social-icons">
      <ul class="text-center">
        <li><a href=""><span class="fa fa-linkedin"></span></a></li>
        <li><a href="#"><span class="fa fa-facebook"></span></a></li>
        <li><a href="#"><span class="fa fa-instagram"></span></a></li>
        <li><a href="#"><span class="fa fa-pinterest-p"></span></a></li>
      </ul>
    </div>
  </footer>
</div>
<!--Close wrapper outer-page-->
