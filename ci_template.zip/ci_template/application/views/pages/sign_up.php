<style>
  .error-msg{ color: black !important; }
  .sug { color: green !important; }
</style>
<div class="login-wrapper">

  <section class="section-right col-sm-12">
    <a href="<?php echo base_url('login'); ?>" class="go-back"></a>
    <div class="signup-form col-md-12 col-sm-6 col-md-offset-0 col-sm-offset-3">
      <h1 class="text-center color-white bottom_30">SIGN UP NEW ACCOUNT</h1>
      <span class="form-horizontal">
	
	<?php echo form_open_multipart('signup/','id="sign_up_id"');?></span>
       <div class="success_msg"><?php echo $success; ?></div>

	<div class="form-group">
        <div class="col-sm-12">
			<input maxlength="20" type="text" name="name" class="form-control" id="name" placeholder="UserName" value = "<?php echo $name ?>">
			<?php echo form_error('name', '<span class="error-msg">', '</span>');?>
		</div>
    </div>

    <div class="form-group">
        <div class="col-sm-12">
			<input type="text" name="email" class="form-control" id="email" placeholder="Email" value = "<?php echo $email ?>">
			<?php echo form_error('email', '<span class="error-msg">', '</span>');?>
        </div>
	</div>
	
    <div class="form-group">
         <div class="col-sm-12"><input type="password" name="password" class="form-control" id="pwd" placeholder="Password">
			<?php echo form_error('password', '<span class="error-msg">', '</span>');?>
		</div>
    </div>
		
	<div class="form-group">
        <div class="col-sm-12"><input type="password" name="confirm_password" class="form-control" id="cpwd" placeholder="Confirm Password">
			<?php echo form_error('confirm_password', '<span class="error-msg">', '</span>');?>
		</div>
    </div>
	
	<div class="form-group">
		<div class="col-sm-12">
			<div class="">
				<input type= "file" name="image" id="image" value="">
				<?php echo form_error('image', '<br><span class="error-msg">', '</span>');?>
			</div>
		</div>
	</div>

        <div class="form-group">
          <div class="col-sm-12"><input type="button" onclick="signUp()" value="Sign up" class="btn btn-default btn-block"></div>
        </div>
	
	  <?php form_close();?>
    </div>
  </section>
</div>
<script type="text/javascript">
	function signUp(){
		//var image_name = $('#image').attr('value');
		var filename = $('input[type=file]').val().split('\\').pop() ? $('input[type=file]').val().split('\\').pop() : '' ;
		$.ajax({
          'url': 'ajax-signup?image='+filename,
          'type' : 'POST',
          'data' : $('#sign_up_id').serialize(),
          success : function(output){
          	var result = JSON.parse(output);
          	//alert(result.error.name);
          	if(result.response == 'failure'){
          		$('#name').parent().children().remove('span');
	          	$('#email').parent().children().remove('span');
	          	$('#pwd').parent().children().remove('span');
	          	$('#cpwd').parent().children().remove('span');
	          	$('#image').siblings().remove();
	          	$('#image').parent().children().remove('br');
	          	$('#image').parent().children().remove('span');

	          	$('.success_msg').html('');
	          	

	          	$('#name').parent().append('<span class="error-msg">'+result.error.name+'</span>');
	          	$('#email').parent().append('<span class="error-msg">'+result.error.email+'</span>');
	          	$('#pwd').parent().append('<span class="error-msg">'+result.error.password+'</span>');
	          	$('#cpwd').parent().append('<span class="error-msg">'+result.error.confirm_password+'</span>');
	          	$('#image').parent().append('<br><span class="error-msg">'+result.error.image+'</span>');
          	} else {
          		$('#name').parent().children().remove('span');
	          	$('#email').parent().children().remove('span');
	          	$('#pwd').parent().children().remove('span');
	          	$('#cpwd').parent().children().remove('span');
	          	$('#image').siblings().remove();
	          	$('#image').parent().children().remove('br');
	          	$('#image').parent().children().remove('span');

	          	//$('#name').attr('value','');
	          	$('.success_msg').html(result.data.success);

          	}
          }
        });
	}
</script>