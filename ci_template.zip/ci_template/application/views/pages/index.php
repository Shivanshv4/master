<style>
  span.remove_error { vertical-align:-webkit-baseline-middle; }
</style>
<div class="login-wrapper">
  <section class="section-left  col-sm-12">
    
  </section>
  <section class="section-right  col-sm-12">
    <div class="login-form col-md-12 col-sm-6 col-md-offset-0 col-sm-offset-3">
      <h1 class="text-center color-white bottom_30">SIGN UP OR LOG-IN AS</h1>
      <input type="hidden" name="verify" />
      <?php echo form_error('verify', '<span class="remove_error">', '</span>');
      ?>
      <span class="remove_error"><?php
	echo @$verify;
      ?>
      <?php echo $this->session->flashdata('flash_msg'); ?>
      </span>
        <?php echo form_open(); ?>
	<input type="hidden" name="backurl" value="<?php echo $backurl;?>">
	  <div class="form-horizontal">
	    <div class="form-group">
	      <div class="col-sm-12"><input type="text" name="loginemail" class="form-control" value="<?php echo stripcslashes(trim($user_data['email'])); ?>" id="inputEmail3" placeholder="Email">
		<?php echo form_error('loginemail', '<span class="remove_error">', '</span>');?>
	      </div>
	    </div>
	    <div class="form-group">
	      <div class="col-sm-12"><input type="password" name="loginpassword" class="form-control" id="inputPassword3" placeholder="Password" value="<?php echo stripcslashes(trim($user_data['password'])); ?>">
		<?php echo form_error('loginpassword', '<span class="remove_error">', '</span>');?>
	      </div>
	    </div>
	    
	    <div class="form-group">
	      <div class="col-sm-12"><input type="submit" value="Login" class="btn btn-default btn-block"></div>
	    </div> 
		
		 <div class="form-group">
	
		<a  class="col-sm-12" href ="/ci_template">back to sign up </a>
		</div>
			
	  </div>
        <?php form_close(); ?>
      </section>
    </div>
