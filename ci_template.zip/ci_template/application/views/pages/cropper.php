
	
<link rel="stylesheet" href="<?php echo base_url()?>lib/cropper/assets/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>lib/cropper//assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>lib/cropper//dist/cropper.css">
<link rel="stylesheet" href="<?php echo base_url()?>lib/cropper/demo/css/main.css">

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body>
  <!--[if lt IE 8]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->
  <?php
 
 $image_name = @$this->uri->segment(3);
 
 $image_url = base_url().'uploads/temp/postimages/'.$image_name;
 
 $number = @$this->uri->segment(4);
 
  ?>
  
<div class="img-container1 img_cropper_container" id="img_cropper_container" style="">
	<img id="cropper_image" style="max-height:300px;" src="<?php echo $image_url;?>" alt="Picture">
	<img id="cropper_loader_image"  src="<?php echo base_url();?>lib/images/bx_loader.gif" alt="Picture">  
</div>


 <input type="hidden" id="dataX" />
 <input type="hidden" id="dataY" />
<input type="hidden" id="dataHeight" />
<input type="hidden" id="dataWidth" />
        <input type="hidden" id="number" value="<?php echo $number;?>" />
<input type="hidden" id="imgUrl" value="<?php echo $image_url;?>" />
       
       <a class="btn btn-primary" id="download" href="javascript:void(0);" download="cropped.png" style="display:none">Download</a>
       <div class="form-group row pull-right">
       <input type="button" value="Save" id="submitBtn_crop" style="display:none"  class="btn btn-default ">
       </div>
       
  <script src="<?php echo base_url()?>lib/cropper/assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url()?>lib/cropper/assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>lib/cropper/dist/cropper.js"></script>

  <style>
    #submitBtn_crop{
      background: #000 none repeat scroll 0 0;
    border: 0 none;
    border-radius: 0;
    color: #fff;
    font-weight: 400;
    padding: 7px 31px 7px 16px;
    text-align: center;
    text-transform: uppercase;
    margin-top:10px;
    }
    #cropper_image{
	display:none;
    }
    .img_cropper_container{
	text-align:center;
	min-height:300px;
    }
  </style>
  <script src="<?php echo base_url()?>lib/cropper/demo/js/cropper_image.js"></script>

  <script>
  $(document).ready(function(){
    
     $('#submitBtn_crop').click(function(event){
       
       var dataHeight = $("#dataHeight").val();
       var dataWidth = $("#dataWidth").val();
       var dataX = $("#dataX").val();
       var dataY = $("#dataY").val();
       
       var imgUrl = $("#imgUrl").val();
       
	   $.ajax({
	   method: "POST",
	   url: "<?php echo base_url(); ?>pages/temp_image_crop/postimages",
	   data: { imgH: dataHeight,imgW:dataWidth,imgX1:dataX,imgY1:dataY,imgUrl:imgUrl}
	   })
	   .done(function(data) {
	   //console.log(data);
	   
	   var obj= $.parseJSON(data); 
	   console.log(obj);
	   
	 
	   if(obj.status=="success") {
	      parent.setValue(obj.profile_image);
	      parent.setImageUrlValue(obj.url);
	      
	   }
	  
	   })
	   .fail(function() {
	   //alert( "error" );
	   })
	   .always(function() {
	   //alert( "complete" );
	   });
       
      
      });
    
    }); 
	       function cropImage(){
		  
		  alert("cropp image");
		  
		  
	       }
  </script>
 
  

