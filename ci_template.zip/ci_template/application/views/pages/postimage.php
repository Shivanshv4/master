<div class="wrapper">
  
   <section class="dashboard-right my-shop">
	
      <h3 class="page-title">Post Image</h3>
      <div class="row">
	<!-- POST REQUEST-->
	   <div class="col-md-9 col-sm-12 col-xs-12 product-panel shop-products-list">
		<div class="panel panel-default">
		   <div class="panel-body">
			<div class="col-md-12 edit-profile-form">
			   <div class="col-md-8 col-sm-12">
				<form class="form-horizontal" action="<?php echo base_url(); ?>pages/postimage" method="post" id="f_post_request" enctype="multipart/form-data">
				   
				   
				   <div class="form-group">
					<label for="request_image" class="control-label col-md-3 col-sm-4 col-xs-12">Image</label>
					<div class="col-md-9 col-sm-8 col-xs-12">

                                        <div class="upload_product_img">
                                            <ul>
                                                   <li>
                                                       <div class="profile-image" data-width="440" data-height="440"  id="user_profile_image"></div>
                                                      
                                                       <div onclick="uploadProductImage(1);" class="cropControls cropControlsUpload">
                                                               <i title="Select Image" class="cropControlUpload"></i>
                                                       </div>
                                                   </li>
                                                   <input type="hidden" name="txtproduct_image[]" id="txtproduct_image1" value="<?php echo $userData['image_name_hidden'] ?>">
                                                   <a href="#myModalImage" id="model_image" style="display:none" class="btn btn-default" data-toggle="modal" data-target="#myModalImage">Post New Image</a>
                                                                        <input type="file" name="img" style="display:none" id="img" onchange="imageupload();" />
                                            </ul>
                                            <span  id="error_image"></span>
                                        </div>
					   <span id="error_request_image"></span>
					</div>
				   </div>
				   
				</form>
			   </div>
		      </div>
		   </div>
		</div>
	   </div>		
         <!-- Message Panel -->
<?php  //$this->load->view('pages/dashboard_message.php');?>

<div class="modal fade" id="myModalImage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog modal-sm" style="width: 630px;">
      <div class="modal-content">
	 <div class="modal-header">
	    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	    <h4 class="modal-title">Crop Image</h4>
	 </div>
	 <div class="modal-body edit-profile-form">
	    <div class="row">
	       <div class="form-group1 row1">
		  <div  class="text-center" id="result_message"></div>
	       </div>
	       <iframe id="cropper_iframe" src="<?php echo base_url();?>pages/cropper" style="width:100%;height:360px;" frameborder="0" allowtransparency="true"></iframe>
	       <div class="form-group1">
		  <div id="result_image_data"> </div>
		  <input type="hidden" id="new_thumb_image" ?>
		  <input type="hidden" id="product_number" value="1" /> 
	       </div>
	    
	    </div>
	 </div>
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

</section>
   
<script>
 function uploadProductImage(id)
 {
   $("#img").click();
}
function setValue(val){
   var value = val; 
  
}

function setImageUrlValue(val){
   var value = val;
   
   $('#user_profile_image').html("<img src='"+value+"'/>");
   
   $("#myModalImage .close").click();
}
 function beforeSubmit(data) {
            //code
        }
function imageupload()
{

  if(check_image_size())
  {
  var action='<?php echo base_url()?>pages/temp_image_save/postimages';
        
   $("#f_post_request").attr('action',action);
	   
	    
 //////////////////////////////
   var options = { 
	     beforeSubmit: beforeSubmit,  // pre-submit callback 
	     success: function(data){
	       
	       var obj=jQuery.parseJSON(data);
	       //console.log(obj);
	        if (obj.status=="success") {
	       //$("#result_image_data").html(data);
	       
	       var number = $("#product_number").val();
	       
	       var url = "<?php echo base_url();?>pages/cropper/"+ obj.image+"/"+number;
	       
	       $("#cropper_iframe").attr("src",url);
	       //$('#cropper_image').attr('src', obj.url).show();
	       
	       //$('#myModalImage').show();
	       $("#model_image").click();
	        }
	       else{
		  bootbox.dialog({
		  message: obj.message,
		  title: "Warning",
		  buttons: {
		      main: {
		      label: "Ok",
		      className: "btn-primary"
		      }
		  },
		  className: 'bootbox-warning'
		  });
	       }
	       
	       },  // post-submit callback
	     //beforeSerialize:beforeSerialize,
	     // dataType: 'json',
	     //resetForm: true        // reset the form after successful submit 
     };
    $("#f_post_request").ajaxSubmit(options);
  }
  else{
   //alert("Upload valid image");
  }
}

function check_image_size() { 
    var id="img"; // image
    var t=$('#image_data').val();
         var fileUpload = $("#"+id)[0];
         
           var fuData = fileUpload;
                var FileUploadPath = fuData.value;
				
				if (window.File && window.FileReader && window.FileList && window.Blob)
				  {
				      //get the file size and file type from file input field
				      var fsize = $("#"+id)[0].files[0].size;
				      //alert(fsize);
				      if(fsize>2097152) //do something if file size more than 1 mb (1048576)
				      {
					  $("#"+id).focus();
                                            alert("Please upload file size less than 2 mb.");
                                           
                                                $("#"+id).val('');
                                           return false;
					  
				      }
				      else{
					//return true;
				      }
				  }
				  else{
				    alert("Not supported");
				  }
                                var Extension = FileUploadPath.substring(FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
                                 if (Extension == "png" 
                                || Extension == "jpeg" || Extension == "jpg") {
                                            return true
                                        } 
                            //The file upload is NOT an image
                            else {
                                            $("#"+id).focus();
                                            alert("Please upload jpg,jpeg and png image only. ");
                                           
                                                $("#"+id).val('');
                                           return false;
                            
                                }
                                //Check whether HTML5 is supported.
                                if (typeof (fileUpload.files) != "undefined") {
                                    //Initiate the FileReader object.
                                    var reader = new FileReader();
                                    //Read the contents of Image File.
                                    reader.readAsDataURL(fileUpload.files[0]);
                                    reader.onload = function (e) {
                                        //Initiate the JavaScript Image object.
                                        var image = new Image();
                                        //Set the Base64 string return from FileReader as source.
                                        image.src = e.target.result;
                                        image.onload = function () {
                                            //Determine the Height and Width.
                                            var height = this.height;
                                            var width = this.width;
                                           // alert(width +' -- '+ height);
                                            if (width < 640 || height < 460) {
                                              //  alert("Please upload at least 640x460 px size image.");
                                                 $("#"+id).val('');
                                            }
                                            else{
                                              
                                            }
                                            
                                        };
                                    }
                                } else {
                                    alert("This browser does not support HTML5.");
                                    return false;
                                }
    }
</script>   
