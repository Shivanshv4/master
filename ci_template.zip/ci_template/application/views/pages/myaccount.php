
<div class="wrapper">
<!-- Dadhboard Header -->
<header class="dashboard-header">
   <nav class="navbar navbar-default bg-yellow">
	<div class="container-fluid">
	   <!-- Brand and toggle get grouped for better mobile display -->
	   <div class="navbar-header" >
	    		<a class="navbar-brand" style="padding:15px;" href="<?php echo base_url();?>/dashboard">
		  <div class="logo" style="padding:2px; font-size:22px;color:#fff">Yishon</div>
		</a>
	   </div>
	   <!-- Toggle Sidebar Button -->
	   <button type="button" class="btn toggle-btn"><span class="fa fa-navicon"></span></button>
	   <!-- Advertise Button -->

	  
	  
	</div><!-- /.container-fluid -->
   </nav>
</header>
<!-- Dadhboard Header End -->
<!-- Dadhboard Left Section -->
<section class="dashboard-left bg-dark-grey">
   
   <div class="side-nav">
		<ul>
	 	    <li class='active' >
				<a href="#" class="color-white my-profile" title="My Profile">My Profile</a>
			</li>
			<li>
			<br><br><input type = "text" name = "keyword" placeholder = "twitter keyword">
			</li>
			<div class="search">
			<li>
			<br>&nbsp &nbsp <input type = "button" name = "twitter" value = "search">
			</li>
			</div>
	    </ul>

	<div class="logout">
	   <a href="<?php echo base_url();?>logout" class="btn btn-default log-out-btn">LOGOUT</a>
	</div>
   </div>
   
</section>
<!-- Dadhboard Left Section End -->
 
    <h3 class="page-title">My Profile</h3>
   

     
</div>


