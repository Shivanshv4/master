<script src='https://www.google.com/recaptcha/api.js'></script>
<div class="wrapper">
    	
	<?php $this->load->view('templates/header_dashbaord');	?>
      
        <?php  $this->load->view('pages/dashboard_left.php');	?>
       
        
        <!-- Dadhboard Right Section -->
        <section class="dashboard-right my-shop">
        	
            <!-- Notifications For Mobile -->
        	<?php $this->load->view('pages/dashboard_notification_mobile.php');	?>
        	
        	<h3 class="page-title"><?php echo $title ?></h3>
            
            <div class="row">
            	
                
		<!-- Contact Us-->
		<div class="col-md-9 col-sm-12 col-xs-12 product-panel shop-products-list">
		  <div class="panel panel-default">
		    <div class="panel-body">
		      <div class="col-md-12 edit-profile-form">
			<div class="col-md-6 col-sm-12">
			  <form class="form-horizontal">

				<div id="result_message"></div>

			<?php
			//print_r($ses_data);
			$placeHolder = 'Enquiry';
			if(count($plan_data)) {
				$placeHolder = $plan_data['adv_name'].' $'.$plan_data['adv_price'].' Name of Product for Advertisment ';
				
				if($plan_data['type']=="showproduct")
				{
					$placeHolder ="What product do you want us to help you advertise?";
				}
				if($plan_data['type']=="showprofile")
				{
					$placeHolder ="Show Your Profile Once At Everyone's Newsfeed";
				}
				?>
				<h3 class="advrt-heading"><?php echo $plan_data['adv_name'] ?></h3>
				  <p><?php echo $plan_data['adv_description'] ?></p>
			<?php }?>

			    <div class="form-group">
			      <label for="name" class="control-label col-md-3 col-sm-4 col-xs-12">Name</label>
			      <div class="col-md-9 col-sm-8 col-xs-12">
				<input type="text" class="form-control" maxlength="30" id="name" <?php  if(!empty($ses_data['name'])){?>readonly="readonly" <?php } ?> value="<?php echo $ses_data['name'] ?>" name="name" placeholder="Name">
				<span class="error-msg" id="error_name"></span> </div>
			    </div>
			    <div class="form-group">
			      <label for="email" class="control-label col-md-3 col-sm-4 col-xs-12">Email</label>
			      <div class="col-md-9 col-sm-8 col-xs-12">
				<input type="email" class="form-control" readonly="readonly" value="<?php echo $ses_data['email'] ?>" id="email" name="email" placeholder="Email">
				<span class="error-msg" id="error_email"></span> </div>
			    </div>
			    <div class="form-group" style="white-space:nowrap">
			      <label for="phone" class="control-label col-md-3 col-sm-4 col-xs-12">Contact No</label>
			      <div class="col-md-9 col-sm-8 col-xs-12">
				<input type="text" class="form-control" id="phone" maxlength="15" name="phone" placeholder="+01-23456789">
				<span class="error-msg" id="error_phone"></span> </div>
			    </div>
				<?php if(!count($plan_data)) { ?>
				<div class="form-group">
			      <label for="email" class="control-label col-md-3 col-sm-4 col-xs-12">Subject</label>
			      <div class="col-md-9 col-sm-8 col-xs-12">
					<span class="custom-dropdown">
						<select name="subject" id="subject">
							<option value="">Select Subject</option>
							<option value="reportbugs">Report Bugs</option>
							<option value="enquiry">Enquiry</option>
							<option value="reportabuse">Report Abuse</option>
							<option value="others">Others</option>
						</select>
					</span>
					<span class="error-msg" id="error_subject"></span>
			      </div>
			    </div>
				<?php } else {
					echo '<input type="hidden"  id="subject" readonly="readonly" value="" name="subject">';
				}?>

			    <div class="form-group">
			      <label for="message" class="control-label col-md-3 col-sm-4 col-xs-12">Enquiry</label>
			      <div class="col-md-9 col-sm-8 col-xs-12">
				<textarea class="form-control" id="message" name="message" placeholder="<?php echo $placeHolder ?>"></textarea>
				<span class="error-msg" id="error_message"></span> </div>
			    </div>
			    
			     <div class="form-group">
				
				<div class="col-md-12 col-sm-12 col-xs-12  pull-right text-right">
					<div class="g-recaptcha" data-sitekey="<?php echo $this->config->item('captcha_site_key');?>"></div>
					<span class="error-msg" id="error_captcha"></span>
				</div>
			     </div>
			    
			    <div class="form-group">
			      <label for="" class="control-label col-md-3 col-sm-4 col-xs-12"></label>
			      <div class="col-md-9 col-sm-8 col-xs-12">
				<!--<input type="submit" value="Submit" class="btn btn-default">-->
				<input type="button" value="Submit" class="btn btn-default" onClick="postNewRequest();">
				<?php if(count($plan_data)) { ?>
				<a class="btn btn-default cancel-btn" href="<?php echo base_url('advertise'); ?>">Cancel</a>
				<?php } ?>
				<input type="hidden" name="plan_id" id="plan_id" value="<?php echo ($planId)?$planId:0; ?>">
			      </div>
			    </div>
			  </form>
			</div>
			<div class="col-md-6 col-sm-12">
			 <?php if($latitude && $longitude) { ?>
			  <div class="image-map" id="google_map" style="width: 100%; height: 267px"></div>
			  <?php } ?>
			  <div class="map_detail">
			    <ul>
				<?php if(trim(strip_tags($address))) {
					echo '<li><span>Address : </span><span class="address">'.nl2br($address).'</span></li>';
				}
				if(trim(strip_tags($contact_no))) {
					echo '<li><span>Contact No  : </span><span class="address">'.$contact_no.'</span> </li>';
				}
				if(trim(strip_tags($address))) {
					echo '<li><span>Email : </span><span class="address"><a class="color-black" href="mailto:'.$admin_email.'">'.$admin_email.'</a></span> </li>';
				}
				?>



			    </ul>
			  </div>
			</div>
		      </div>
		    </div>
		  </div>
		</div>
		<!-- Contact Us-->
                
		
                <!-- Message Panel -->
		
		 <?php  $this->load->view('pages/dashboard_message.php');	?>
		
            
            
        </section>
        <!-- Dadhboard Right Section End -->
<script src="http://maps.googleapis.com/maps/api/js"></script>
<script type="text/javascript">
function validateEmail(email) {
  // http://stackoverflow.com/a/46181/11236

    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function phonenumber(inputtxt)
{
  var phoneno = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4,5})[-. ]?([0-9]{4,5})$/;
  if((inputtxt.match(phoneno)))
  {
	return true;
   } else {
        return false;
   }
}

function postNewRequest()
{
   $("#result_message").show();
   var error=0;
   $("#result_message").html("");
   $("#error_name").html("");
   $("#error_email").html("");
   $("#error_phone").html("");
   $("#error_message").html("");
   $("#error_subject").html("");
   $("#error_captcha").html("");

   $("#error_name").show("");
   $("#error_email").show("");
   $("#error_phone").show("");
   $("#error_message").show("");
   $("#error_captcha").show("");

   var name=$.trim($("#name").val());
   var email=$.trim($("#email").val());
   var phone=$.trim($("#phone").val());
   var message=$.trim($("#message").val());
   var plan_id=$.trim($("#plan_id").val());
   var subject=$.trim($("#subject").val());



   if (name=="") {
	$("#error_name").html('Please enter name.');
	$("#name").focus();
	error++;
   }
   if (email =="") {
	$("#error_email").html('Please enter email.');
	$("#email").focus();
	error++
   } else if (!validateEmail(email)) {
	$("#error_email").html('Please enter valid email.');
	$("#email").focus();
	error++;
   }
   if (phone=="") {
	$("#error_phone").html('Please enter phone.');
	$("#phone").focus();
	error++;
   } else if (!phonenumber(phone)) {
	$("#error_phone").html('Please enter valid phone.');
	$("#phone").focus();
	error++;
   }
   <?php if(!count($plan_data)) { ?>
   if (subject=="") {
	$("#error_subject").html('Please select subject.');
	$("#subject").focus();
	error++;
   }
   <?php } ?>
   if (message=="") {
	$("#error_message").html('Please enter enquiry.');
	$("#message").focus();
	error++;
   }
   
   ////// recaptcha check
    var widgetId1;
    var onloadCallback = function() {
        // Renders the HTML element with id 'example1' as a reCAPTCHA widget.
        // The id of the reCAPTCHA widget is assigned to 'widgetId1'.
        widgetId1 = grecaptcha.render('example1', {
          'sitekey' : '<?php echo $this->config->item('captcha_site_key');?>',
          'theme' : 'light'
        });
      
      };
    
      var resp=grecaptcha.getResponse(widgetId1);
      if (resp=="") {
      
         //alert('Please enter valid captcha');
      
	 $("#error_captcha").html('Please enter valid captcha.');
	$("#error_captcha").focus();
	error++;
      }
   
	
   if (error==0)
   {
	$("#result_message").html("Please wait...");
	$.ajax({
	  method: "POST",
	  url: "<?php echo base_url(); ?>dashboard/post_contact",
	  data: {txt_name: name,txt_email:email, txt_phone: phone,txt_message:message, txt_plan_id:plan_id, subject: subject }
	  })
	.done(function(data) {
	  var obj= $.parseJSON(data);
	  if (obj.error==0)
	  {
		$("#error_name").html("");
		$("#error_email").html("");
		$("#error_phone").html("");
		$("#error_message").html("");
		$("#error_subject").html("");
		//$("#name").val("");
		$("#subject").val("");
		$("#phone").val("");
		$("#message").val("");

		$("#result_message").html('<span class="success remove_error">'+ obj.message +'</span>').delay(12000).fadeOut('slow');
	   }
	   else{
		$("#result_message").html('<span class="error-msg remove_error">'+obj.message+ '</span>').delay(12000).fadeOut('slow');
	   }
	})
	.fail(function() {
	  //alert( "error" );
	})
	.always(function() {
		grecaptcha.reset(widgetId1);
	  //alert( "complete" );
	});
   }

}






// title: 'Hello World!'
<?php if($latitude && $longitude) { ?>
geocoder = new google.maps.Geocoder();
var latlng = new google.maps.LatLng('<?php echo $latitude ?>', '<?php echo $longitude ?>');

var mapOptions = {
	zoom: 15, //Change the Zoom level to suit your needs
	center: latlng,
	mapTypeId: google.maps.MapTypeId.ROADMAP
}
//map_canvas is just a <div> on the page with the id="map_canvas"
map = new google.maps.Map(document.getElementById('google_map'), mapOptions);
var marker = new google.maps.Marker({
	position: {lat: <?php echo $latitude ?>, lng: <?php echo $longitude ?>},
	map: map
});
<?php } ?>
</script>
