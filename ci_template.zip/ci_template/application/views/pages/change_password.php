<style>
  .sug{color: green;}
</style>
<div class="">
<!--<div class="wrapper">-->
  <section class="section-left col-md-8 col-sm-12">
    <div class="hero-img">
      <span><img src="<?php echo base_url()?>lib/images/hero_img.png" class="img-responsive" alt=""></span>
      <a href="javascript:void(0)" class="app-btn">Get the free App!</a>
    </div>
  </section>
  <section class="section-right col-md-4 col-sm-12">
    <a href="<?php echo base_url(); ?>" class="go-back"></a>
    <div class="forgot-pswrd-form col-md-12 col-sm-6 col-md-offset-0 col-sm-offset-3">
      <h1 class="text-center color-white bottom_30">CHANGE PASSWORD</h1>
      <span class="remove_error_1 sug"><?php echo $success_msg; ?> </span>
      <?php
      if($success_msg == '')
      {
	echo form_open(); ?>
	<div  class="form-horizontal">
	  <div class="form-group">
	    <div class="col-sm-12">
	      <input type="password" name="new_password" class="form-control" id="new_password" placeholder="Password" value="<?php echo $password; ?>">
	      <?php echo form_error('new_password','<span class="remove_error">','</span>'); ?>
	    </div>
	  </div>
	  <div class="form-group">
	    <div class="col-sm-12">
	      <input type="password" name="re_password" class="form-control" id="re_password" placeholder="Confirm Password" value="<?php echo $repassword; ?>">
	      <?php echo form_error('re_password','<span class="remove_error">','</span>'); ?>
	    </div>
	  </div>
	  <div class="form-group">
	    <div class="col-sm-12"><input type="submit" name="Submit" value="Submit" class="btn btn-default btn-block"></div>
	  </div>
	  </div>
<?php }
      form_close(); ?>
    </div>
    <div class="bottom_nav">
      <ul class="text-center">
       <li><a href="<?php echo site_url('about') ?>" class="color-white" title="About Us" >About Us</a></li>
        <li><a href="<?php echo site_url('privacy') ?>" class="color-white" title="Privacy Policy">Privacy Policy</a></li>
        <li><a href="<?php echo site_url('termsconditions') ?>" class="color-white" title="Terms & Conditions">Terms & Conditions</a></li>
      </ul>
    </div>
  </section>
</div>
