
<div class="wrapper">
    	
	<?php $this->load->view('templates/header_dashbaord');	?>
      
        <?php  $this->load->view('pages/dashboard_left.php');	?>
       
        
        <!-- Dadhboard Right Section -->
        <section class="dashboard-right my-shop">

            <!-- Notifications For Mobile -->
        	<?php $this->load->view('pages/dashboard_notification_mobile.php');	?>
        	
        	<h3 class="page-title"><?php echo $pagedate['content_title']; ?></h3>
            
            <div class="row">
            	
                <!-- Ststic Page Panel -->
               <div class="col-md-9 col-sm-12 col-xs-12 product-panel shop-products-list">
		<div class="panel panel-default">
		  <div class="panel-body">
		    <div class=" edit-profile-form">
		      <div class="col-md-12 col-sm-12">
			<div class="about-us">
			  <?php echo $pagedate['content']; ?>
			  
			</div>
		      </div>
		    </div>
		  </div>
		</div>
	      </div>
                
		<!-- Ststic Page Panel -->
                <!-- Message Panel -->
		
		 <?php  $this->load->view('pages/dashboard_message.php');	?>
		
            
            
        </section>
        <!-- Dadhboard Right Section End -->
	
	
	

