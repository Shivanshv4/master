<!-- Page Heading -->
<div class="row">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                       <h3 class="panel-title">Reset Password</h3>
                    </div>
                    
                    <?php if($this->session->flashdata('flash_msg') !=""):?>
                    
                        <?php echo $this->session->flashdata('flash_msg'); ?>
                       
                    <?php endif;?>
                    <div class="panel-body">
                        <?php echo form_open('admin/reset_password/'.$this->uri->segment(3));?>
                            <fieldset>
                                <div class="form-group <?php echo ((form_error('password') !="") ? 'has-error' : ''); ?>">
                                   <input class="form-control" placeholder="Password" name="password" type="password" value="<?php echo $this->session->flashdata('message') =="" ? $_REQUEST['password']:''; ?>" autofocus>
                                    <?php echo form_error('password', '<span class="error-msg">', '</span>');?>
                                </div>
                                <div class="form-group <?php echo ((form_error('c_password') !="") ? 'has-error' : ''); ?>">
                                   <input class="form-control" placeholder="Confirm Password" name="c_password" type="password" value="<?php echo $this->session->flashdata('message') =="" ? $_REQUEST['c_password']:''; ?>">
                                    <?php echo form_error('c_password', '<span class="error-msg">', '</span>');?>
                                </div>
                               <button type="submit" class="btn btn-lg btn-success btn-block">Reset Password</button>
                            </fieldset>
                        <?php echo form_close();?>
                        <div class="span12"><a href="<?php echo site_url('admin');?>">Login</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->