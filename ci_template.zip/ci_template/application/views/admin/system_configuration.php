<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($config_details))
{
   $admin_email      	=(isset($config_details['admin_email']) && $config_details['admin_email'] !="") ? $config_details['admin_email']:"";
   $signup_email 		=(isset($config_details['signup_email']) && $config_details['signup_email'] !="") ? $config_details['signup_email']:"";
   $smtp_port_number    =(isset($config_details['smtp_port_number']) && $config_details['smtp_port_number'] !="") ? $config_details['smtp_port_number']:"";
   $smtp_server_host  	=(isset($config_details['smtp_server_host']) && $config_details['smtp_server_host'] !="") ? $config_details['smtp_server_host']:"";
   $smtp_uName  		=(isset($config_details['smtp_uName']) && $config_details['smtp_uName'] !="") ? $config_details['smtp_uName']:"";
   $smtp_uPass		=(isset($config_details['smtp_uPass']) && $config_details['smtp_uPass'] !="") ? $config_details['smtp_uPass']:"";

   $address			=(isset($config_details['address']) && $config_details['address'] !="") ? $config_details['address']:"";
   $latitude		=(isset($config_details['latitude']) && $config_details['latitude'] !="") ? $config_details['latitude']:"";
   $longitude		=(isset($config_details['longitude']) && $config_details['longitude'] !="") ? $config_details['longitude']:"";
   $contact_no		=(isset($config_details['contact_no']) && $config_details['contact_no'] !="") ? $config_details['contact_no']:"";

   $date_format		=(isset($config_details['date_format']) && $config_details['date_format'] !="") ? $config_details['date_format']: "F j, Y";
   $time_format		=(isset($config_details['time_format']) && $config_details['time_format'] !="") ? $config_details['time_format']: "h:i a";

   $facebook_url		=(isset($config_details['facebook_url']) && $config_details['facebook_url'] !="") ? $config_details['facebook_url']: "";
   $linkedin_url		=(isset($config_details['linkedin_url']) && $config_details['linkedin_url'] !="") ? $config_details['linkedin_url']: "";
   $twitter_url			=(isset($config_details['twitter_url']) && $config_details['twitter_url'] !="") ? $config_details['twitter_url']: "";
   $pinterest_url		=(isset($config_details['pinterest_url']) && $config_details['pinterest_url'] !="") ? $config_details['pinterest_url']: "";
   $instagram_url		=(isset($config_details['instagram_url']) && $config_details['instagram_url'] !="") ? $config_details['instagram_url']: "";
   $allowed_otp_perday		=(isset($config_details['allowed_otp_perday']) && $config_details['allowed_otp_perday'] !="") ? $config_details['allowed_otp_perday']: "";

}

?>
<!-- Page Heading -->
<div class="row panel-body">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <!--<span class="sr-only">Error:</span>-->
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php echo form_open_multipart('admin/system_configuration');?>
		<div class="form-group">
		   <label for="admin_email">Admin Email</label>
               <input class="form-control" type="text" value="<?php echo stripslashes($admin_email);?>" name="admin_email" id="admin_email" />
		   <?php echo form_error('admin_email','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="signup_email">Signup Email</label>
		   <input class="form-control" type="text" value="<?php echo $signup_email;?>" name="signup_email" id="signup_email"/>
		   <?php echo form_error('signup_email','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="smtp_server_host">SMTP Server Host</label>
               <input class="form-control" type="text" value="<?php echo $smtp_server_host;?>" name="smtp_server_host" id="smtp_server_host" />
		   <?php echo form_error('smtp_server_host','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		    <label for="smtp_port_number">SMTP Server Port</label>
		   <input class="form-control" type="text" value="<?php echo $smtp_port_number;?>" name="smtp_port_number" id="smtp_port_number"/>
		   <?php echo form_error('smtp_port_number','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="smtp_uName">SMTP User Email</label>
               <input class="form-control" type="text" value="<?php echo stripslashes($smtp_uName);?>" name="smtp_uName" id="smtp_uName"/>
		   <?php echo form_error('smtp_uName','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="smtp_uPass">SMTP Password</label>
               <input class="form-control" type="password" value="<?php echo $smtp_uPass;?>" name="smtp_uPass" id="smtp_uPass"/>
		   <?php echo form_error('smtp_uPass','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		    <label for="address">Address</label>
		    <textarea name="address" class="form-control" id="address" rows="5"><?php echo stripslashes($address);?></textarea>
		     <?php echo form_error('address','<span class="error-msg">','</span>')?>
		</div>
		<div class="form-group">
		   <label for="latitude">Latitude</label>
               <input class="form-control" type="text" value="<?php echo $latitude;?>" name="latitude" id="latitude"/>
		   <?php echo form_error('latitude','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="longitude">Longitude</label>
               <input class="form-control" type="text" value="<?php echo $longitude;?>" name="longitude" id="longitude"/>
		   <?php echo form_error('longitude','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="contact_no">Contact No.</label>
               <input class="form-control" type="text" value="<?php echo $contact_no;?>" name="contact_no" id="contact_no"/>
		   <?php echo form_error('contact_no','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label>Date Format:</label>
		   <span class="form-control">
		   <label class="radio-inline">
			 <input type="radio" name="date_format" value="F j, Y" <?php if($date_format == 'F j, Y') echo 'checked="checked"'; ?> /> <?php echo date('F j, Y'); ?><br>
		   </label>
		   <label class="radio-inline">
			 <input type="radio" name="date_format" value="d/m/Y" <?php if($date_format == 'd/m/Y') echo 'checked="checked"'; ?> /> <?php echo date('d/m/Y'); ?><br>
		   </label>
		   <label class="radio-inline">
			 <input type="radio" name="date_format" value="m/d/Y" <?php if($date_format == 'm/d/Y') echo 'checked="checked"'; ?> /> <?php echo date('m/d/Y'); ?><br>
		   </label>
		   </span>
		 </div>
		<div class="form-group">
		   <label>Time Format:</label>
		   <span class="form-control">
		   <label class="radio-inline">
			 <input type="radio" name="time_format" value="h:i a" <?php if($time_format == 'h:i a') echo 'checked="checked"'; ?> /> <?php echo date('h:i a'); ?><br>
		   </label>
		   <label class="radio-inline">
			 <input type="radio" name="time_format" value="h:i A" <?php if($time_format == 'h:i A') echo 'checked="checked"'; ?> /> <?php echo date('h:i A'); ?><br>
		   </label>
		   <label class="radio-inline">
			 <input type="radio" name="time_format" value="H:i" <?php if($time_format == 'H:i') echo 'checked="checked"'; ?> /> <?php echo date('H:i'); ?><br></span>
		   </label>
		   </span>
		</div>
		<div class="form-group">
		   <label for="facebook_url">Facebook Url</label>
               <input class="form-control" type="text" value="<?php echo stripslashes($facebook_url);?>" name="facebook_url" id="facebook_url" />
		   <?php echo form_error('facebook_url','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="linkedin_url">Linkedin Url</label>
               <input class="form-control" type="text" value="<?php echo stripslashes($linkedin_url);?>" name="linkedin_url" id="linkedin_url" />
		   <?php echo form_error('linkedin_url','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="twitter_url">Twitter Url</label>
               <input class="form-control" type="text" value="<?php echo stripslashes($twitter_url);?>" name="twitter_url" id="twitter_url" />
		   <?php echo form_error('twitter_url','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="pinterest_url">Pinterest Url</label>
               <input class="form-control" type="text" value="<?php echo stripslashes($pinterest_url);?>" name="pinterest_url" id="pinterest_url" />
		   <?php echo form_error('pinterest_url','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="instagram_url">Instagram Url</label>
               <input class="form-control" type="text" value="<?php echo stripslashes($instagram_url);?>" name="instagram_url" id="instagram_url" />
		   <?php echo form_error('instagram_url','<span class="error-msg">','</span>')?>
            </div>
	    <div class="form-group">
		   <label for="instagram_url">Allowed OTP in a day</label>
               <input class="form-control" type="text" value="<?php echo stripslashes($allowed_otp_perday);?>" name="allowed_otp_perday" id="allowed_otp_perday" />
		   <?php echo form_error('allowed_otp_perday','<span class="error-msg">','</span>')?>
            </div>
		
		
		<div>
		   <button type="submit" class="btn btn-success">Submit</button>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->
