<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  
    </div>
</div>
<!-- /.row -->
<!-- Page Heading -->
<div class="row panel-body">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="">
		<div class="table-responsive" style="overflow: auto;">
		   <table class="table table-bordered table-hover table-striped" id="user_list_grid">
			<thead>
			   <tr>
				<th>User Name</th>
				<th>User Email</th>
				
				<th>Image name</th>
				<th>Actions</th>
			   </tr>
                  </thead>
			<tbody>
			<?php if(count($users_data) >0){
			   foreach($users_data as $k=>$users){
			?>
			   <tr id="<?php echo md5($users['id']);?>">
				<td><?php echo ucfirst($users['name']);?></td>
				<td><?php echo $users['email'];?></td>

				<td>
				    <a href="<?php echo site_url('admin/add_user/'.base64_encode($users['id']));?>" alt="Edit User" title="Edit User"><img src="<?php echo base_url(); ?>lib/images/admin_edit.png"/></a>
				    
				    <a href="<?php echo site_url('admin/delete_user/'.base64_encode($users['id']));?>" alt="Delete User" title="Delete User" onclick="return confirm('Are you sure to delete this user ?');"><img src="<?php echo base_url(); ?>lib/images/delete_admin.png"/></a>
				</td>
			   </tr>
			<?php	}
			   }?>
			</tbody>
		   </table>
		</div>
	  </div>
    </div>
</div>
<!-- /.row -->
