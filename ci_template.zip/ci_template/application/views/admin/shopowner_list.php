<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
		<a href="<?php echo site_url('admin/add_shopowner');?>" class="btn btn-lg btn-success pull-right">Add Users</a>
	  </h1>
    </div>
</div>
<!-- /.row -->
<!-- Page Heading -->
<div class="row">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <!--<span class="sr-only">Error:</span>-->
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="panel-body">
		<div class="table-responsive" style="overflow: auto;">
		   <table class="table table-bordered table-hover table-striped" id="shopowner_datatable">
			<thead>
			   <tr>
				<th>User Name</th>
				<th>User Email</th>
				<th>User Type</th>
				<th>User Status</th>
				<th>Featured On</th>
				<th>Border</th>
				<th>Actions</th>
			   </tr>
                  </thead>
			<tbody>
			<?php if(count($users_data) >0){ 
			   foreach($users_data as $k=>$users){
			?>
			   <tr id="<?php echo md5($users['id']);?>">
				<td><?php echo ucfirst($users['name']);?></td>
				<td><?php echo $users['email'];?></td>
				<td><?php echo ucfirst($users['account_type']);?></td>
				<td><?php echo ($users['status'] !="" ? ucfirst($users['status']) : 'Inactive');?></td>
				<td><?php echo ($users['featured_profile'] !="No" ? ($users['featured_profileon']) : '');?></td>
				<td id="<?php echo $users['id'] ?>" class="editable_border"><?php echo ucfirst($users['col_border']);?></td>
				<td>
				    <?php if($users['status'] == 'Active'){
					  $alt_text = 'Block User';
					  $image_name = 'user_block.png';
					  $status = 'Inactive';
				    }else{
					  $alt_text = 'Activate User';
					  $image_name = 'user_active.png';
					  $status = 'Active';
				    }?>

				    <!--<a href="<?php echo site_url('product/'.base64_encode($users['id']));?>" alt="View Product" title="View Product"><img src="<?php echo base_url(); ?>lib/images/admin_view.png"/></a>-->
					<a href="<?php echo site_url('admin/view_shopowner/'.base64_encode($users['id']));?>" alt="View User" title="View User"><img src="<?php echo base_url(); ?>lib/images/admin_view.png"/></a>
					<a href="<?php echo site_url('admin/updateFeatured/'.base64_encode($users['id']));?>" alt="Featured" title="Featured"><img src="<?php echo base_url(); ?>lib/images/star.png"/></a>
					<a href="javascript:void(0);" onclick="changeUserStatus(this, '<?php echo $status;?>')" id="<?php echo $users['id'];?>" alt="<?php echo $alt_text;?>" title="<?php echo $alt_text;?>"><img src="<?php echo base_url(); ?>lib/images/<?php echo $image_name;?>"/></a>
				    <a href="<?php echo site_url('admin/add_shopowner/'.base64_encode($users['id']));?>" alt="Edit User" title="Edit User"><img src="<?php echo base_url(); ?>lib/images/admin_edit.png"/></a>
				    
				    <a href="<?php echo site_url('admin/delete_user/'.base64_encode($users['id'])."/shopowner");?>" alt="Delete User" title="Delete User" onclick="return confirm('Are you sure to delete this user ?');"><img src="<?php echo base_url(); ?>lib/images/delete_admin.png"/></a>
				</td>
			   </tr>
			<?php	}
			   }?>
			</tbody>
		   </table>
		</div>
	  </div>
    </div>
</div>

<script src="<?php echo base_url(); ?>lib/js/jquery.jeditable.js"></script>

<!-- /.row -->
<script type="text/javascript">
    function changeUserStatus(obj,status) {
	  var user_id = obj.id;
	  $.ajax({
		url : "<?php echo site_url('admin/change_status');?>",
		dataType:'JSON',
		type: "POST",
		data:{'user_id':user_id,'status':status},
		success: function(data)
		{
		    if (data.success == 'success') {
			  window.location.reload();
		    }
		},error :function(){

		}
	  });
    }

$(function() {

	$("#shopowner_datatable_paginate, #shopowner_datatable_length").click(function() {

		$(".editable_border").editable("<?php echo base_url('admin/updateBorder'); ?>", {
			indicator : '<img src="img/indicator.gif">',
			data   : "{'Silver':'Silver','Gold':'Gold','Platinum':'Platinum', 'Diamond' :'Diamond', 'Perfect' :'Perfect'}",
			type   : "select",
			submit : "OK",
			id   	  	: 'cellid',
			name 	  	: 'cellvalue',
			style  : "inherit",
			submitdata : function() {
				return {id : 2};
			}
		});

	});

	$(".editable_border").editable("<?php echo base_url('admin/updateBorder'); ?>", {
    indicator : 'Wait...',
    data   : "{'Silver':'Silver','Gold':'Gold','Platinum':'Platinum', 'Diamond' :'Diamond', 'Perfect' :'Perfect'}",
    type   : "select",
    submit : "OK",
	id   	  	: 'cellid',
	name 	  	: 'cellvalue',
    style  : "inherit",
    submitdata : function() {
      return {id : 2};
    }
  });

});
</script>
