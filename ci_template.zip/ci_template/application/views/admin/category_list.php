<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  <div class="pull-right">
		<a href="<?php echo site_url('admin/category/add');?>" class="btn btn-default btn-success ">Add Category</a>
		<a href="<?php echo site_url('admin/category_order');?>" class="btn btn-default btn-success">Set Order</a>
		</div>
	  </h1>
    </div>
</div>
<!-- /.row -->
<!-- Page Heading -->
<div class="row panel-body">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="panel-body">
		<div class="table-responsive" style="overflow: auto;">
		   <table class="table table-bordered table-hover table-striped" id="category_datatable">
			<thead>
			   <tr>
				<th>S.No.</th>
				<th>Category Name</th>
				<th>Category Image</th>
				<th>Category Status</th>
				<th>Actions</th>
			   </tr>
                  </thead>
			<tbody>
			<?php if(count($category_data) >0){
			    $i=0;
			   foreach($category_data as $k=>$category){
			    $i++;
				if($category['category_image'] !=""){
				    $product_img = base_url().'uploads/category_images/'.$category['category_image'];
				}else{
				    $product_img = base_url().'lib/images/no_product.png';
				}
			?>
			   <tr id="<?php echo md5($category['id_category']);?>">
			    <td><?php echo $i;?></td>
				<td><?php echo ucfirst($category['category_name']);?></td>
				<td><img src="<?php echo $product_img;?>" alt="<?php echo $category['category_image'];?>" class="img-square"  height="80" width="80"/></td>
				<td><?php echo ($category['category_status'] ? ucfirst($category['category_status']) : 'Inactive');?></td>
				<td>
				    <?php if($category['category_status'] == 'Active'){
					  $alt_text = 'Block Category';
					  $image_name = 'user_block.png';
					  $status = 'Inactive';
				    }else{
					  $alt_text = 'Activate Category';
					  $image_name = 'user_active.png';
					  $status = 'Active';
				    }?>
				    <a href="javascript:void(0);" onclick="changeCategoryStatus(this, '<?php echo $status;?>')" id="<?php echo $category['id_category'];?>" alt="<?php echo $alt_text;?>" title="<?php echo $alt_text;?>"><img src="<?php echo base_url(); ?>lib/images/<?php echo $image_name;?>"/></a>
				    <a href="<?php echo site_url('admin/category/add/'.base64_encode($category['id_category']));?>" alt="Edit Category" title="Edit Category"><img src="<?php echo base_url(); ?>lib/images/admin_edit.png"/></a>
				    <a href="<?php echo site_url('admin/category/view/'.base64_encode($category['id_category']));?>" alt="View Category" title="View Category"><img src="<?php echo base_url(); ?>lib/images/admin_view.png"/></a>
				    <a href="javascript:void(0);" alt="Delete Category" title="Delete Category" onclick="deleteCategory(this);" id="<?php echo $category['id_category'];?>"><img src="<?php echo base_url(); ?>lib/images/delete_admin.png"/></a>
				</td>
			   </tr>
			<?php	}
			   }?>
			</tbody>
		   </table>
		</div>
	  </div>
    </div>
</div>
<!-- /.row -->
<script type="text/javascript">
    function changeCategoryStatus(obj,status) {
	  var id_category = obj.id;
	  $.ajax({
		url : "<?php echo site_url('admin/change_category_status');?>",
		dataType:'JSON',
		type: "POST",
		data:{'id_category':id_category,'category_status':status},
		success: function(data)
		{
		    if (data.success == 'success') {
			  window.location.reload();
		    }
		},error :function(){
		    
		}
	  });
    }
    
    function deleteCategory(obj) {
	  if (confirm('Are you sure to delete this category ?')) {
		changeCategoryStatus(obj,'Deleted') 
	  }
	  return false;
    }
</script>
