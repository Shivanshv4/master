<style type="text/css">
   .datepicker{
	top: 526.6px !important;
   }
</style>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($content_details))
{
   $content_title  =(isset($content_details['content_title']) && $content_details['content_title'] !="") ? $content_details['content_title']:"";
   $variable_name =(isset($content_details['variable_name']) && $content_details['variable_name'] !="") ? $content_details['variable_name']:"";
   $content    =(isset($content_details['content']) && $content_details['content'] !="") ? $content_details['content']:"";
   $status  =(isset($content_details['status']) && $content_details['status'] !="") ? $content_details['status']:"";
}
if(isset($content_details['id']) && $content_details['id'] !=""){
   $content_id   = $content_details['id'];
   
}elseif(@$this->uri->segment(3) && @$this->uri->segment(3)!=FALSE){
   $content_id = base64_decode(@$this->uri->segment(3));
}else{
   $content_id = 0;
}
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php if($content_id == 0){
		echo form_open_multipart('admin/add_content');
	   }else{
		echo form_open_multipart('admin/add_content/'.base64_encode($content_id));
	   }?>
		<div class="form-group <?php echo (@form_error('content_title') ? 'has-error' :'');?>">
		   <label>Title</label>
               <input class="form-control" type="text" value="<?php echo $content_title;?>" name="content_title"/>
		   <?php echo form_error('content_title','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group <?php echo (@form_error('variable_name') ? 'has-error' :'');?>">
		   <label>Variable Name</label>
               <input class="form-control" type="text" value="<?php echo $variable_name;?>" name="variable_name" <?php echo ($content_id >0 ? 'readonly="readonly"' : '');?>/>
		   <?php echo form_error('variable_name','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group <?php echo (@form_error('content') ? 'has-error' :'');?>">
		   <label>Content</label>
               <textarea rows="5" class="form-control mceEditor" name="content" id="content"><?php echo stripslashes($content);?></textarea>
		   <?php echo form_error('content','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group <?php echo (@form_error('status') ? 'has-error' :'');?>">
               <label>Status</label>
		   <select class="form-control" name="status">
			<option value="">Select</option>
			<option value="Active" <?php echo ($status == 'Active' ? 'selected="selected"' : '');?>>Active</option>
			<option value="Inactive" <?php echo ($status == 'Inactive' ? 'selected="selected"' : '');?>>Inactive</option>
               </select>
		   <?php echo form_error('status','<span class="error-msg">','</span>')?>
            </div>
		<div>
		   <input type="hidden" id="content_id" value="<?php echo $content_id;?>" name="content_id"/>
		   <button type="submit" class="btn btn-success">Submit</button>
		   <a href="<?php echo site_url('admin/static_content');?>" class="btn btn-primary">Back</a>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->
