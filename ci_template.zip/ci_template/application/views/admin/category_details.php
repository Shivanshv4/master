<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($category_details))
{
   $category_name =(isset($category_details['category_name']) && $category_details['category_name'] !="") ? $category_details['category_name']:"";
   $category_status  =(isset($category_details['category_status']) && $category_details['category_status'] !="") ? $category_details['category_status']:"";
   $image_name = (isset($category_details['category_image']) && trim($category_details['category_image']) !="") ? $category_details['category_image'] :"";
   if((isset($category_details['category_image']) && trim($category_details['category_image']) !="")){
	$image = base_url().'uploads/category_images/'.$category_details['category_image'];
   }else{
	$image = base_url().'lib/images/no_product.png';
   }
}
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php echo form_open_multipart('product/view_product');?>
		<div class="form-group">
		   <label>Category Name</label>
               <input class="form-control" type="text" value="<?php echo $category_name;?>" name="category_name" readonly="readonly"/>
            </div>
		<div class="form-group"><label>Category Status</label>
		   <input class="form-control" type="text" value="<?php echo ucfirst($category_status);?>" name="category_status" readonly="readonly"/>
            </div>
		<div class="form-group">
		   <label>Category Image</label>
		   <br>
		   <img src="<?php echo $image;?>" alt="<?php echo $category_name;?>" class="img-thumbnail"  height="160" width="160"/>
            </div>
		<div>
		   <a href="<?php echo site_url('admin/categories');?>" class="btn btn-primary">Back</a>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
