<?php
$segment = @$this->uri->segment(3);
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?></h1>
    </div>
</div>
<!-- /.row -->
<!-- Page Heading -->
<div class="row">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="panel-body">
		<div class="table-responsive" style="overflow: auto;">
		    <table class="table table-bordered table-hover table-striped" id="contact_management_datatable">
			<thead>
			   <tr>
				<th>Name</th>
				<th>Email</th>
				<th>Subject</th>
				<?php if(@$this->uri->segment(3)=="advertisement"){?>
				<th>Adv Plan</th>
				<?php } ?>
				<th>Message</th>
				<th>Actions</th>
			   </tr>
			</thead>
			<tbody>
			<?php if(count($contact_data) >0){
			   foreach($contact_data as $k=>$contact){
			?>
			   <tr id="<?php echo md5($contact['id']);?>">
				<td><?php echo ucfirst($contact['name']);?></td>
				<td><?php echo character_limiter($contact['email']);?></td>
				<?php if(@$this->uri->segment(3)!="advertisement"){?>
				<td><?php echo character_limiter($contact['subject']);?></td>
				<?php }else{?>
				<td>Advertisement</td>
				<td><?php echo character_limiter($contact['adv_name']);?></td>
				<?php } ?>
				<td><?php echo ($contact['message'] !="" ? character_limiter(ucfirst($contact['message']),20) : '');?></td>
				<td>
				    <a href="<?php echo site_url('admin/view_contact/'.base64_encode($contact['id']).'/'.base64_encode($segment));?>" alt="View Contact" title="View Contact"><img src="<?php echo base_url(); ?>lib/images/admin_view.png"/></a>
				    <a href="<?php echo site_url('admin/reply_contact/'.base64_encode($contact['id']).'/'.base64_encode($segment));?>" alt="Reply Contact" title="Reply Contact"><img src="<?php echo base_url(); ?>lib/images/reply_contact.png"/></a>
				    <a href="<?php echo site_url('admin/delete_contact/'.base64_encode($contact['id']).'/'.base64_encode($segment));?>" alt="Delete Contact" title="Delete Contact" onclick="return confirm('Are you sure to delete this contact enquiry ?');"><img src="<?php echo base_url(); ?>lib/images/delete_admin.png"/></a>
				</td>
			   </tr>
			<?php	}
			   }?>
			</tbody>
		    </table>
		</div>
	  </div>
    </div>
</div>
<!-- /.row -->
