<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
		<a href="<?php echo site_url('admin/edit_banner');?>" class="btn btn-lg btn-success pull-right">Add Banner</a>
	  </h1>
    </div>
</div>
<!-- /.row -->
<!-- Page Heading -->
<div class="row">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <!--<span class="sr-only">Error:</span>-->
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="panel-body">
		<div class="table-responsive" style="overflow: auto;">
		   <table class="table table-bordered table-hover table-striped" id="banner_list_grid">
			<thead>
			   <tr>
				<th>Name</th>
				<th>Link 1</th>
				<th>Link 2</th>
				<th>Banner Type</th>
				<th>Banner Image</th>
				<th>Banner Status</th>
				<th>Actions</th>
			   </tr>
                  </thead>
			<tbody>
			<?php if(count($banner_data) >0){ 
			   foreach($banner_data as $k => $products){
				if($products['banner_image'] !=""){
				    $product_img = base_url().'uploads/banner_images/sm_'.$products['banner_image'];
				}else{
				    $product_img = base_url().'lib/images/no_product.png';
				}
				
			?>
			   <tr id="<?php echo md5($products['banner_id']);?>">
				<td><?php echo $products['banner_title'];?></td>
				<td><?php echo $products['link_one'] ? ucfirst($products['link_one']) :'';?></td>
				<td><?php echo $products['link_two'] ? ucfirst($products['link_two']) :'';?></td>
				<td><?php echo $products['banner_type_name'];?></td>
				<td><img src="<?php echo $product_img;?>" alt="<?php echo $products['name'];?>" class="img-square"  width="80"/></td>
				<td><?php echo ($products['cstatus'] !="" ? ucfirst($products['cstatus']) : 'Inactive');?></td>
				<td>
				    <?php if($products['cstatus'] == 'Active'){
					  $alt_text = 'Block Banner';
					  $image_name = 'user_block.png';
					  $status = 'Inactive';
				    }else{
					  $alt_text = 'Activate Banner';
					  $image_name = 'user_active.png';
					  $status = 'Active';
				    }?>

				    <a href="<?php echo site_url('admin/edit_banner/'.base64_encode($products['banner_id']));?>" alt="Edit Banner" title="Edit Banner"><img src="<?php echo base_url(); ?>lib/images/admin_edit.png"/></a>
				    
				    <a href="<?php echo site_url('admin/delete_banner/'.base64_encode($products['banner_id']));?>" alt="Delete Banner" title="Delete Banner" onclick="return confirm('Are you sure to delete this banner ?');"><img src="<?php echo base_url(); ?>lib/images/delete_admin.png"></a>

				</td>
			   </tr>
			<?php	}
			   }?>
			</tbody>
		   </table>
		</div>
	  </div>
    </div>
</div>
<!-- /.row -->
<script type="text/javascript">
    function changeProductStatus(obj,status) {
	  var product_id = obj.id;
	  $.ajax({
		url : "<?php echo site_url('product/change_status');?>",
		dataType:'JSON',
		type: "POST",
		data:{'product_id':product_id,'status':status},
		success: function(data)
		{
		    if (data.success == 'success') {
			  window.location.reload();
		    }
		},error :function(){

		}
	  });
    }
</script>
