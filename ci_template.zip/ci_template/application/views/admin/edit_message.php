<style type="text/css">
   .datepicker{
	top: 526.6px !important;
   }
</style>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($content_details))
{
   $subject =(isset($content_details['subject']) && $content_details['subject'] !="") ? $content_details['subject']:"";
   $variable_name =(isset($content_details['title']) && $content_details['title'] !="") ? $content_details['title']:"";
   $variables =(isset($content_details['variables']) && $content_details['variables'] !="") ? $content_details['variables']:"";
   $content    =(isset($content_details['content']) && $content_details['content'] !="") ? $content_details['content']:"";
   $status  =(isset($content_details['status']) && $content_details['status'] !="") ? $content_details['status']:"";
}
if(isset($content_details['id']) && $content_details['id'] !=""){
   $content_id   = $content_details['id'];
   
}elseif(@$this->uri->segment(3) && @$this->uri->segment(3)!=FALSE){
   $content_id = base64_decode(@$this->uri->segment(3));
}else{
   $content_id = 0;
}
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php if($content_id == 0){
		echo form_open_multipart('admin/editmessage');
	   }else{
		echo form_open_multipart('admin/editmessage/'.base64_encode($content_id));
	   }?>
		<div class="form-group <?php echo (@form_error('content_title') ? 'has-error' :'');?>">
		   <label>Subject</label>
               <input class="form-control" type="text" value="<?php echo $subject;?>" name="subject"/>
		   <?php echo form_error('subject','<span class="error-msg">','</span>')?>
               </div>
		<div class="form-group <?php echo (@form_error('variable_name') ? 'has-error' :'');?>">
		   <label>Variable Name</label>
               <input class="form-control" type="text" value="<?php echo $variable_name;?>" name="variable_name" <?php echo ($content_id >0 ? 'readonly="readonly"' : '');?>/>
		   <?php echo form_error('variable_name','<span class="error-msg">','</span>')?>
               </div>
		<div class="form-group <?php echo (@form_error('content') ? 'has-error' :'');?>">
		   <label>Message</label>
               <textarea rows="5" class="form-control mceEditor" name="content" id="content"><?php echo stripslashes($content);?></textarea>
		   <?php echo form_error('content','<span class="error-msg">','</span>')?>
            </div>
            <div class="form-group <?php echo (@form_error('content_title') ? 'has-error' :'');?>">
		   <label>Variables</label>
		   <div>
		     <?php echo nl2br($variables);?>
		   </div>
		   <?php echo form_error('variables','<span class="error-msg">','</span>')?>
               </div>
	       
		<div class="form-group <?php echo (@form_error('status') ? 'has-error' :'');?>">
               <label>Status</label>
		   <select class="form-control" name="status">
			<option value="">Select</option>
			<option value="Enable" <?php echo ($status == 'Enable' ? 'selected="selected"' : '');?>>Enable</option>
			<option value="Disable" <?php echo ($status == 'Disable' ? 'selected="selected"' : '');?>>Disable</option>
               </select>
		   <?php echo form_error('status','<span class="error-msg">','</span>')?>
            </div>
		<div>
		   <input type="hidden" id="content_id" value="<?php echo $content_id;?>" name="content_id"/>
		   <button type="submit" class="btn btn-success">Submit</button>
		   <a href="<?php echo site_url('admin/emailmessage');?>" class="btn btn-primary">Back</a>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->
