<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($contact_data))
{
   $name    =(isset($contact_data['name']) && $contact_data['name'] !="") ? $contact_data['name']:"";
   $phone   =(isset($contact_data['phone']) && $contact_data['phone'] !="") ? $contact_data['phone']:"";
   $email   =(isset($contact_data['email']) && $contact_data['email'] !="") ? $contact_data['email']:"";
   $message   =(isset($contact_data['message']) && $contact_data['message'] !="") ? $contact_data['message']:"";
   
   $subject   =$contact_data['subject'];
   $adv_plan   =$contact_data['plan_id'];
   
   
   
}

$page = base64_decode(@$this->uri->segment(4));

if(!empty($page))
{
    $back_url = "admin/contact_management/".$page;
}
else{
    $back_url = "admin/contact_management";
}

?>
<div class="row">
   <div class="col-lg-12">
	<div class="panel-body">
	   <div class="form-group">
		<label>Name</label>
		<input class="form-control" type="text" value="<?php echo $name;?>" name="name" readonly="readonly"/>
         </div>
	   <div class="form-group">
		<label>Contact Number</label>
		<input class="form-control" type="text" value="<?php echo $phone;?>" name="phone" readonly="readonly"/>
         </div>
	   <div class="form-group">
		<label>Email</label>
		<input class="form-control" type="text" value="<?php echo $email;?>" name="email" readonly="readonly"/>
         </div>
	   <?php if(empty($adv_plan)){ ?>
	   <div class="form-group">
		<label>subject</label>
		<input class="form-control" type="text" value="<?php echo $subject;?>" name="email" readonly="readonly"/>
         </div>
	   <?php }else{
	    $plan_data = $this->banner_model->GeAdvertisementById($adv_plan); 
	    ?>
	    <div class="form-group">
		<label>Advertisment Plan</label>
		<textarea rows="3" class="form-control mceNoEditor" name="message" id="message" readonly="readonly"><?php echo $plan_data['adv_name']; ?></textarea>
         </div>
	    <?php
	   }
	    ?>
	   <div class="form-group">
		<label>Message</label>
		<textarea rows="10" class="form-control mceNoEditor" name="message" id="message" readonly="readonly"><?php echo stripslashes(strip_tags($message));?></textarea>
         </div>
	   <div>
		<a href="<?php echo site_url($back_url);?>" class="btn btn-primary">Back</a>
         </div>
	</div>
   </div>
</div>
