<style type="text/css">
   .datepicker{
	top: 458.6px !important;
   }
</style>
<!-- Page Heading -->
<?php if(isset($user_details))
{
   $name      =(isset($user_details['name']) && $user_details['name'] !="") ? $user_details['name']:"";
   $email     =(isset($user_details['email']) && $user_details['email'] !="") ? $user_details['email']:"";
   $password  =(isset($user_details['password']) && $user_details['password'] !="") ? $user_details['password']:"";
   $cpassword =(isset($user_details['cpassword']) && $user_details['cpassword'] !="") ? $user_details['cpassword']:"";
   
   $image_name = (isset($user_details['image_name']) && trim($user_details['image_name']) !="") ? $user_details['image_name'] :"";
  

   
      if((isset($user_details['image_name']) && trim($user_details['image_name']) !="")){
   
	       $image = showUserImage("thumb_".$user_details['image_name']);
	   
      }else{
			$image = base_url().'lib/images/no_user_image.png';
      }
  
}
else{
    $image = '';
}
if(isset($user_details['id']) && $user_details['id'] !=""){
   $user_id   = $user_details['id'];
   
}elseif(@$this->uri->segment(3) && @$this->uri->segment(3)!=FALSE){
   $user_id = base64_decode(@$this->uri->segment(3));
}else{
   $user_id = 0;
}

$page_name = $this->uri->segment(2);
?>

<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>

<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php if($user_id == 0){
	    if($page_name=="add_shopowner")
	    {
		echo form_open_multipart('admin/add_shopowner');
	    }
	    else{
	       echo form_open_multipart('admin/add_user');
	    }
	   }else{
	        if($page_name=="add_shopowner")
	       {
		echo form_open_multipart('admin/add_shopowner/'.base64_encode($user_id));
	       }
	       else{
		  echo form_open_multipart('admin/add_user/'.base64_encode($user_id));
	       }
	   }?>
		<div class="form-group <?php echo (@form_error('user_name') ? 'has-error' :'');?>">
		   <label>Name</label>
               <input class="form-control" type="text" value="<?php echo $name;?>" name="user_name"/>
		   <?php echo form_error('user_name','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group <?php echo (@form_error('user_email') ? 'has-error' :'');?>">
			<label>Email</label>
				<input class="form-control" type="text" value="<?php echo $email;?>" name="user_email"/>
				<?php echo form_error('user_email','<span class="error-msg">','</span>')?>
				<input class="form-control" type="hidden" value="<?php echo $old_email;?>" name="old_email"/>   
       </div>
		
		<?php if($user_id == 0){?>
		<div class="form-group <?php echo (@form_error('password') ? 'has-error' :'');?>">
		   <label>Password</label>
               <input class="form-control" type="password" value="<?php echo $password;?>" name="password"/>
		   <?php echo form_error('password','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group <?php echo (@form_error('cpassword') ? 'has-error' :'');?>">
		   <label>Confirm Password</label>
               <input class="form-control" type="password" value="<?php echo $cpassword;?>" name="cpassword"/>
		   <?php echo form_error('cpassword','<span class="error-msg">','</span>')?>
            </div>
		<?php }?>
		
		
		<div>
		   <input type="hidden" id="user_id" value="<?php echo $user_id;?>" name="user_id"/>
		   <button type="submit" class="btn btn-success">Submit</button>
			<a href="<?php echo site_url('admin/users') ?>" class="btn btn-primary">Back</a>
		  

            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
