<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($admin_details))
{
   $admin_name      	=(isset($admin_details['user_name']) && $admin_details['user_name'] !="") ? $admin_details['user_name']:"";
   $admin_email 		=(isset($admin_details['email']) && $admin_details['email'] !="") ? $admin_details['email']:"";
   $password    		=(isset($admin_details['password']) && $admin_details['password'] !="") ? $admin_details['password']:"";
   $confirm_password  	=(isset($admin_details['confirm_password']) && $admin_details['confirm_password'] !="") ? $admin_details['confirm_password']:"";
}
?>
<!-- Page Heading -->
<div class="row">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <!--<span class="sr-only">Error:</span>-->
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php echo form_open_multipart('admin/profile');?>
		<div class="form-group">
		   <label for="admin_email">Admin Name</label>
               <input class="form-control" type="text" value="<?php echo $admin_name;?>" name="user_name" id="user_name" />
		   <?php echo form_error('user_name','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="signup_email">Admin Email</label>
		   <input class="form-control" type="text" value="<?php echo $admin_email;?>" name="email" id="email"/>
		   <?php echo form_error('email','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		   <label for="smtp_server_host">Password</label>
               <input class="form-control" type="password" value="<?php //echo $password;?>" name="password" id="password" autocomplete="off" />
		   <?php echo form_error('password','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group">
		    <label for="smtp_port_number">Confirm Password</label>
		   <input class="form-control" type="password" value="<?php //echo $confirm_password;?>" name="confirm_password" id="confirm_password"  autocomplete="off" />
		   <?php echo form_error('confirm_password','<span class="error-msg">','</span>')?>
            </div>
		<div class="col-lg-12">
		   <button type="submit" class="btn btn-success">Submit</button>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->
<script type="text/javascript">alert(tinymce.activeEditor.getBody());
tinymce.activeEditor.getBody().setAttribute('contenteditable', false);
</script>