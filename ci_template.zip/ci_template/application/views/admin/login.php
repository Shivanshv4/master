<!-- Page Heading -->
<div class="row">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                       <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <?php if(!empty($message)):?>
                    <div class="error"><?php echo $message;?></div>
                    <?php endif;?>
                    <input type="hidden" name="verify" />
                    <?php echo form_error('verify', '<p class="bg-danger">', '</p>');?>
                    <span class="remove_error"><?php echo @$verify;?></span>
                    <div class="panel-body">
                        <?php echo form_open('admin');?>
                            <fieldset>
                                <div class="form-group <?php echo ((form_error('user_email') !="") ? 'has-error' : ''); ?>">
                                   <input class="form-control" placeholder="Email" name="user_email" type="text" value="<?php echo $_REQUEST['user_email'] ?>" autofocus>
                                    <?php //echo form_error('user_email', '<span class="error-msg">', '</span>');?>
                                </div>
                                <div class="form-group <?php echo ((form_error('password') !="") ? 'has-error' : ''); ?>">
                                   <input class="form-control" placeholder="Password" name="password" type="password" value="<?php echo $_REQUEST['password'] ?>">
                                    <?php //echo form_error('password', '<span class="error-msg">', '</span>');?>
                                </div>
                               <button type="submit" class="btn btn-lg btn-success btn-block">Login</button>
                            </fieldset>
                        <?php echo form_close();?>
                       <div class="span12"><a href="<?php echo site_url('admin/forgot_password');?>">Forgot Password?</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.row -->