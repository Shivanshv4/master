<style type="text/css">
   .datepicker{
	top: 526.6px !important;
   }
</style>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($category_details))
{
   $category_name =(isset($category_details['category_name']) && $category_details['category_name'] !="") ? $category_details['category_name']:"";
   $category_status  =(isset($category_details['category_status']) && $category_details['category_status'] !="") ? $category_details['category_status']:"";
   $image_name = (isset($category_details['category_image']) && trim($category_details['category_image']) !="") ? $category_details['category_image'] :"";
   if((isset($category_details['category_image']) && trim($category_details['category_image']) !="")){
	$image = base_url().'uploads/category_images/'.$category_details['category_image'];
   }else{
	$image = base_url().'lib/images/no_product.png';
   }
}
if(isset($category_details['id']) && $category_details['id'] !=""){
   $id_category   = $category_details['id'];

}elseif(@$this->uri->segment(3) && @$this->uri->segment(3)!=FALSE){
   $id_category = base64_decode(@$this->uri->segment(3));
}else{
   $id_category = 0;
}
?>
<style>
#sortable-list		{ padding:0; }
#sortable-list li	{ padding:4px 8px; color:#000; cursor:move; list-style:none; width:500px; background:#ddd; margin:10px 0; border:1px solid #999; }

</style>

	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.js"></script>
<!-- Page Heading -->
<div class="row">

   <div class="alert alert-success" style="display: none" id="message-box"><?php echo $message; ?> </div>

    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php
	   //echo form_open_multipart('product/add_category', array('id' => 'dd-form'));
	   ?>

	   <form id="dd-form" action="<?php echo base_url('product/setOrderCategory'); ?>" method="post">
		<div class="form-group <?php echo (@form_error('category_status') ? 'has-error' :'');?>">

		 <ul id="sortable-list">
		 <?php
			$order = array();
			foreach ($category_data  as $catData) {

			   echo '<li title="',$catData['id_category'],'">',$catData['category_name'],'</li>';
			   $order[] = $catData['id_category'];
			}
		 ?>
		 </ul>
            </div>

		<div>

			<input type="hidden" name="sort_order" id="sort_order" value="<?php echo implode(',',$order); ?>" />
<input style="display: none"; type="checkbox" value="1" name="autoSubmit" id="autoSubmit" <?php if($_POST['autoSubmit']) { echo 'checked="checked"'; } ?> />


		   <a href="<?php echo site_url('admin/categories');?>" class="btn btn-primary">Back</a>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->
<script type="text/javascript">

   /* when the DOM is ready */
//jQuery(document).ready(function() {
$( document ).ready(function() {

	/* grab important elements */
	var sortInput = jQuery('#sort_order');
	var submit = jQuery('#autoSubmit');

	var messageBox = jQuery('#message-box');
	var list = jQuery('#sortable-list');
	/* create requesting function to avoid duplicate code */
	var request = function() {
		jQuery.ajax({
			beforeSend: function() {
			   messageBox.show();
				messageBox.text('Updating the sort order in the database.');
				//alert(submit[0].checked);
			},
			complete: function() {
			   messageBox.show();
				messageBox.text('Database has been updated.');
			},
			data: 'sort_order=' + sortInput[0].value + '&ajax=true&do_submit=1&byajax=1', //need [0]?
			type: 'post',
			url: '<?php echo base_url('product/setOrderCategory'); ?>'
		});
	};
	/* worker function */
	var fnSubmit = function(save) {
		var sortOrder = [];
		list.children('li').each(function(){
			sortOrder.push(jQuery(this).data('id'));
		});
		sortInput.val(sortOrder.join(','));
		console.log(sortInput.val());
		if(save) {
			request();
		}
	};
	/* store values */
	list.children('li').each(function() {
		var li = jQuery(this);
		li.data('id',li.attr('title')).attr('title','');
	});
	/* sortables */
	list.sortable({
		opacity: 0.7,
		update: function() {
			fnSubmit(true);
		}
	});
	list.disableSelection();
	/* ajax form submission */
	jQuery('#dd-form').bind('submit',function(e) {
		if(e) e.preventDefault();
		fnSubmit(true);
	});
});
</script>
