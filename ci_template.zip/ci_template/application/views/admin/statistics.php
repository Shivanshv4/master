<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
		<a href="<?php echo site_url('admin/resetstats');?>" class="btn btn-lg btn-success pull-right">Reset</a>
	  </h1>
    </div>
</div>
<!-- /.row -->
<!-- Page Heading -->
<div class="row">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="panel-body">
		<div class="table-responsive" style="overflow: auto;">
		  
		   <table id="shopowner_statistics-grid" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>User Name</th>
                        <th>Deals Done</th>
			<th>Mail Sent</th>
			<th>Mail Not Received</th>
			<th>Featured Profile Adv</th>
			<th>Featured Product Adv</th>
			<th>Days Active</th>
			<th>Total Points</th>
                      </tr>
                    </thead>
                    <tbody>
                    </tbody>
                  </table>
		</div>
	  </div>
    </div>
</div>


