<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($user_details))
{
   $name      =(isset($user_details['name']) && $user_details['name'] !="") ? $user_details['name']:"";
   $email     =(isset($user_details['email']) && $user_details['email'] !="") ? $user_details['email']:"";
   $gender    =(isset($user_details['gender']) && $user_details['gender'] !="") ? $user_details['gender']:"";
   $dob       =(isset($user_details['dob']) && $user_details['dob'] !="") ?date('m/d/Y',strtotime($user_details['dob'])):"";
   $type      =(isset($user_details['account_type']) && $user_details['account_type'] !="") ? $user_details['account_type']:"";
   $address   =(isset($user_details['address']) && $user_details['address'] !="") ? $user_details['address']:"";
   $phone_number=(isset($user_details['phone_number']) && $user_details['phone_number'] !="") ? $user_details['phone_number']:"";
   $country_id = (isset($user_details['country_id']) && trim($user_details['country_id']) !="") ? $user_details['country_id'] :"";
   $col_border = (isset($user_details['col_border']) && trim($user_details['col_border']) !="") ? $user_details['col_border'] :"";
   $account_type = (isset($user_details['account_type']) && trim($user_details['account_type']) !="") ? $user_details['account_type'] :"";
   if((isset($user_details['image_name']) && trim($user_details['image_name']) !="")){
	$image = showUserImage("thumb_".$user_details['image_name']);
   }else{
	$image = base_url().'lib/images/no_user_image.png';
   }
}
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php echo form_open_multipart('admin/view_user');?>
		<div class="form-group">
		   <label>Name</label>
               <input class="form-control" type="text" value="<?php echo ucfirst($name);?>" name="user_name" readonly="readonly"/>
            </div>
		<div class="form-group">
		   <label>Email</label>
               <input class="form-control" type="text" value="<?php echo $email;?>" name="user_email" readonly="readonly"/>
            </div>
		<div class="form-group">
		   <label>Gender</label>
               <input class="form-control" type="text" value="<?php echo ucfirst($gender);?>" name="user_gender" readonly="readonly"/>
            </div>
		<div class="form-group"><label>User Type</label>
		   <input class="form-control" type="text" value="<?php echo ucfirst($type);?>" name="user_type" readonly="readonly"/>
            </div>
		<div class="form-group">
		   <label>Date Of Birth</label>
               <input class="form-control" type="text" value="<?php echo $dob;?>" id="dob_datepicker" readonly="readonly"  name="user_dob"/>
            </div>
		<div class="form-group">
		   <label>Contact Number</label>
               <input class="form-control" type="text" value="<?php echo $phone_number;?>" name="phone_number" readonly="readonly"/>
            </div>
		<div class="form-group">
		   <label>Address</label>
               <textarea class="form-control" name="address" readonly="readonly"><?php echo $address;?></textarea>
            </div>
		<div class="form-group">
		   <label>Country</label>
		   <?php $counrty_data = $this->admin_model->_getCountryDetailsById($country_id);?>
		   <input class="form-control" type="text" value="<?php echo  $counrty_data['country_name'];?>" name="country" readonly="readonly"/>
            </div>
		<?php if($account_type=="shopowner"){ ?>
		<div class="form-group">
		   <label>Border</label>
               <input class="form-control" type="text" value="<?php echo $col_border;?>" id="dob_datepicker" readonly="readonly"  name="user_dob"/>
            </div>
		<?php } ?>
		<div class="form-group">
		   <label>Profile Image</label>
		   <br>
		   <img src="<?php echo $image;?>" alt="<?php echo $name;?>" class="img-thumbnail"  height="160" width="160"/>
            </div>
		<div>
			<?php if($callfrom == 'shopowner') {
				echo '<a href="'.site_url('admin/shopowner').'" class="btn btn-primary">Back</a>';
			} else {
				echo '<a href="'.site_url('admin/users').'" class="btn btn-primary">Back</a>';
			}
			?>

            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->
