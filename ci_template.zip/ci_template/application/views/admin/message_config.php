<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
		<!--<a href="<?php //echo site_url('admin/add_content');?>" class="btn btn-lg btn-success pull-right">Add Content</a>-->
	  </h1>
    </div>
</div>
<!-- /.row -->
<!-- Page Heading -->
<div class="row panel-body">
    <?php if($this->session->flashdata('flash_msg') !=""){?>
    <div class="alert alert-success" id="alert-success-div">
	  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
	  <!--<span class="sr-only">Error:</span>-->
	  <?php echo $this->session->flashdata('flash_msg');?>
	  <button type="button" class="close" aria-label="Close" id="msg-close"><span aria-hidden="true">&times;</span></button>
    </div>
    <?php }?>
    <div class="col-lg-12">
	  <div class="panel-body">
		<div class="table-responsive" style="overflow: auto;">
		   <table class="table table-bordered table-hover table-striped" id="content_datatable">
			<thead>
			   <tr>
				<!--<th>Title</th>-->
				<th>Subject</th>
				<th>Message</th>
				<th>Status</th>
				<th>Actions</th>
			   </tr>
                  </thead>
			<tbody>
			<?php if(count($message_list) >0){ 
			   foreach($message_list as $k=>$content){
			?>
			   <tr id="<?php echo md5($content['id']);?>">
				<td><?php echo ucfirst($content['subject']);?></td>
				<td><?php echo $content['content'];?></td>
				<td><?php echo $content['status'];?></td>
				<td>
				    <?php if($content['status'] == 'Enable'){
					  $alt_text = 'Disable Message';
					  $image_name = 'user_block.png';
					  $status = 'Disable';
				    }else{
					  $alt_text = 'Enable Message';
					  $image_name = 'user_active.png';
					  $status = 'Enable';
				    }?>
				    <a href="javascript:void(0);" onclick="changeContentStatus(this, '<?php echo $status;?>')" id="<?php echo $content['id'];?>" alt="<?php echo $alt_text;?>" title="<?php echo $alt_text;?>"><img src="<?php echo base_url(); ?>lib/images/<?php echo $image_name;?>"/></a>
				    <a href="<?php echo site_url('admin/editmessage/'.base64_encode($content['id']));?>" alt="Edit Message" title="Edit Message"><img src="<?php echo base_url(); ?>lib/images/admin_edit.png"/></a>
				    
				</td>
			   </tr>
			<?php	}
			   }?>
			</tbody>
		   </table>
		</div>
	  </div>
    </div>
</div>
<!-- /.row -->
<script type="text/javascript">
    function changeContentStatus(obj,status) {
	  var content_id = obj.id;
	  $.ajax({
		url : "<?php echo site_url('admin/c');?>",
		dataType:'JSON',
		type: "POST",
		data:{'content_id':content_id,'status':status},
		success: function(data)
		{
		    if (data.success == 'success') {
			  window.location.reload();
		    }
		},error :function(){
		    
		}
	  });
    }
</script>