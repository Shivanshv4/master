<style type="text/css">
   .datepicker{
	top: 526.6px !important;
   }
</style>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($category_details))
{
   $category_name =(isset($category_details['category_name']) && $category_details['category_name'] !="") ? $category_details['category_name']:"";
   $category_status  =(isset($category_details['category_status']) && $category_details['category_status'] !="") ? $category_details['category_status']:"";
   $image_name = (isset($category_details['category_image']) && trim($category_details['category_image']) !="") ? $category_details['category_image'] :"";
   if((isset($category_details['category_image']) && trim($category_details['category_image']) !="")){
	$image = base_url().'uploads/category_images/'.$category_details['category_image'];
   }else{
	$image = base_url().'lib/images/no_product.png';
   }
}
if(isset($category_details['id']) && $category_details['id'] !=""){
   $id_category   = $category_details['id'];
   
}elseif(@$this->uri->segment(4) && @$this->uri->segment(4)!=FALSE){
   $id_category = base64_decode(@$this->uri->segment(4));
}else{
   $id_category = 0;
}
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php if($id_category == 0){
		echo form_open_multipart('admin/category/add');
	   }else{
		echo form_open_multipart('admin/category/add/'.base64_encode($id_category));
	   }?>
		<div class="form-group <?php echo (@form_error('category_name') ? 'has-error' :'');?>">
		   <label>Category Name</label>
               <input class="form-control" type="text" value="<?php echo $category_name;?>" name="category_name"/>
		   <?php echo form_error('category_name','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group <?php echo (@form_error('category_status') ? 'has-error' :'');?>">
               <label>Status</label>
		   <select class="form-control" name="category_status">
			<option value="">Select</option>
			<option value="Active" <?php echo ($category_status == 'Active' ? 'selected="selected"' : '');?>>Active</option>
			<option value="Inactive" <?php echo ($category_status == 'Inactive' ? 'selected="selected"' : '');?>>Inactive</option>
               </select>
		   <?php echo form_error('category_status','<span class="error-msg">','</span>')?>
            </div>
		<div class="form-group <?php echo (@form_error('category_image') ? 'has-error' :'');?>">
		   <label>Category Image</label>
		   <?php if($id_category != 0 && $image != ""){?>
		   <br>
		   <img src="<?php echo $image;?>" alt="<?php echo $name;?>" class="img-thumbnail"  height="160" width="160"/>
		   <?php }?>
               <input class="btn-file" type="file" value="" id="category_image" name="category_image"/>
		   <input type="hidden" name="category_image" value="<?php echo $image_name;?>"/>
		   <em>(Please select file with extensions jpg, jpeg, gif, png with maximum size of 2MB.)</em>
		   <?php echo form_error('category_image','<br><span class="error-msg">','</span>')?>
            </div>
		<div>
		   <input type="hidden" id="category_id" value="<?php echo $id_category;?>" name="id_category"/>
		   <button type="submit" class="btn btn-success">Submit</button>
		   <a href="<?php echo site_url('admin/categories');?>" class="btn btn-primary">Back</a>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->
