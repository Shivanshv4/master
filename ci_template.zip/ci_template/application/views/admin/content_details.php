<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($content_details))
{
   $content_title  =(isset($content_details['content_title']) && $content_details['content_title'] !="") ? $content_details['content_title']:"";
   $variable_name =(isset($content_details['variable_name']) && $content_details['variable_name'] !="") ? $content_details['variable_name']:"";
   $content    =(isset($content_details['content']) && $content_details['content'] !="") ? $content_details['content']:"";
   $status  =(isset($content_details['status']) && $content_details['status'] !="") ? $content_details['status']:"";
}
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php echo form_open_multipart('admin/view_content');?>
		<div class="form-group">
		   <label>Title</label>
               <input class="form-control" type="text" value="<?php echo $content_title;?>" name="content_title" readonly="readonly"/>
            </div>
		<div class="form-group">
		   <label>Variable Name</label>
               <input type="text" class="form-control" value="<?php echo $variable_name;?>" name="variable_name" id="variable_name" readonly="readonly" />
		</div>
		<div class="form-group">
		   <label>Content</label>
               <textarea rows="10" class="form-control mceNoEditor" name="content" id="content" readonly="readonly"><?php echo stripslashes(strip_tags($content));?></textarea>
            </div>
		<div class="form-group"><label>Status</label>
		   <input class="form-control" type="text" value="<?php echo ucfirst($status);?>" name="status" readonly="readonly"/>
            </div>
		<div>
		   <a href="<?php echo site_url('admin/static_content');?>" class="btn btn-primary">Back</a>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->
