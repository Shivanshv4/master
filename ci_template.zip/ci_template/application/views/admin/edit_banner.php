<style type="text/css">
   .datepicker{
	top: 526.6px !important;
   }
</style>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php

if(isset($banner_details))
{
   
   $banner_title =(isset($banner_details['banner_title']) && $banner_details['banner_title'] !="") ? $banner_details['banner_title']:"";
   $link_one =(isset($banner_details['link_one']) && $banner_details['link_one'] !="") ? $banner_details['link_one']:"";
   $link_two =(isset($banner_details['link_two']) && $banner_details['link_two'] !="") ? $banner_details['link_two']:"";
   $cstatus =(isset($banner_details['cstatus']) && $banner_details['cstatus'] !="") ? $banner_details['cstatus']:"";

   //$category_status  =(isset($category_details['category_status']) && $category_details['category_status'] !="") ? $category_details['category_status']:"";
   $image_name = (isset($banner_details['banner_image']) && trim($banner_details['banner_image']) !="") ? $banner_details['banner_image'] :"";
   
   if(isset($banner_details['image_url']) && $banner_details['image_url']!="")
   { 
      $image = $banner_details['image_url'];
   }
   else{
      
      if((isset($banner_details['banner_image']) && trim($banner_details['banner_image']) !="")){
	   $image = base_url().'uploads/banner_images/thumb_'.$banner_details['banner_image'];
      }else{
	   $image = base_url().'lib/images/no_banner.jpg';
      }
   }
}
else{
   $image = base_url().'lib/images/no_banner.jpg';
}
if(isset($banner_details['banner_id']) && $banner_details['banner_id'] !=""){
  $banner_id   = $banner_details['banner_id'];

}elseif(@$this->uri->segment(3) && @$this->uri->segment(3)!=FALSE){
   $banner_id = base64_decode(@$this->uri->segment(3));
}else{
   $banner_id = 0;
}

$bannertype_data = $this->banner_model->getBannerType();


?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <div class="panel-body">
	   <?php if($banner_id == 0){
		echo form_open_multipart('admin/edit_banner');
	   }else{
		echo form_open_multipart('admin/edit_banner/'.base64_encode($banner_id));
	   }?>
		<div class="form-group <?php echo (@form_error('category_name') ? 'has-error' :'');?>">
		   <label>Name</label>

	       <textarea class="form-control" name="banner_title"><?php echo $banner_title ?></textarea>
		   <?php echo form_error('banner_title','<span class="error-msg">','</span>')?>
            </div>

	  <div class="form-group <?php echo (@form_error('category_name') ? 'has-error' :'');?>">
		   <label>Link 1</label>
               <input class="form-control" type="text" value="<?php echo $link_one;?>" name="link_one"/>
		   <?php echo form_error('category_name','<span class="error-msg">','</span>')?>
            </div>
    <div class="form-group <?php echo (@form_error('category_name') ? 'has-error' :'');?>">
		   <label>Link 2</label>
               <input class="form-control" type="text" value="<?php echo $link_two;?>" name="link_two"/>
		   <?php echo form_error('category_name','<span class="error-msg">','</span>')?>
            </div>

		<div class="form-group <?php echo (@form_error('category_status') ? 'has-error' :'');?>">
               <label>Status</label>
		   <select class="form-control" name="banner_status">
			<option value="">Select</option>
			<option value="Active" <?php echo ($cstatus == 'Active' ? 'selected="selected"' : '');?>>Active</option>
			<option value="Inactive" <?php echo ($cstatus == 'Inactive' ? 'selected="selected"' : '');?>>Inactive</option>
               </select>
		   <?php echo form_error('banner_status','<span class="error-msg">','</span>')?>
            </div>
	    
	    <div class="form-group <?php echo (@form_error('category_status') ? 'has-error' :'');?>">
               <label>Banner Type</label>
		   <select class="form-control" name="banner_type">
			<option value="">Select</option>
			<?php foreach($bannertype_data as $type)
			{
			   $sel = $type['id']==$banner_details['banner_type']?"selected='selected'":"";
			   
			   echo '<option value="'.$type['id'].'" '.$sel.' > '.$type['name'].'</option>';
			}
			?>
			
               </select>
		   <?php echo form_error('banner_type','<span class="error-msg">','</span>')?>
            </div>
	    
		<div class="form-group <?php echo (@form_error('banner_image') ? 'has-error' :'');?>">
		   <label>Banner Image</label>
		   <?php if($banner_id != 0 && $image != ""){?>
		   <!--<br>
		   <img src="<?php echo $image;?>" alt="<?php echo $name;?>" class="img-thumbnail"  height="160" width="160"/>-->
		   <?php }?>
                   <!-- <input class="btn-file" type="file" value="" id="banner_image" name="banner_image"/>-->
		   <input type="hidden" name="banner_old_image" value="<?php echo $image_name;?>"/>
		   <!--  <em>(Please select file with extensions jpg, jpeg, gif, png with maximum size of 2MB. Please upload 1920x370 px size image.)
		  
		   </em>-->
		   
		   
		   <div class="admin_user_profile_image banner_image" data-width="1920" data-height="370"  id="user_profile_image" style="background: url('<?php echo $image;?>') no-repeat center; background-size: 100%" >
		     
		     
		   </div>
		   
		   <input type="hidden" name="" id="crop_controls_right" value="32.8">
		   <?php echo form_error('org_image_name','<br><span class="error-msg">','</span>')?>
		   <input type="hidden" name="image_url" id="image_url" value="<?php echo $banner_details['image_url'] ?>">
		   <input type="hidden" name="org_image_name" id="org_image_name" value="<?php echo $banner_details['org_image_name'] ?>">
		   
            </div>
		<div>
		   <input type="hidden" id="banner_id" value="<?php echo $banner_id;?>" name="banner_id"/>
		   <button type="submit" class="btn btn-success">Submit</button>
		   <a href="<?php echo site_url('admin/banner');?>" class="btn btn-primary">Back</a>
            </div>
		<?php echo form_close();?>
	  </div>
    </div>
</div>
<!-- /.row -->


<script src="<?php echo base_url() ?>lib/croppic.js"></script>



<script type="text/javascript">
  
  
   var croppicContaineruserprofileimage = {
				uploadUrl:'<?php echo base_url()?>admin/temp_image_save_user/banner_images',
				cropUrl:'<?php echo base_url()?>admin/temp_image_crop_user/banner_images',
				modal:true,
				doubleZoomControls:false,
				 rotateControls: false,
				imgEyecandyOpacity:0.4,
				loaderHtml:'<div class="loader bubblingG"><span id="bubblingG_1"></span><span id="bubblingG_2"></span><span id="bubblingG_3"></span></div> ',
				onBeforeImgUpload: function(){ console.log('onBeforeImgUpload');  },
				onAfterImgUpload:function(imgobj){ console.log('onAfterImgUpload'); $("#org_image_name").val($(this)[0].imgImage); $("#image_url").val($(this)[0].imgUrl); },
				onImgDrag: function(){ console.log('onImgDrag') },
				onImgZoom: function(){ console.log('onImgZoom') },
				onBeforeImgCrop: function(){ console.log('onBeforeImgCrop') },
				onAfterImgCrop:function(passobj){ console.log(passobj); $("#image_name_id").val(passobj.profile_image);  },
				onReset:function(){ console.log('onReset') },
				onAfterRemoveCroppedImg:function(){ $("#image_name_id").val('');  },
				onError:function(errormessage){
				  bootbox.dialog({
					     message: errormessage,
					     title: "Warning",
					     buttons: {
						 main: {
						 label: "Ok",
						 className: "btn-primary"
						 }
					     },
					     className: 'bootbox-warning'
					     });


				 }
		}
		var cropContaineroutput = new Croppic('user_profile_image', croppicContaineruserprofileimage);

   
</script>
