<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
	  <h1 class="page-header"><?php echo $title;?>
	  </h1>
    </div>
</div>
<?php if(isset($contact_data))
{
   $name    	=(isset($contact_data['name']) && $contact_data['name'] !="") ? $contact_data['name']:"";
   $email   	=(isset($contact_data['email']) && $contact_data['email'] !="") ? $contact_data['email']:"";
   $message   	=(isset($contact_data['content']) && $contact_data['content'] !="") ? $contact_data['content']:"";
}
if(isset($contact_data['id']) && $contact_data['id'] !=""){
   $contact_id   = $contact_data['id'];
   
}elseif(@$this->uri->segment(3) && @$this->uri->segment(3)!=FALSE){
   $contact_id = base64_decode(@$this->uri->segment(3));
}else{
   $contact_id = 0;
}

$page = base64_decode(@$this->uri->segment(4));

if(!empty($page))
{
    $back_url = "admin/contact_management/".$page;
}
else{
    $back_url = "admin/contact_management";
}


?>
<div class="row">
   <div class="col-lg-12">
	<div class="panel-body">
	   <?php echo form_open('admin/reply_contact/'.@$this->uri->segment(3)."/".@$this->uri->segment(4));?>
	   <div class="form-group">
		<label>Name</label>
		<input class="form-control" type="text" value="<?php echo $name;?>" name="name" readonly="readonly"/>
         </div>
	   <div class="form-group">
		<label>Email</label>
		<input class="form-control" type="text" value="<?php echo $email;?>" name="email" readonly="readonly"/>
         </div>
	   <div class="form-group">
		<label>Message</label>
		<textarea rows="10" class="form-control mceEditor" name="content" id="content"><?php echo stripslashes(strip_tags($message));?></textarea>
		<?php echo form_error('content','<span class="error-msg">','</span>')?>
         </div>
	   <div>
		<input type="hidden" name="contact_id" value="<?php echo $contact_id;?>"/>
		<button type="submit" class="btn btn-success">Submit</button>
		<a href="<?php echo site_url($back_url);?>" class="btn btn-primary">Back</a>
         </div>
	   <?php echo form_close();?>
	</div>
   </div>
</div>
