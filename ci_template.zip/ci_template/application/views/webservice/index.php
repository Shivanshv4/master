<!DOCTYPE html>
<html>
   <head>
	<script type="text/javascript" src="<?php echo base_url(); ?>lib/webservice/js/jquery-1.11.1.min.js" ></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>lib/webservice/css/pretty-json.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>lib/webservice/css/style.css" />
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<script src="<?php echo base_url(); ?>lib/webservice/js/custom.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>CI Webservices</title>
	
   </head>
   <body>
	<div id="top">&nbsp;</div>
	<div style="position:fixed;right: 5%;top:40%;">
	   <a href="#top"><input type="button" id="back-top" value="Top"/></a>
	</div>
	<div style="position:fixed;right: 5%;top:50%;">
            <div class="search-box">
            <div class="form_field">
                        <input type="text" name="search" id="search" placeholder="Search Service" value="" />
                         <input type="hidden" id="search_id" placeholder="Search Service" value="" />
                    </div>
        </div>
            <ul>
                <li><a href="#module1" id="module-1">Module 1 Web Services</a></li>
            </ul>
            
        </div>
<style>
   .inactive a{
      background:#fff;
      color:#fff !important;
   }
   .inactive p{
      background:#fff;
      color:#fff !important;
   }
</style>
<!--
*****************************************************************************************************************************************
******************************************** M O D U L E - 1   W E B    S E R V I C E S *************************************************
*****************************************************************************************************************************************
-->
<?php $base_url = $this->config->item('base_url');?>
      <h2 id="module1">CI webservices Module 1</h2>
	   <div class="module-div">
		<ol type="1" class="list_1">
		  <li class="inactive"><a href="javascript:void(0);" data-href="#country_list">Country List</a><p>Service URL: <?php echo $base_url; ?>country_list</p></li>
		  <li class="inactive"><a href="javascript:void(0);" data-href="#get_otp">Get Otp</a><p>Service URL: <?php echo $base_url; ?>get_otp</p></li>
		  <li class="inactive"><a href="javascript:void(0);" data-href="#signup">signup</a><p>Service URL: <?php echo $base_url; ?>signup</p></li>
		  <li class="inactive"><a href="javascript:void(0);" data-href="#verify_otp">verify_otp</a><p>Service URL: <?php echo $base_url; ?>verify_otp</p></li>
		  <li class="active"><a href="javascript:void(0);" data-href="#postphoto">postphoto</a><p>Service URL: <?php echo $base_url; ?>postphoto</p></li>
		  
		</ol>

<!-- ############################################################## Country List ############################################# -->
        
	<div id="country_list" class="div_service">
	   <?php echo form_open('webservice/country_list');?>
	   <h3>Country List</h3>
	  
	   
	   <div class="form_row">
		<div class="form_label">Lang</div>
		<div class="form_field">
		   <input type="text" name="lang" value="" />
		   <div class="desc">key: lang</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
<!-- ############################################################# Get OTP ############################################# -->
        
	<div id="get_otp" class="div_service">
	   <?php echo form_open('webservice/get_otp');?>
	   <h3>Get OTP</h3>
	  
	   <div class="form_row">
		<div class="form_label">phone_no</div>
		<div class="form_field">
		   <input type="text" name="phone_no" value="" />
		   <div class="desc">key: phone_no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Lang</div>
		<div class="form_field">
		   <input type="text" name="lang" value="" />
		   <div class="desc">key: lang</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>                        
		
<!-- ############################################################# SIGNUP ############################################# -->
        
	<div id="signup" class="div_service">
	   <?php echo form_open('webservice/signup');?>
	   <h3>signup</h3>
	  
	   <div class="form_row">
		<div class="form_label">phone_no</div>
		<div class="form_field">
		   <input type="text" name="phone_no" value="" />
		   <div class="desc">key: phone_no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">password</div>
		<div class="form_field">
		   <input type="text" name="password" value="" />
		   <div class="desc">key: password</div>
		</div>
	   </div>
	    <div class="form_row">
		<div class="form_label">otp_no</div>
		<div class="form_field">
		   <input type="text" name="otp_no" value="" />
		   <div class="desc">key: otp_no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Lang</div>
		<div class="form_field">
		   <input type="text" name="lang" value="" />
		   <div class="desc">key: lang</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
<!-- ############################################################# verify otp ############################################# -->
        
	<div id="verify_otp" class="div_service">
	   <?php echo form_open('webservice/verify_otp');?>
	   <h3>verify otp</h3>
	  
	    <div class="form_row">
		<div class="form_label">otp_no</div>
		<div class="form_field">
		   <input type="text" name="otp_no" value="" />
		   <div class="desc">key: otp_no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Lang</div>
		<div class="form_field">
		   <input type="text" name="lang" value="" />
		   <div class="desc">key: lang</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>               

<!-- ############################################################# post photo ############################################# -->
<div id="postphoto" class="div_service">
		<?php echo form_open_multipart('webservice/postphoto');?>
		<h3>Post Photo</h3>
		<div class="form_row">
		   <div class="form_label">* user_id(loggedin user_id)</div>
		   <div class="form_field">
			<input type="text" name="user_id" value="" />
			<div class="desc">key: user_id</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Image Name</div>
		   <input type="file" id="postphoto_image_name" name="post_image[]" multiple size="20" />
		   <?php echo form_error('image_name', '<span class="remove_error">', '</span>');?>
		</div>
		<script>
		  $(function(){
		  $('#postphoto_image_name').change(function(){
		     
		      var input = document.getElementById('postphoto_image_name');
			   if(input.files.length>2){
			      $('#postphoto_image_name').val('');
			       		       alert("You can only upload a maximum of 2 files");
			   }else{
			       $('.validation').css('display','none');
			   }
			
		  
		  });    
	      });
		</script>
		<div class="form_row">
		   <div class="form_label">* caption</div>
		   <div class="form_field">
			<input type="text" name="caption" value="" />
			<div class="desc">key: caption</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* share_type (followers/users)</div>
		   <div class="form_field">
			<input type="text" name="share_type" value="" />
			<div class="desc">key: share_type</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* tag_people (mutiple username seperated by comma)</div>
		   <div class="form_field">
			<input type="text" name="tag_people" class= "mydate1" value=""  />
			<div class="desc">key: tag_people</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* location</div>
		   <div class="form_field">
			<input type="text" name="location" value="" />
			<div class="desc">key: location </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">latitude</div>
		   <div class="form_field">
			<input type="text" name="latitude" value="" />
			<div class="desc">key: latitude </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">longitude</div>
		   <div class="form_field">
			<input type="text" name="longitude" value="" />
			<div class="desc">key: longitude</div>
		   </div>
		</div>
		
		
		<div class="form_row">
		   <div class="form_label">Debug Mode</div>
		   <div class="form_field">
			<input type="text" name="mode" value="" />
			<div class="desc">key: mode <br />values: debug</div>
		   </div>
		</div>
		<div class="form_row" style="display: block;">
		   <div class="form_label">Show Html</div>
		   <div class="form_field">
			<input type="text" name="showHtml" value="yes" />
			<div class="desc">key: showHtml<br /> values: yes / no</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">&nbsp;</div>
		   <div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
		</div>
	   <?php echo form_close(); ?>
	</div>


<!-- ############################################################## User Signup ##################################################### -->

         <div id="user_signup" class="div_service">
		<?php echo form_open_multipart('webservice/user_signup');?>
		<h3>User Signup</h3>
		<div class="form_row">
		   <div class="form_label">* Name</div>
		   <div class="form_field">
			<input type="text" name="name" value="" />
			<div class="desc">key: name</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Email</div>
		   <div class="form_field">
			<input type="text" name="email" value="" />
			<div class="desc">key: email</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Date Of Birth</div>
		   <div class="form_field">
			<input type="text" name="dob" class= "mydate" value=""  />
			<div class="desc">key: dob (Format: YYYY-MM-DD)</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Gender</div>
		   <div class="form_field">
			<input type="text" name="gender" value="" />
			<div class="desc">key: gender ('Male', 'Female') </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Password</div>
		   <div class="form_field">
			<input type="password" name="password" value="" />
			<div class="desc">key: password </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Image Name</div>
		   <input type="file" name="image_name" size="20" />
		   <?php echo form_error('image_name', '<span class="remove_error">', '</span>');?>
		</div>
		<div class="form_row">
		   <div class="form_label">* Account Type</div>
		   <div class="form_field">
			<select name="account_type">
			   <option value="">Select account type</option>
			   <option value="consumer">consumer</option>
			   <option value="shopowner">shopowner</option>
			</select>
			<div class="desc">key: account_type </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Debug Mode</div>
		   <div class="form_field">
			<input type="text" name="mode" value="" />
			<div class="desc">key: mode <br />values: debug</div>
		   </div>
		</div>
		<div class="form_row" style="display: block;">
		   <div class="form_label">Show Html</div>
		   <div class="form_field">
			<input type="text" name="showHtml" value="yes" />
			<div class="desc">key: showHtml<br /> values: yes / no</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">&nbsp;</div>
		   <div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
		</div>
	   <?php echo form_close(); ?>
	</div>
	   <!-- ############################################################## User Signup Facebook##################################################### -->

         <div id="user_signup_facebook" class="div_service">
		<?php echo form_open_multipart('webservice/userSignupFacebook');?>
		<h3>User Signup Facebook</h3>
		<div class="form_row">
		   <div class="form_label">* Facebook Id</div>
		   <div class="form_field">
			<input type="text" name="fb_id" value="" />
			<div class="desc">key: fb_id </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Name</div>
		   <div class="form_field">
			<input type="text" name="name" value="" />
			<div class="desc">key: name</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Email</div>
		   <div class="form_field">
			<input type="text" name="email" value="" />
			<div class="desc">key: email</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label"> Date Of Birth</div>
		   <div class="form_field">
			<input type="text" name="dob" class= "mydate" value=""  />
			<div class="desc">key: dob (Format: YYYY-MM-DD)</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label"> Gender</div>
		   <div class="form_field">
			<input type="text" name="gender" value="" />
			<div class="desc">key: gender ('Male', 'Female') </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Account Type</div>
		   <div class="form_field">
			<select name="account_type">
			   <option value="">Select account type</option>
			   <option value="consumer">consumer</option>
			   <option value="shopowner">shopowner</option>
			</select>
			<div class="desc">key: account_type </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Image Name</div>
		   <div class="form_field">
			<input type="file" name="image_name" size="20" />
			<div class="desc">key: image_name</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Image Name</div>
		   <div class="form_field">
			<input type="text" name="image_name" size="20" />
			<div class="desc">key: image_name</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Is verified E-mail from facebook</div>
		   <div class="form_field">
			<select name="is_verified">
			   <option value=""></option>
			   <option value="No">No</option>
			   <option value="Yes">Yes</option>
			</select>
			<div class="desc">key: is_verified </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Debug Mode</div>
		   <div class="form_field">
			<input type="text" name="mode" value="" />
			<div class="desc">key: mode <br />values: debug</div>
		   </div>
		</div>
		<div class="form_row" style="display: block;">
		   <div class="form_label">Show Html</div>
		   <div class="form_field">
			<input type="text" name="showHtml" value="yes" />
			<div class="desc">key: showHtml<br /> values: yes / no</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">&nbsp;</div>
		   <div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
		</div>
	   <?php echo form_close(); ?>
	</div>
	 
<!-- ############################################################## User Login by email ############################################# -->
        
	<div id="user_emaillogin" class="div_service">
	   <?php echo form_open('webservice/email_login');?>
	   <h3>User Login</h3>
	   <div class="form_row">
		<div class="form_label">* Email</div>
		<div class="form_field">
		   <input type="text" name="email" value="" />
		   <div class="desc">key: email</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Password</div>
		<div class="form_field">
		   <input type="password" name="password" value="" />
		   <div class="desc">key: password </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Device Token</div>
		<div class="form_field">
		   <input type="text" name="device_token" value="" />
		   <div class="desc">key: device_token</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Device Type (android, ios)</div>
		<div class="form_field">
		   <input type="text" name="device_type" value="" />
		   <div class="desc">key: device_type</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">App Version</div>
		<div class="form_field">
		   <input type="text" name="app_version" value="" />
		   <div class="desc">key: app_version</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
                        
<!-- ###################################### User Login by facebook ########################################## -->
        
	<div id="user_facebooklogin" class="div_service">
	   <?php echo form_open('webservice/facebook_login');?>
	   <h3>User Login</h3>
	   <div class="form_row">
		<div class="form_label">* fb_id</div>
		<div class="form_field">
		   <input type="text" name="fb_id" value="" />
		   <div class="desc">key: fb_id </div>
		</div>
	   </div>

	   <div class="form_row">
		   <div class="form_label">Email</div>
		   <div class="form_field">
			<input type="text" value="" name="email">
			<div class="desc">key: email</div>
		   </div>
		</div>

	   <div class="form_row">
		<div class="form_label">Image Name</div>
		<div class="form_field">
		   <input type="text" name="image_name" value="" />
		   <div class="desc">key: image_name</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Device Token</div>
		<div class="form_field">
		   <input type="text" name="device_token" value="" />
		   <div class="desc">key: device_token</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Device Type</div>
		<div class="form_field">
		   <input type="text" name="device_type" value="" />
		   <div class="desc">key: device_type</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">App Version</div>
		<div class="form_field">
		   <input type="text" name="app_version" value="" />
		   <div class="desc">key: app_version</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: none;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
                        
<!-- ############################################### Forgot Password ######################################### -->
        
	<div id="forgetpassword" class="div_service">
	   <?php echo form_open('webservice/forgetpassword');?>
	   <h3>Forget Password</h3>
	   <div class="form_row">
		<div class="form_label">* Email</div>
		<div class="form_field">
		   <input type="text" name="email" value="" />
		   <div class="desc">key: email </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: none;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>

<!--######################################################## View Profile ##########################################-->
        
	<div id="viewProfile" class="div_service">
	   <?php echo form_open('webservice/viewProfile');?>
	   <h3>View Profile</h3>
	   <div class="form_row">
		<div class="form_label"> Shop Id</div>
		<div class="form_field">
		   <input type="text" name="shop_id" value="" />
		   <div class="desc">key: shop_id</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* User Id{login user}</div>
		<div class="form_field">
		   <input type="text" name="user_id" value="" />
		   <div class="desc">key: user_id</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
<!--############################################# Edit Profile #######################################################-->
	<div id="editProfile" class="div_service">
		<?php echo form_open_multipart('webservice/editProfile');?>
		<h3>Edit Profile</h3>
		<div class="form_row">
		   <div class="form_label">* User Id</div>
		   <div class="form_field">
			<input type="text" name="user_id" value="" />
			<div class="desc">key: user_id</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Name</div>
		   <div class="form_field">
			<input type="text" name="name" value="" />
			<div class="desc">key: name</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Email</div>
		   <div class="form_field">
			<input type="text" name="email" value="" />
			<div class="desc">key: email</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Date Of Birth</div>
		   <div class="form_field">
			<input type="text" name="dob" class= "mydate" value="" readonly />
			<div class="desc">key: dob (Format: YYYY-MM-DD)</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">* Gender</div>
		   <div class="form_field">
			<input type="text" name="gender" value="" />
			<div class="desc">key: gender ('Male', 'Female') </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Phone Number</div>
		   <div class="form_field">
			<input type="text" name="phone_number" value="" />
			<div class="desc">key: phone_number </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Phone Number Visibility</div>
		   <div class="form_field">
			<input type="text" name="show_contact" value="" />
			<div class="desc">key: show_contact (Yes/No) (Only for Shop Owner) </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Website Url</div>
		   <div class="form_field">
			<input type="text" name="website_url" value="" />
			<div class="desc">key: website_url (Only for Shop Owner) </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Address</div>
		   <div class="form_field">
			<input type="text" name="address" value="" />
			<div class="desc">key: address </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">*Shop Description (in case of shopowner)</div>
		   <div class="form_field">
			<input type="text" name="shop_description" value="" />
			<div class="desc">key: shop_description </div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">Image Name</div>
		   <input type="file" name="image_name" size="20" />
		   <?php echo form_error('image_name', '<span class="remove_error">', '</span>');?>
		</div>
		<div class="form_row">
		   <div class="form_label">Debug Mode</div>
		   <div class="form_field">
			<input type="text" name="mode" value="" />
			<div class="desc">key: mode <br />values: debug</div>
		   </div>
		</div>
		<div class="form_row" style="display: block;">
		   <div class="form_label">Show Html</div>
		   <div class="form_field">
			<input type="text" name="showHtml" value="yes" />
			<div class="desc">key: showHtml<br /> values: yes / no</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">&nbsp;</div>
		   <div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
		</div>
	   <?php echo form_close(); ?>
	</div>





<!-- ############################################### Category listing ######################################### -->
        
	<div id="category_list" class="div_service">
	   <?php echo form_open('webservice/getAllCategories');?>
	   <h3>Get All Catgeory Listing</h3>
	   <div class="form_row">
		<div class="form_label"> Category Status</div>
		<div class="form_field">
		   <select name="category_status">
			<option value="">Select Status</option>
			<option value="Active">Active</option>
			<option value="Inactive">Inactive</option>
		   </select>
		   <div class="desc">key: category_status </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Page Number</div>
		<div class="form_field">
		   <input type="text" name="page_no" value="" />
		   <div class="desc">key: page_no </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	<!-- ############################################### product/shop listing by category ######################################### -->
        
	<div id="category_list2" class="div_service">
	   <?php echo form_open('webservice/shopProductListByCategory');?>
	   <h3>Get All Shop/Product Listing By Category</h3>
	   <div class="form_row">
		<div class="form_label">* Category Id</div>
		<div class="form_field">
		   <input type="text" name="id_category" value="" />
		   <div class="desc">key: id_category </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* List For</div>
		<div class="form_field">
		   <select name="list_type">
			<option value="">Select Status</option>
			<option value="shop">shop</option>
			<option value="product">product</option>
		   </select>
		   <div class="desc">key: list_type </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Page Number</div>
		<div class="form_field">
		   <input type="text" name="page_no" value="" />
		   <div class="desc">key: page_no </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	
	<!-----------------####################Request List############################---------------->
	<div id="category_search" class="div_service">
	   <?php echo form_open('webservice/getCategorySearch');?>
	   <h3>Catgeory Search</h3>
	   <div class="form_row">
		<div class="form_label">* User Id{logged in}</div>
		<div class="form_field">
		   <input type="text" name="user_id" value="" />
		   <div class="desc">key: user_id</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Category Id{mandatory for search within a category}</div>
		<div class="form_field">
		   <input type="text" name="id_category" value="" />
		   <div class="desc">key: id_category</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Search Type</div>
		<div class="form_field">
		   <select name="search_type">
			<option value="">Select Type</option>
			<option value="cunsumers">cunsumers</option>
			<option value="category">category</option>
			<option value="category_shop">category_shop</option>
			<option value="category_product">category_product</option>
			<option value="category_request">category_request</option>
		   </select>
		   <div class="desc">key: search_type </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label"> Search Text</div>
		<div class="form_field">
		   <input type="text" name="search_text" value="" />
		   <div class="desc">key: search_text</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label"> Filter Type .</div>
		<div class="form_field">
		        <select name="filter_type">
			<option value="">Filter Type</option>
			<option value="latest">latest</option>
			<option value="most_popular">most_popular</option>
			<option value="highest_ratings">highest_ratings</option>
			<option value="most_products">most_products</option>
			<option value="most_followers">most_followers</option>
		        </select>
		   <div class="desc">key: filter_type </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Page No</div>
		<div class="form_field">
		   <input type="text" name="page_no" value="" />
		   <div class="desc">key: page_no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	
	<!-----------------####################Settings############################---------------->
	<div id="user_settings" class="div_service">
	   <?php echo form_open('webservice/saveUserSettings');?>
	   <h3>User Account Settings</h3>
	   <div class="form_row">
		<div class="form_label">* User Id{logged in}</div>
		<div class="form_field">
		   <input type="text" name="user_id" value="" />
		   <div class="desc">key: user_id</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Notifications</div>
		<div class="form_field">
		   <select name="notifications">
			<option value="">Select</option>
			<option value="On">On</option>
			<option value="Off">Off</option>
		   </select>
		   <div class="desc">key: notifications </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Email Alert</div>
		<div class="form_field">
		   <select name="email_alert">
			<option value="">Select</option>
			<option value="On">On</option>
			<option value="Off">Off</option>
		   </select>
		   <div class="desc">key: email_alert </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* New Chat</div>
		<div class="form_field">
		   <select name="new_chat">
			<option value="">Select</option>
			<option value="On">On</option>
			<option value="Off">Off</option>
		   </select>
		   <div class="desc">key: new_chat </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* New Product Posted</div>
		<div class="form_field">
		   <select name="new_product_posted">
			<option value="">Select</option>
			<option value="On">On</option>
			<option value="Off">Off</option>
		   </select>
		   <div class="desc">key: new_product_posted </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Current Password</div>
		<div class="form_field">
		   <input type="password" name="current_password" value="" />
		   <div class="desc">key: current_password</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* New Password</div>
		<div class="form_field">
		   <input type="password" name="new_password" value="" />
		   <div class="desc">key: new_password</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Confirm Password</div>
		<div class="form_field">
		   <input type="password" name="confirm_password" value="" />
		   <div class="desc">key: confirm_password</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	<!-----------------####################Notifications List############################---------------->
	<div id="user_notification" class="div_service">
	   <?php echo form_open('webservice/getUserNotificationList');?>
	   <h3>User Notification List</h3>
	   <div class="form_row">
		<div class="form_label">* User Id{logged in}</div>
		<div class="form_field">
		   <input type="text" name="user_id" value="" />
		   <div class="desc">key: user_id</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label"> Status</div>
		<div class="form_field">
		   <select name="status">
			<option value="">Select</option>
			<option value="Read">Read</option>
			<option value="Unread">Unread</option>
		   </select>
		   <div class="desc">key: status </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Page No</div>
		<div class="form_field">
		   <input type="text" name="page_no" value="" />
		   <div class="desc">key: page_no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	<!-----------------####################Test push notification for android############################---------------->
	<div id="test_push_android" class="div_service">
	   <?php echo form_open('webservice/testPushNotificationAndroid');?>
	   <h3>Test push notification for android</h3>
	   <div class="form_row">
		<div class="form_label"> Device Token 1</div>
		<div class="form_field">
		   <input type="text" name="push_token[]" value="" />
		   <div class="desc">key: push_token</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label"> Device Token 2</div>
		<div class="form_field">
		   <input type="text" name="push_token[]" value="" />
		   <div class="desc">key: push_token</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label"> Api Key</div>
		<div class="form_field">
		   <input type="text" name="api_key" value="" />
		   <div class="desc">key: api_key</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	<!-----------------####################Test push notification for apple############################---------------->
	<div id="test_push_apple" class="div_service">
	   <?php echo form_open('webservice/testPushNotificationApple');?>
	   <h3>Test push notification for apple</h3>
	   <div class="form_row">
		<div class="form_label"> Device Token </div>
		<div class="form_field">
		   <input type="text" name="push_token" value="" />
		   <div class="desc">key: push_token</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>

	<!-----------------#################### Update device token and other details ############################---------------->
	<div id="update_device_token" class="div_service">
	   <?php echo form_open('webservice/updateDeviceToken');?>
	   <h3>Update device token and other details</h3>
	   <div class="form_row">
		<div class="form_label">* User Id{logged in}</div>
		<div class="form_field">
		   <input type="text" name="user_id" value="" />
		   <div class="desc">key: user_id </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label"> Device Token </div>
		<div class="form_field">
		   <input type="text" name="device_token" value="" />
		   <div class="desc">key: device_token</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">App Version</div>
		<div class="form_field">
		   <input type="text" name="app_version" value="" />
		   <div class="desc">key: app_version </div>
		</div>
	   </div>

	   <div class="form_row">
		<div class="form_label">Device Type</div>
		<div class="form_field">
		   <input type="text" name="device_type" value="" />
		   <div class="desc">key: device_type </div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	<!-----------------#################### Contact Us services ############################---------------->
	<div id="contactus" class="div_service">
	   <?php echo form_open('webservice/postContactRequest');?>
	   <h3>Contact Us</h3>
	   <div class="form_row">
		<div class="form_label">* User Id{logged in}</div>
		<div class="form_field">
		   <input type="text" name="user_id" value="" />
		   <div class="desc">key: user_id</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* User Name</div>
		<div class="form_field">
		   <input type="text" name="name" value="" />
		   <div class="desc">key: name</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">* Phone No.</div>
		<div class="form_field">
		   <input type="text" name="phone" value="" />
		   <div class="desc">key: phone</div>
		</div>
	   </div>

	   <div class="form_row">
		<div class="form_label">* Email Address</div>
		<div class="form_field">
		   <input type="text" name="email" value="" />
		   <div class="desc">key: email</div>
		</div>
	   </div>

	   <div class="form_row">
		<div class="form_label">selected Plan Id</div>
		<div class="form_field">
		   <input type="text" name="plan_id" value="" />
		   <div class="desc">key: plan_id</div>
		</div>
	   </div>


	   <div class="form_row">
		<div class="form_label">Subject</div>
		<div class="form_field">
		 <select id="subject" name="subject">
			<option value=""></option>
			<option value="Report Bugs">Report Bugs</option>
			<option value="Enquiry">Enquiry</option>
			<option value="Report Abuse">Report Abuse</option>
			<option value="Others">Others</option>
		</select>

		   <div class="desc">key: subject<br />values: Report, Enquiry, Report Abuse, Others</div>
		</div>
	   </div>

	   <div class="form_row">
		<div class="form_label">* Message</div>
		<div class="form_field">
		  <textarea name="message"></textarea>

		   <div class="desc">key: message</div>
		</div>
	   </div>


	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	<!-----------------#################### Static page ############################---------------->
	<div id="staticpage" class="div_service">
	   <?php echo form_open('webservice/staticpage');?>
	   <h3>Static Page Detail </h3>
	   <!--<div class="form_row">
		<div class="form_label">* User Id{logged in}</div>
		<div class="form_field">
		   <input type="text" name="user_id" value="" />
		   <div class="desc">key: user_id</div>
		</div>
	   </div>-->
	   <div class="form_row">
		<div class="form_label">* Static Page Variable Name</div>
		<div class="form_field">
		   <select name="variable_name">
			<option value="about_us">about_us</option>
			<option value="privacy_policy">privacy_policy</option>
			<option value="terms_conditions">terms_conditions</option>
		   </select>
		   <div class="desc">key: variable_name</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	
	<!-----------------####################Logout############################---------------->
	<div id="logout" class="div_service">
	   <?php echo form_open('webservice/logout');?>
	   <h3>Logout</h3>
	   <div class="form_row">
		<div class="form_label">* User Id</div>
		<div class="form_field">
		   <input type="text" name="user_id" value="" />
		   <div class="desc">key: user_id</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">Debug Mode</div>
		<div class="form_field">
		   <input type="text" name="mode" value="" />
		   <div class="desc">key: mode <br />values: debug</div>
		</div>
	   </div>
	   <div class="form_row" style="display: block;">
		<div class="form_label">Show Html</div>
		<div class="form_field">
		   <input type="text" name="showHtml" value="yes" />
		   <div class="desc">key: showHtml<br /> values: yes / no</div>
		</div>
	   </div>
	   <div class="form_row">
		<div class="form_label">&nbsp;</div>
		<div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
	   </div>
	   <?php echo form_close(); ?>
	</div>
	
	
	<!--############################################# Update Time zone #######################################################-->
	<div id="updateUserTimeZone" class="div_service">
		<?php echo form_open_multipart('webservice/updateUserTimeZone');?>
		<h3>Update Time zone</h3>
		<div class="form_row">
		   <div class="form_label">* User Id</div>
		   <div class="form_field">
			<input type="text" name="user_id" value="" />
			<div class="desc">key: user_id</div>
		   </div>
		</div>
		
		<div class="form_row">
		   <div class="form_label">Debug Mode</div>
		   <div class="form_field">
			<input type="text" name="mode" value="" />
			<div class="desc">key: mode <br />values: debug</div>
		   </div>
		</div>
		<div class="form_row" style="display: block;">
		   <div class="form_label">Show Html</div>
		   <div class="form_field">
			<input type="text" name="showHtml" value="yes" />
			<div class="desc">key: showHtml<br /> values: yes / no</div>
		   </div>
		</div>
		<div class="form_row">
		   <div class="form_label">&nbsp;</div>
		   <div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
		</div>
	   <?php echo form_close(); ?>
	</div>
        <!-- ------------- end update time zone -->
</div>

<!--
*****************************************************************************************************************************************
************************************************* M O D U L E - 2   W E B    S E R V I C E S ********************************************
*****************************************************************************************************************************************
-->

<!--                <h2 id="module2">Warehouse services Module 2</h2>
                <ol type="1" class="list_1">
                        <li><a href="javascript:void(0);" data-href="#get_friend_list">Get Friend List</a><p>Service URL: <?php //echo 'http://'.$_SERVER['HTTP_HOST'].'/warehouse/webservice/' ?>get_friend_list</p></li>
                </ol>-->

<!-- ############################################### Get My Friend List List ####################################################### -->

<!--                <div id="get_friend_list" class="div_service">
                        <form action="webservice/get_friend_list" method="post" enctype="multipart/form-data">
                                <h3>Get Friend List</h3>
                                <div class="form_row">
                                        <div class="form_label">User ID</div>
                                        <div class="form_field">
                                                <input type="text" name="u_id" value="" />
                                                <div class="desc">key: u_id</div>
                                        </div>
                                </div>
                                <div class="form_row">
                                        <div class="form_label">Debug Mode</div>
                                        <div class="form_field">
                                                <input type="text" name="mode" value="" />
                                                <div class="desc">key: mode <br />values: debug</div>
                                        </div>
                                </div>
                                <div class="form_row" style="display: none;">
                                        <div class="form_label">Show Html</div>
                                        <div class="form_field">
                                                <input type="text" name="showHtml" value="yes" />
                                                <div class="desc">key: showHtml<br /> values: yes / no</div>
                                        </div>
                                </div>
                                <div class="form_row">
                                        <div class="form_label">&nbsp;</div>
                                        <div class="form_field"><input type="submit" name="submit" value="Submit" /></div>
                                </div>
                        </form>
                </div>-->
        </body>
</html>
