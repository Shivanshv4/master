<?php
$activePage = $this->uri->segment(1);
if($activePage == 'dashboard')
{ ?>    
    <!--<footer class="footer">
      <div class="bottom-nav">
	 <ul>
	    <li><a href="javascript:void(0)">About</a></li>
	     <li><a href="javascript:void(0)">Coontact Us</a></li>
	    <li><a href="javascript:void(0)">Privacy</a></li>
	    <li><a href="javascript:void(0)">Terms & Conditions</a></li>
	  </ul>
       </div>
       <div class="social-icons">
	  <ul class="text-center">
	    <li><a href="javascript:void(0)"><span class="fa fa-linkedin"></span></a></li>
	    <li><a href="javascript:void(0)"><span class="fa fa-facebook"></span></a></li>
	    <li><a href="javascript:void(0)"><span class="fa fa-instagram"></span></a></li>
	    <li><a href="javascript:void(0)"><span class="fa fa-pinterest-p"></span></a></li>
	  </ul>
	</div>
    </footer>
    </div>-->
<?php } ?>
    


<input type="hidden" id="cm_base_url" value="<?php echo base_url(); ?>" />

    <!-- Include all compiled plugins (below), or include individual files as needed -->
      <!--<script src="//code.jquery.com/jquery-1.10.2.js"></script>-->
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script src="<?php echo base_url(); ?>lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>lib/js/bootstrap-datepicker.js"></script>
    <script src="<?php echo base_url(); ?>lib/js/bootstrap-filestyle.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>lib/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url(); ?>lib/js/jquery.simplr.smoothscroll.min.js"></script>


      <script src="<?php echo base_url(); ?>lib/js/jquery.bxslider.min.js"></script>
      <script src="<?php echo base_url(); ?>lib/js/jquery.masonry.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>lib/js/custom.js" type="text/javascript"></script>
    
    <script type="text/javascript" src="<?php echo base_url(); ?>lib/js/emoticons.js"></script>

<script type="text/javascript">
	  $(window).bind("load resize", function() {
	    var sec_right_height = $('.section-right').height();
            if(window.innerWidth > window.innerHeight){
	     $('.forgot-pswrd-form').css({
	       'margin-top': + (sec_right_height-40)/4 +'px'	
	       });
	     }
	   else{}
        });
     </script>
     <script type="text/javascript">
	$(document).ready(function() {
           
	    $('.error-msg').delay(15000).fadeOut('slow');
	    $('.remove_error').delay(15000).fadeOut('slow');
	    
	    $( "#datepicker" ).datepicker({
	    changeMonth: true,
	    changeYear: true,
	    yearRange: '1900:+0',
	    autoclose: true,
	    todayHighlight: true
	    });


        });
     </script>

  </body>
</html>
