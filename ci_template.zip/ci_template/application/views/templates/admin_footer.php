	</div>
            <!-- /.container-fluid -->
	</div>
        <!-- /#page-wrapper -->
	<!-- /#wrapper -->
	<!-- Bootstrap Core JavaScript -->
	<script src="<?php echo base_url(); ?>lib/js/bootstrap.min.js"></script>
	<!-- Bootstrap Core JavaScript -->
	<link href="<?php echo base_url(); ?>lib/css/jquery.dataTables.css" rel="stylesheet">
	<!-- Bootstrap Core JavaScript -->
	<script src="<?php echo base_url(); ?>lib/js/jquery.dataTables.min.js"></script>
	<!-- Bootstrap Datepicker -->
	<script src="<?php echo base_url(); ?>lib/js/bootstrap-datepicker.js"></script>
	<!-- Colorbox css -->
	<link href="<?php echo base_url(); ?>lib/colorbox/colorbox.css" rel="stylesheet">
	<!-- Bootstrap Datepicker -->
	<script src="<?php echo base_url(); ?>lib/colorbox/jquery.colorbox.js"></script>
	<!--Tiny mce editor-->
	<script type="text/javascript" src="<?php echo base_url();?>lib/tinymce/js/tinymce/tinymce.min.js"></script>
	<script type="text/javascript">
	 
	 //data-table for business users
          var dataTable = jQuery('#user_list_grid').DataTable( {
            "processing": true,
            "serverSide": true,
            "aoColumns": [
                     null,
                     {"bSortable": true },
		     {"bSortable": false },
		     {"bSortable": false },
                    
		    
                  ],
            "ajax":{
              url :"users_data", // json datasource
              type: "post",  // method  , by default get
              error: function(){  // error handling
                jQuery(".business-user-grid-error").html("");
                jQuery("#user_list_grid").append('<tbody class="business-user-grid-error"><tr><th colspan="7">No data found in the server</th></tr></tbody>');
                jQuery("#user_list_grid_processing").css("display","none");
              }
            }
          });
	 
	jQuery('#user_datatable').dataTable( {
	   "order": [[ 0, "desc" ]],
	   "aoColumnDefs": [
		 { 'bSortable': false, 'aTargets': [1,4 ] }
	    ]
	});

	jQuery( "#dob_datepicker" ).datepicker({
	   changeMonth: true,
	   changeYear: true,
	   yearRange: '1900:+0',
	   todayHighlight: true,
	   autoclose: true,
	   toggleActive: true,
	   endDate: '+0d'
	});
	jQuery('.popup').colorbox({iframe:true, width:"50%", height:"65%", overlayClose : false ,escKey:false , arrowKey : false,onClosed:function(){parent.location.reload();}});
	jQuery('.error-msg').delay(15000).fadeOut('slow');
	jQuery('.remove_error').delay(15000).fadeOut('slow');
	jQuery('#alert-success-div').delay(15000).fadeOut('slow');
	jQuery('#msg-close').click(function(){
	jQuery('#alert-success-div').remove();
	});
	tinymce.init({
	   mode: "specific_textareas",
	   theme: "modern",
	   editor_selector : "mceEditor",
	   editor_deselector : "mceNoEditor",
	   plugins: [
		"nonbreaking advlist autolink lists link image charmap print preview anchor",
		"searchreplace visualblocks code fullscreen",
		//"insertdatetime media table contextmenu paste textcolor"
	   ],
	   menubar : false, relative_urls : false,
	   remove_script_host : false,
	   //convert_urls : true,
	   height : 200,
	   width: '100%',
	   toolbar: "bold italic | bullist | code ",
	   //toolbar: "bold italic | link image | forecolor | backcolor | bullist numlist alignleft aligncenter alignright | code "
	   onchange_callback: function(editor) {
	   tinyMCE.triggerSave();
	   }
   });
</script>
   </body>
</html>
