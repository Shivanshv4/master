<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
   <!--head-->
   <head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!--<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">-->
	<title><?php echo $title; ?></title>
	
	<meta property="fb:app_id" content="" />
        <meta property="og:type"   content="website" />
	<meta property="og:site_name" content=""/>
	
        <meta property="og:url"    content="<?php if(isset($meta_url)) echo $meta_url; ?>" />
        <meta property="og:title"  content="<?php echo $title;?>" />
      
	
	<link rel="icon" href="<?php echo base_url(); ?>lib/images/favicon.ico" type="image/gif" >
	<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Roboto:300,700,400,500' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="<?php echo base_url(); ?>lib/css/bootstrap.min.css" >
	
	<link rel="stylesheet" href="<?php echo base_url(); ?>lib/css/jquery.mCustomScrollbar.min.css" >
        <link rel="stylesheet" href="<?php echo base_url(); ?>lib/css/jquery.bxslider.css" />

	<link rel="stylesheet" href="<?php echo base_url(); ?>lib/css/mstyle.css" >
	<!--<link rel="stylesheet" href="<?php echo base_url(); ?>lib/css/datepicker.css" >-->
	<!-- Bootstrap datepicker -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>lib/css/bootstrap-datepicker.min.css" >
	<link rel="stylesheet" href="<?php echo base_url(); ?>lib/css/bootstrap-datetimepicker.min.css"/>
	<link href="<?php echo base_url() ?>lib/css/croppic.css" rel="stylesheet">
	<link src="<?php echo base_url(); ?>lib/css/emoticons.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>lib/css/style.css" >

	<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>-->
	
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="<?php echo base_url(); ?>lib/js/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>lib/js/jquery.form.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>lib/js/bootbox.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>lib/js/emoji.js"></script>

	<script type="text/javascript" src="<?php echo base_url(); ?>lib/cosmatics/js/notification.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>lib/cosmatics/css/notification.css"></script>

       <script type="text/javascript" src="<?php echo base_url(); ?>lib/js/function.js"></script>

   </head>
   <!--EOF head-->
   <!--body-->


   <body>

