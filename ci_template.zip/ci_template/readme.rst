*/ CodeIgniter Template
    
    Singsys Pte. Ltd. (00179) <info@singsys.com>

/*

**************************
Change SESSION COOKIE NAME 
**************************

Change Session Cookie Name After setup the project in application/config/config.php
eg:
$config['sess_cookie_name'] = 'ci_session_wg';

